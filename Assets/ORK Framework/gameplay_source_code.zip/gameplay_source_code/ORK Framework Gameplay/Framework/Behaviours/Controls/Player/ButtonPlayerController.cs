
using ORKFramework;
using UnityEngine;
using System.Collections;

namespace ORKFramework.Behaviours
{
	[RequireComponent(typeof(CharacterController))]
	[AddComponentMenu("ORK Framework/Controls/Player: Button Controller")]
	public class ButtonPlayerController : MonoBehaviour
	{
		public bool moveDead = true;
		
		public bool useCharacterSpeed = false;
		
		public float runSpeed = 8.0f;
		
		// The gravity for the character
		public float gravity = Physics.gravity.y;
		// The gravity in controlled descent mode
		public float speedSmoothing = 10.0f;
		
		public float rotateSpeed = 500.0f;
		
		public bool firstPerson = false;
		
		public bool useCamDirection = true;
		
		public int verticalAxis = 0;
		
		public int horizontalAxis = 0;
		
		// The current move direction in x-z
		private Vector3 moveDirection = Vector3.zero;
		// The current vertical speed
		private float verticalSpeed = 0.0f;
		// The current x-z move speed
		private float moveSpeed = 0.0f;
		
		private float lastMoveSpeed = 0.0f;
		
		private Combatant combatant = null;
		
		private CharacterController controller = null;
		
		private Vector3 targetDirection = Vector3.zero;
		
		
		// jump settings
		public bool useJump = false;
		
		public int jumpKey = 0;
		
		public float jumpDuration = 0.5f;
		
		public float jumpDelay = 0;
		
		public float jumpSpeed = -Physics.gravity.y;
		
		public EaseType jumpInterpolation = EaseType.EaseOutQuad;
		
		public float inAirModifier = 0.5f;
		
		public float jumpMaxGroundAngle = 45;
		
		private Function interpolate;
		
		private bool isJumping = false;
		
		private float jumpTime = 0;
		
		private float jumpTimeout = 0;
		
		
		// sprint settings
		public bool useSprint = false;
		
		public int sprintKey = 0;
		
		public float sprintFactor = 2.0f;
		
		public bool useEnergy = false;
		
		public FloatValue maxEnergy = new FloatValue(10);
		
		public FloatValue energyConsume = new FloatValue(1);
		
		public FloatValue energyRegeneration = new FloatValue(1);
		
		void Start()
		{
			this.moveDirection = this.transform.TransformDirection(Vector3.forward);
			
			if(this.useCharacterSpeed || !this.moveDead || 
				this.useJump || (this.useSprint && this.useEnergy))
			{
				this.combatant = ComponentHelper.GetCombatant(this.transform.root.gameObject);
				if(this.combatant != null && this.useEnergy)
				{
					this.combatant.SprintEnergyMax = this.maxEnergy.GetValue(this.combatant, this.combatant);
					this.combatant.SprintEnergy = this.combatant.SprintEnergyMax;
				}
			}
			this.interpolate = Interpolate.Ease(this.jumpInterpolation);
		}
	
		void Update()
		{
			float t = ORK.Game.DeltaMovementTime;
			if(this.controller == null)
			{
				this.controller = this.GetComponent<CharacterController>();
			}
		
			if(this.jumpTimeout <= 0 && 
				this.jumpTime < this.jumpDuration)
			{
				this.jumpTime += t;
			}
			else if(this.jumpTimeout <= 0)
			{
				this.jumpTime = this.jumpDuration;
				this.isJumping = false;
			}
		
			this.UpdateSmoothedMovementDirection();
			this.ApplyGravity();
		
			if(!(this.lastMoveSpeed == 0 && this.moveSpeed == 0))
			{
				// Calculate actual motion
				Vector3 movement;
				if(this.firstPerson)
				{
					movement = this.targetDirection * this.moveSpeed + new Vector3(0, this.verticalSpeed, 0);
				}
				else
				{
					movement = this.moveDirection * this.moveSpeed + new Vector3(0, this.verticalSpeed, 0);
				}
				movement *= t;
			
				// Move the controller
				this.controller.Move(movement);
			}
			else
			{
				this.controller.Move(new Vector3(0, this.verticalSpeed, 0) * t);
			}
			this.lastMoveSpeed = this.moveSpeed;
		
			if(!this.firstPerson && this.useCamDirection)
			{
				this.transform.rotation = Quaternion.LookRotation(this.moveDirection);
			}
		}
	
		private void UpdateSmoothedMovementDirection()
		{
			float t = ORK.Game.DeltaMovementTime;
			// Forward vector relative to the camera along the x-z plane	
			Vector3 forward = Camera.main.transform.TransformDirection(Vector3.forward);
			forward.y = 0;
			forward = forward.normalized;
	
			// Right vector relative to the camera
			// Always orthogonal to the forward vector
			Vector3 right = new Vector3(forward.z, 0, -forward.x);
		
			if(this.firstPerson || !this.useCamDirection)
			{
				forward = this.transform.TransformDirection(Vector3.forward);
				right = this.transform.TransformDirection(Vector3.right);
			}
		
			float v = 0.0f;
			float h = 0.0f;
			float speedMod = 1;
		
			if(this.combatant == null || 
				((this.moveDead || !this.combatant.Dead) && 
				!this.combatant.Status.StopMovement))
			{
				v = ORK.InputKeys.Get(this.verticalAxis).GetAxis();
				h = ORK.InputKeys.Get(this.horizontalAxis).GetAxis();
			
				if(this.useCharacterSpeed && this.combatant != null)
				{
					this.runSpeed = this.combatant.GetMoveSpeed(MoveSpeedType.Run);
				}
			
				// jump
				if(!this.isJumping && this.useJump && this.controller.isGrounded && 
					ORK.InputKeys.Get(this.jumpKey).GetButton())
				{
					RaycastOutput hit;
					if(RaycastHelper.Raycast(this.controller.transform.position, -Vector3.up, out hit))
					{
						if(Vector3.Angle(Vector3.up, hit.normal) < this.jumpMaxGroundAngle)
						{
							this.combatant.Animations.Play(ORK.AnimationTypes.jumpID);
							this.isJumping = true;
							this.jumpTime = 0;
							this.jumpTimeout = this.jumpDelay;
						}
					}
				}
			
				// sprint
				if(this.combatant != null)
				{
					if(this.useSprint && this.controller.isGrounded &&
						ORK.InputKeys.Get(this.sprintKey).GetButton())
					{
						if(this.EnergyHandling(true))
						{
							speedMod = this.sprintFactor;
						}
					}
					else
					{
						this.EnergyHandling(false);
					}
				}
			}
			
			// Target direction relative to the camera
			if(this.useCamDirection || this.firstPerson)
			{
				this.targetDirection = h * right + v * forward;
			}
			else if(!this.useCamDirection)
			{
				this.transform.Rotate(Vector3.up * h * this.rotateSpeed * t);
				this.targetDirection = v * this.transform.TransformDirection(Vector3.forward);
			}
		
			if(!this.controller.isGrounded)
			{
				this.targetDirection *= this.inAirModifier;
			}
		
			// We store speed and direction seperately,
			// so that when the character stands still we still have a valid forward direction
			// moveDirection is always normalized, and we only update it if there is user input.
			if(this.targetDirection != Vector3.zero)
			{
				// If we are really slow, just snap to the target direction
				if(this.moveSpeed < (runSpeed / 2) * 0.9f)
				{
					this.moveDirection = this.targetDirection.normalized;
				}
				else if(!this.firstPerson)
				{
					this.moveDirection = Vector3.RotateTowards(this.moveDirection, this.targetDirection, 
						this.rotateSpeed * Mathf.Deg2Rad * t, 1000).normalized;
				}
			}
			else
			{
				this.moveDirection = this.transform.TransformDirection(Vector3.forward);
			}
		
			// Smooth the speed based on the current target direction
			float curSmooth = speedSmoothing * t;
		
			// Choose target speed
			//* We want to support analog input but make sure you cant walk faster diagonally than just forward or sideways
			float targetSpeed = Mathf.Min(this.targetDirection.magnitude, 1.0f);
			if(targetSpeed < 0.2)
				targetSpeed = 0;
			targetSpeed = targetSpeed * runSpeed * speedMod;
			this.moveSpeed = Mathf.Lerp(this.moveSpeed, targetSpeed, curSmooth);
		}
	
		private void ApplyGravity()
		{
			if(this.isJumping && this.jumpTimeout <= 0)
			{
				this.verticalSpeed = Interpolate.Ease(this.interpolate, 
					this.jumpSpeed, -this.jumpSpeed + 0.1f, this.jumpTime, this.jumpDuration);
			}
			else
			{
				this.verticalSpeed = gravity;
			}
			if(this.jumpTimeout > 0)
			{
				this.jumpTimeout -= ORK.Game.DeltaMovementTime;
			}
		}
	
		private bool EnergyHandling(bool use)
		{
			bool ok = true;
			if(this.useSprint && this.useEnergy)
			{
				float t = ORK.Game.DeltaMovementTime;
				// set max
				this.combatant.SprintEnergyMax = this.maxEnergy.GetValue(this.combatant, this.combatant);
				// regenerate
				this.combatant.SprintEnergy += this.energyRegeneration.GetValue(this.combatant, this.combatant) * t;
				// use
				if(use)
				{
					float tmp = this.energyConsume.GetValue(this.combatant, this.combatant) * t;
					if(tmp > this.combatant.SprintEnergy)
						ok = false;
					else
						this.combatant.SprintEnergy -= tmp;
				}
				// max bounds
				if(this.combatant.SprintEnergy < 0)
					this.combatant.SprintEnergy = 0;
				else if(this.combatant.SprintEnergy > this.combatant.SprintEnergyMax)
				{
					this.combatant.SprintEnergy = this.combatant.SprintEnergyMax;
				}
			}
			return ok;
		}
	}
}
