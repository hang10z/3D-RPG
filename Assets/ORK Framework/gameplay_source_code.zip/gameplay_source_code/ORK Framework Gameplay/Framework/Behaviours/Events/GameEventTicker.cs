
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class GameEventTicker : MonoBehaviour, IEventStarter
	{
		private GameEvent gameEvent;
		
		private IEventStarter starter;
		
		public void StartEvent(ORKGameEvent eventAsset, IEventStarter starter, GameObject startingObject)
		{
			if(eventAsset != null)
			{
				this.starter = starter;
				
				this.gameEvent = new GameEvent();
				this.gameEvent.SetData(eventAsset.GetData().ToDataObject());
				this.gameEvent.StartEvent(this, startingObject);
			}
			else if(ComponentHelper.IsAlive(starter))
			{
				starter.EventEnded();
				GameObject.Destroy(this);
			}
		}
		
		void Update()
		{
			if(!ORK.Game.Paused && 
				this.gameEvent != null && this.gameEvent.Executing)
			{
				this.gameEvent.Tick(ORK.Game.DeltaTime);
			}
		}
		
		public void EventEnded()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
			}
			GameObject.Destroy(this);
		}

		public void DontDestroy()
		{
			if(ComponentHelper.IsAlive(this.starter))
			{
				GameObject.DontDestroyOnLoad(this.starter.GameObject);
			}
			else
			{
				GameObject.DontDestroyOnLoad(this.gameObject);
			}
		}

		public GameObject GameObject
		{
			get
			{
				if(ComponentHelper.IsAlive(this.starter))
				{
					return this.starter.GameObject;
				}
				else
				{
					return this.gameObject;
				}
			}
		}
	}
}
