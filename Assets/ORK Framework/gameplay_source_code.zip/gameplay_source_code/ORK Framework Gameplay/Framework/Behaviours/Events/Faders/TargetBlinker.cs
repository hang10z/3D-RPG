
using ORKFramework;
using System.Collections.Generic;
using System.Collections;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class TargetBlinker : ColorFader
	{
		void Awake()
		{
			this.inPause = true;
		}
	}
}
