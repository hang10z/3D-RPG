
using ORKFramework;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class CombatantComponent : MonoBehaviour
	{
		public Combatant combatant;
		
		public AddCombatant addCombatantComponent;
		
		private bool registered = false;
		
		
		// movement variables
		private bool inAir = false;
		
		private float verticalSpeed = 0;
		
		private float horizontalSpeed = 0;
		
		private Vector3 lastPosition;
		
		private float lastMoveTime = 0;
		
		
		// movement components
		private CharacterController controllerComp;
		
		private Rigidbody rigidbodyComp;
		
		private Rigidbody2D rigidbody2DComp;
		
		private NavMeshAgent navMeshAgent;
		
		void Start()
		{
			// find character controller
			this.controllerComp = this.GetComponent<CharacterController>();
			if(this.controllerComp == null)
			{
				this.controllerComp = this.transform.root.GetComponentInChildren<CharacterController>();
			}
			// find rigidbody
			this.rigidbodyComp = this.GetComponent<Rigidbody>();
			if(this.rigidbodyComp == null)
			{
				this.rigidbodyComp = this.transform.root.GetComponentInChildren<Rigidbody>();
			}
			// find rigidbody2D
			this.rigidbody2DComp = this.GetComponent<Rigidbody2D>();
			if(this.rigidbody2DComp == null)
			{
				this.rigidbody2DComp = this.transform.root.GetComponentInChildren<Rigidbody2D>();
			}
			// find navmesh agent
			this.navMeshAgent = this.GetComponent<NavMeshAgent>();
			if(this.navMeshAgent == null)
			{
				this.navMeshAgent = this.transform.root.GetComponentInChildren<NavMeshAgent>();
			}
			
			this.lastPosition = this.transform.position;
			
			// set damage dealer/zone combatant
			if(this.combatant != null)
			{
				DamageBase[] damage = this.gameObject.GetComponentsInChildren<DamageBase>();
				for(int i=0; i<damage.Length; i++)
				{
					damage[i].Combatant = this.combatant;
				}
			}
		}
		
		
		/*
		============================================================================
		Combatant register functions
		============================================================================
		*/
		void OnEnable()
		{
			if(this.combatant != null && !this.registered)
			{
				ORK.Game.Combatants.Add(this.combatant);
				this.registered = true;
			}
		}
		
		void OnDisable()
		{
			if(this.combatant != null && this.registered)
			{
				ORK.Game.Combatants.Remove(this.combatant);
				this.registered = false;
			}
		}
		
		void OnDestroy()
		{
			if(this.combatant != null && 
				this.combatant.GameObject == this.gameObject)
			{
				this.combatant.StorePosition();
				this.combatant.ClearHUD();
			}
		}
		
		
		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		void Update()
		{
			if(this.combatant != null && !ORK.Game.Paused)
			{
				if(!this.registered)
				{
					this.OnEnable();
				}
				
				// update movement data
				this.UpdateMovementDelta();
				
				// start battle
				if(!this.combatant.Dead && this.combatant.GameObject != null && 
					ORK.Control.CanInteract && !ORK.Control.InBattle && 
					!ORK.Game.ActiveGroup.AllDeadBattle() && 
					ORK.Game.ActiveGroup.Leader != null && 
					ORK.Game.ActiveGroup.Leader.GameObject != null && 
					this.combatant.IsEnemy(ORK.Game.ActiveGroup.Leader) && 
				// check auto start
					((this.combatant.Setting.autoStartBattles && 
						this.combatant.Setting.battleStartRange.InRange(this.combatant, ORK.Game.ActiveGroup.Leader)) || 
				// check move detection
					(this.combatant.Setting.useAutoStartMoveDetection && 
						this.combatant.Setting.autoStartMoveDetection.Check(this.combatant, ORK.Game.ActiveGroup.Leader))) && 
				// check requirement
					this.combatant.Setting.CheckAutoStartBattleRequirements(this.combatant, ORK.Game.ActiveGroup.Leader))
				{
					List<GameObject> tmp = new List<GameObject>();
					tmp.Add(this.combatant.GameObject);
					tmp.Add(ORK.Game.ActiveGroup.Leader.GameObject);
					
					Vector3 center = TransformHelper.GetCenterPosition(tmp);
					BattleComponent battle = null;
					
					if(this.combatant.Group.Spawner != null)
					{
						battle = this.combatant.Group.Spawner.GetBattleComponent(center, 
							ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles);
					}
					else if(this.addCombatantComponent != null)
					{
						battle = this.addCombatantComponent.GetBattleComponent(center, 
							ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles);
					}
					else
					{
						battle = new GameObject("_Battle").AddComponent<BattleComponent>();
						battle.transform.position = center;
						battle.transform.eulerAngles = ORK.Game.ActiveGroup.Leader.GameObject.transform.eulerAngles;
						battle.battleType = this.combatant.Group.BattleType;
						battle.useSceneID = false;
						battle.DontDestroy();
					}
				
					if(battle != null)
					{
						battle.StartGroup(this.combatant.Group, null);
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Movement functions
		============================================================================
		*/
		private void UpdateMovementDelta()
		{
			if(this.combatant.Setting.moveSettings.usePositionChange)
			{
				this.SetVelocity((this.transform.position - this.lastPosition) / Time.deltaTime);
			}
			else
			{
				if(this.controllerComp != null)
				{
					this.inAir = !this.controllerComp.isGrounded;
					this.SetVelocity(this.controllerComp.velocity);
				}
				else if(this.rigidbodyComp != null)
				{
					this.SetVelocity(this.rigidbodyComp.velocity);
				}
				else if(this.rigidbody2DComp != null)
				{
					this.SetVelocity(this.rigidbody2DComp.velocity);
				}
				else if(this.navMeshAgent != null)
				{
					this.SetVelocity(this.navMeshAgent.velocity);
				}
				else
				{
					this.SetVelocity((this.transform.position - this.lastPosition) / Time.deltaTime);
				}
			}
			
			if(this.transform.position != this.lastPosition)
			{
				this.lastPosition = this.transform.position;
				this.lastMoveTime = Time.time;
			}
		}
		
		public bool InAir
		{
			get{ return this.inAir;}
		}
	
		public float HorizontalSpeed
		{
			get{ return this.horizontalSpeed;}
		}
	
		public float VerticalSpeed
		{
			get{ return this.verticalSpeed;}
		}
	
		private void SetVelocity(Vector3 velocity)
		{
			this.verticalSpeed = velocity.y;
			velocity.y = 0;
			this.horizontalSpeed = velocity.magnitude;
		}
		
		public float LastMoveTime
		{
			get{ return this.lastMoveTime;}
			set{ this.lastMoveTime = value;}
		}
		
		
		/*
		============================================================================
		Drop functions
		============================================================================
		*/
		public bool DropInteract(DragInfo drag)
		{
			if(drag == null)
			{
				return ORK.Battle.CombatantClicked(this.combatant);
			}
			else
			{
				return drag.Origin.DroppedOnCombatant(this.combatant, drag);
			}
		}
	}
}
