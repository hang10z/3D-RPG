
using UnityEngine;
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Events;
using System.Collections.Generic;
using System.Reflection;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class MoveAIComponent : MonoBehaviour, IEventStarter
	{
		public Combatant combatant;
		
		public MoveAISetting settings;
		
		public MoveAIMode mode = MoveAIMode.Idle;
		
		public bool blocked = false;
		
		
		// waypoint
		private Vector3 startPosition = Vector3.zero;
		
		private List<Vector3> waypoint = new List<Vector3>();
		
		private int waypointIndex = 0;
		
		private bool useRandomWaypoints = true;
		
		private bool waypointRandomOrder = false;
		
		
		// idle
		private int idleEventIndex = -1;
		
		private MoveEvent idleMoveEvent;
		
		
		// target
		private GameObject targetObject;
		
		private Combatant targetCombatant;
		
		private float detectionTime = -1;
		
		private float targetPosTime = -1;
		
		private float targetLostTime = -1;
		
		
		// remember last target on stop
		private GameObject lastTarget;
		
		private Combatant lastCombatant;
		
		public MoveAIMode lastMode = MoveAIMode.Idle;
		
		
		// moving
		public Vector3 movePosition;
		
		private MoveSpeed speed;
		
		private bool isMoving = false;
		
		private float stopTime = 0;
		
		
		// flee
		private float fleeTime = -1;
		
		
		// move components
		private SimpleMove simpleMove;
		
		private NavMeshAgent navMeshAgent;
		
		private Component customComponent;
		
		private MethodInfo customSpeedMethod;
		
		private MethodInfo customPositionMethod;
		
		private MethodInfo customStopMethod;
		
		void OnDrawGizmosSelected()
		{
			Gizmos.DrawWireCube(this.movePosition, Vector3.one);
		}
		
		void Start()
		{
			this.startPosition = this.gameObject.transform.position;
		}
		
		void Update()
		{
			if(!ORK.Control.MoveAIBlocked && !this.blocked && 
				this.combatant != ORK.Game.ActiveGroup.Leader && 
				ORK.Battle.CanUseMoveAI(this.combatant))
			{
				// move AI logic
				// TODO: when InAction > update target position!
				if(!this.combatant.Dead && !this.combatant.Status.StopMovement && 
					!this.combatant.Actions.InAction)
				{
					if(this.lastTarget != null)
					{
						this.targetObject = this.lastTarget;
						this.targetCombatant = this.lastCombatant;
						this.mode = this.lastMode;
						this.lastTarget = null;
						this.lastCombatant = null;
					}
					
					// tick the move event
					if(this.idleMoveEvent != null)
					{
						this.idleMoveEvent.Tick(ORK.Game.DeltaTime);
					}
					// stop when not getting closer
					else if(this.isMoving && this.settings.autoStop)
					{
						if((this.targetCombatant != null && 
								Range.Distance(this.combatant, this.targetCombatant, true, false) < this.settings.stopDistance) || 
							(this.targetCombatant == null && 
								Vector3.Distance(this.transform.position, this.movePosition) < this.settings.stopDistance))
						{
							if(this.stopTime == -1)
							{
								this.stopTime = Time.time;
							}
							else if(this.stopTime + this.settings.stopTime < Time.time)
							{
								this.Stop();
								if(this.settings.stopClear)
								{
									this.ClearTarget(false);
								}
							}
						}
						else
						{
							this.stopTime = -1;
						}
					}
				
					// detect possible targets
					if(!MoveAIMode.Hunt.Equals(this.mode) && this.settings.IsDetectionEnabled() && 
						(!this.settings.leaderStopHunt || this.combatant.IsLeader) && 
						this.IsInHuntingRange())
					{
						// timeout running
						if(this.detectionTime > 0)
						{
							this.detectionTime -= ORK.Game.DeltaMovementTime;
						}
						// detection
						else
						{
							this.detectionTime = this.settings.detectionTimeout;
						
							List<Combatant> targets = this.settings.DetectTargets(this.combatant);
							for(int i=0; i<targets.Count; i++)
							{
								// flee or hunt?
								if(this.settings.IsFlee(this.combatant, targets[i]))
								{
									this.SetTarget(targets[i], MoveAIMode.Flee);
								}
								else if(this.settings.IsHunting(this.combatant, targets[i]))
								{
									this.SetTarget(targets[i], MoveAIMode.Hunt);
								}
							}
						}
					}
				
					// movement to target
					if(this.targetObject != null && this.idleMoveEvent == null)
					{
						// update the target position
						if(this.targetPosTime >= 0)
						{
							this.targetPosTime -= ORK.Game.DeltaMovementTime;
							if(this.targetPosTime < 0)
							{
								this.UpdateTargetPosition(false);
							}
						}
						
						if(this.settings.followLeader && this.settings.leaderPriority && 
							!this.combatant.IsLeader && this.combatant.Group.Leader != this.targetCombatant && 
							this.settings.leaderPriorityRange.OutOfRange(this.combatant, this.combatant.Group.Leader))
						{
							if(this.CheckFollowLeader())
							{
								return;
							}
						}
					
						// following leader
						if(this.combatant.Group.Leader == this.targetCombatant)
						{
							if(MoveAIMode.Follow.Equals(this.mode) && 
								this.settings.followLeaderRange.InRange(this.combatant, this.targetCombatant))
							{
								this.ClearTarget(false);
							}
							else if(this.settings.autoRespawn && 
								this.settings.autoRespawnRange.OutOfRange(this.combatant, this.targetCombatant))
							{
								this.combatant.RespawnFlag = true;
								this.combatant.Group.RespawnGroup();
							}
							else if(MoveAIMode.GiveWay.Equals(this.mode) && this.settings.giveWay && 
								this.settings.giveWayRange.OutOfRange(this.combatant, this.targetCombatant))
							{
								this.ClearTarget(false);
							}
						}
						// flee checks
						else if(MoveAIMode.Flee.Equals(this.mode))
						{
							if(this.fleeTime > 0)
							{
								this.fleeTime -= ORK.Game.DeltaMovementTime;
							
								// time's up, stop
								if(this.fleeTime <= 0)
								{
									this.fleeTime = -1;
									this.ClearTarget(false);
								}
							}
						}
						// hunt checks
						else if(MoveAIMode.Hunt.Equals(this.mode) && 
							this.targetCombatant != null)
						{
							if(this.IsOutOfHuntingRange())
							{
								this.targetLostTime = -1;
								this.ClearTarget(false);
								
								this.SetMode(MoveAIMode.Waypoint);
								this.SetMovePosition(this.startPosition);
							}
							else if(this.settings.useHuntingStopRange && 
								this.settings.huntingStopRange.InRange(this.combatant, this.targetCombatant))
							{
								this.targetPosTime = -1;
								this.Stop();
							}
							else if(this.settings.useHuntingStopRange && 
								this.settings.huntingStopRange.OutOfRange(this.combatant, this.targetCombatant))
							{
								this.UpdateTargetPosition(true);
							}
							else if(this.targetLostTime > 0)
							{
								this.targetLostTime -= ORK.Game.DeltaMovementTime;
							
								// found again, stop interval
								if(this.settings.useDetection && 
									this.settings.Detect(this.combatant, this.targetCombatant))
								{
									this.targetLostTime = -1;
								}
								// interval ended, target lost
								else if(this.targetLostTime <= 0)
								{
									this.targetLostTime = -1;
									this.ClearTarget(false);
								}
							}
							// target left the detection area
							else if(!this.settings.Detect(this.combatant, this.targetCombatant))
							{
								// no interval, target lost
								if(this.settings.huntingLostInterval <= 0)
								{
									this.ClearTarget(false);
								}
								// set target lost interval
								else
								{
									this.targetLostTime = this.settings.huntingLostInterval;
								}
							}
						}
					}
					// no target
					else if(this.targetObject == null)
					{
						// follow leader
						this.CheckFollowLeader();
						
						// waypoints
						if(this.targetObject == null && this.idleMoveEvent == null && 
							MoveAIMode.Waypoint.Equals(this.mode) && 
							(!this.settings.followLeader || !this.settings.leaderNoWaypoint || this.combatant.IsLeader))
						{
							this.CheckNextWaypoint();
						}
					
						// perform idle event if nothing to do
						if(MoveAIMode.Idle.Equals(this.mode) && this.idleMoveEvent == null)
						{
							this.PerformIdle();
						}
					}
				}
				else if(!MoveAIMode.Idle.Equals(this.mode))
				{
					this.ClearTarget(true);
				}
			}
			else if(!MoveAIMode.Idle.Equals(this.mode))
			{
				this.ClearTarget(true);
			}
		}
		
		private bool CheckFollowLeader()
		{
			if(this.settings.followLeader && !this.combatant.IsLeader)
			{
				if(this.settings.autoRespawn && 
					this.settings.autoRespawnRange.OutOfRange(this.combatant, this.combatant.Group.Leader))
				{
					this.combatant.RespawnFlag = true;
					this.combatant.Group.RespawnGroup();
					return true;
				}
				else if(this.settings.followLeaderRange.OutOfRange(this.combatant, this.combatant.Group.Leader))
				{
					this.SetTarget(this.combatant.Group.Leader, MoveAIMode.Follow);
					return true;
				}
				else if(this.settings.giveWay && this.settings.giveWayRange.InRange(this.combatant, this.combatant.Group.Leader))
				{
					this.SetTarget(this.combatant.Group.Leader, MoveAIMode.GiveWay);
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Target functions
		============================================================================
		*/
		private void SetMode(MoveAIMode mode)
		{
			this.StopIdle();
			
			this.mode = mode;
			this.targetLostTime = -1;
			this.fleeTime = -1;
			
			if(MoveAIMode.Follow.Equals(this.mode))
			{
				this.speed = this.settings.followSpeed;
			}
			else if(MoveAIMode.GiveWay.Equals(this.mode))
			{
				this.speed = this.settings.giveWaySpeed;
			}
			else if(MoveAIMode.Hunt.Equals(this.mode))
			{
				this.speed = this.settings.huntingSpeed;
			}
			else if(MoveAIMode.Flee.Equals(this.mode))
			{
				this.speed = this.settings.fleeSpeed;
				this.fleeTime = this.settings.fleeTime;
			}
			else if(MoveAIMode.Waypoint.Equals(this.mode))
			{
				this.speed = this.settings.waypointSpeed;
			}
			
			if(MoveAIMode.Idle.Equals(this.mode))
			{
				this.ClearTarget(false);
				this.PerformIdle();
			}
			else
			{
				this.UpdateTargetPosition(true);
			}
		}
		
		public void ActionFinished(List<Combatant> targets)
		{
			if(targets != null)
			{
				for(int i=0; i<targets.Count; i++)
				{
					if(targets[i] != null && targets[i] != null && 
						this.combatant.IsEnemy(targets[i]))
					{
						if(this.settings.huntingLostInterval > 0 || 
							this.settings.Detect(this.combatant, targets[i]))
						{
							this.SetTarget(targets[i], MoveAIMode.Hunt);
							return;
						}
					}
				}
			}
			if(!MoveAIMode.Waypoint.Equals(this.mode) && 
				!MoveAIMode.Hunt.Equals(this.mode))
			{
				this.PerformIdle();
			}
		}
		
		public void DamagedBy(Combatant combatant)
		{
			if(this.settings.detectOnDamage && 
				!MoveAIMode.Hunt.Equals(this.mode))
			{
				this.SetTarget(combatant, MoveAIMode.Hunt);
			}
		}
		
		public bool IsTarget(Combatant target)
		{
			return this.targetCombatant == target;
		}
		
		public void SetTarget(Combatant target, MoveAIMode mode)
		{
			this.targetCombatant = target;
			this.targetObject = target.GameObject;
			this.SetMode(mode);
		}
		
		public void SetTarget(GameObject target, MoveAIMode mode)
		{
			this.targetCombatant = null;
			this.targetObject = target;
			this.SetMode(mode);
		}
		
		public void ClearTarget(bool remember)
		{
			this.Stop();
			this.StopIdle();
			
			// remember last target and mode
			if(remember)
			{
				this.lastCombatant = this.targetCombatant;
				this.lastTarget = this.targetObject;
				this.lastMode = this.mode;
			}
			
			// reset target and mode
			this.targetCombatant = null;
			this.targetObject = null;
			this.mode = MoveAIMode.Idle;
		}
		
		public bool IsInHuntingRange()
		{
			return !this.settings.useHuntingRange || 
				this.settings.huntingRange == null || 
				this.settings.huntingRange.InRange(this.startPosition, this.combatant);
		}
		
		public bool IsOutOfHuntingRange()
		{
			return this.settings.useHuntingRange && 
				this.settings.huntingRange != null && 
				this.settings.huntingRange.OutOfRange(this.startPosition, this.combatant);
		}
		
		
		/*
		============================================================================
		Move functions
		============================================================================
		*/
		private void UpdateTargetPosition(bool force)
		{
			if(this.targetObject != null && 
				(force || this.targetPosTime < 0 || 
					this.movePosition != this.targetObject.transform.position) && 
				(!MoveAIMode.Hunt.Equals(this.mode) || 
					(this.targetLostTime <= 0 || this.settings.huntingLostUpdate)))
			{
				this.SetMovePosition(this.targetObject.transform.position);
				if(this.targetCombatant != null)
				{
					this.targetPosTime = this.settings.GetTargetCheckInterval(this.combatant, this.targetCombatant);
				}
				else
				{
					this.targetPosTime = this.settings.GetTargetCheckInterval(this.combatant.GameObject, this.targetObject);
				}
			}
		}
		
		public void SetMovePosition(Vector3 position)
		{
			this.isMoving = true;
			float speed = this.speed.GetSpeed(this.combatant);
			if(MoveAIMode.Flee.Equals(this.mode) || 
				MoveAIMode.GiveWay.Equals(this.mode))
			{
				this.movePosition = this.transform.position + 
					((this.transform.position - position).normalized * speed * this.settings.fleeTime);
			}
			else
			{
				this.movePosition = position;
			}
		
			this.InitMoveComponent();
		
			// simple direct move
			if(MoveComponentType.Default.Equals(this.settings.compType) && 
				this.simpleMove != null)
			{
				this.simpleMove.MoveTo(speed, this.movePosition);
			}
			// Nav Mesh Agent
			else if(MoveComponentType.NavMeshAgent.Equals(this.settings.compType) && 
				this.navMeshAgent != null)
			{
				this.navMeshAgent.speed = speed;
				this.navMeshAgent.SetDestination(this.movePosition);
				this.navMeshAgent.Resume();
			}
			// custom component
			else if(MoveComponentType.Custom.Equals(this.settings.compType))
			{
				// set speed
				if(this.customSpeedMethod != null)
				{
					this.customSpeedMethod.Invoke(this.customComponent, new System.Object[] {speed});
				}
				// set position
				if(this.customPositionMethod != null)
				{
					this.customPositionMethod.Invoke(this.customComponent, new System.Object[] {this.movePosition});
				}
			}
		}
		
		public void Stop()
		{
			this.isMoving = false;
			this.InitMoveComponent();
		
			if(MoveComponentType.Default.Equals(this.settings.compType) && 
				this.simpleMove != null)
			{
				this.simpleMove.Stop();
			}
			// Nav Mesh Agent
			else if(MoveComponentType.NavMeshAgent.Equals(this.settings.compType) && 
				this.navMeshAgent != null)
			{
				this.navMeshAgent.Stop();
			}
			// custom component
			else if(MoveComponentType.Custom.Equals(this.settings.compType) && 
				this.customStopMethod != null)
			{
				this.customStopMethod.Invoke(this.customComponent, null);
			}
		}
		
		private void InitMoveComponent()
		{
			// simple direct move
			if(MoveComponentType.Default.Equals(this.settings.compType))
			{
				if(this.simpleMove == null)
				{
					this.simpleMove = this.transform.root.GetComponentInChildren<SimpleMove>();
					if(this.simpleMove == null && this.settings.compAdd)
					{
						this.simpleMove = this.gameObject.AddComponent<SimpleMove>();
					}
				}
			}
			// Nav Mesh Agent
			else if(MoveComponentType.NavMeshAgent.Equals(this.settings.compType))
			{
				if(this.navMeshAgent == null)
				{
					this.navMeshAgent = this.transform.root.GetComponentInChildren<NavMeshAgent>();
					if(this.navMeshAgent == null && this.settings.compAdd)
					{
						this.navMeshAgent = this.gameObject.AddComponent<NavMeshAgent>();
					}
					
					if(this.navMeshAgent != null && 
						!this.navMeshAgent.isOnNavMesh)
					{
						this.navMeshAgent.enabled = false;
						this.navMeshAgent.enabled = true;
					}
				}
			}
			// custom component
			else if(MoveComponentType.Custom.Equals(this.settings.compType) && 
				this.settings.compName != "" && this.customComponent == null)
			{
				System.Type type = ORK.Core.TypeHandler.GetType(this.settings.compName, typeof(Component));
				if(type != null)
				{
					this.customComponent = this.transform.root.GetComponentInChildren(type);
					if(this.customComponent == null && this.settings.compAdd)
					{
						this.customComponent = this.gameObject.AddComponent(type);
					}
				}
				if(this.customComponent != null)
				{
					if(this.settings.compSpeedMethod != "")
					{
						this.customSpeedMethod = this.customComponent.GetType().GetMethod(
							this.settings.compSpeedMethod, new System.Type[] {typeof(float)});
					}
					if(this.settings.compPositionMethod != "")
					{
						this.customPositionMethod = this.customComponent.GetType().GetMethod(
							this.settings.compPositionMethod, new System.Type[] {typeof(Vector3)});
					}
					if(this.settings.compStopMethod != "")
					{
						this.customStopMethod = this.customComponent.GetType().GetMethod(
							this.settings.compStopMethod, new System.Type[] {});
					}
				}
			}
		}
		
		
		/*
		============================================================================
		Idle functions
		============================================================================
		*/
		private void PerformIdle()
		{
			this.Stop();
			this.mode = MoveAIMode.Idle;
			ORKMoveEvent eventAsset = this.settings.GetIdleEvent(ref this.idleEventIndex);
			if(eventAsset != null)
			{
				List<GameObject> tmp = new List<GameObject>();
				tmp.Add(this.combatant.GameObject);
				this.idleMoveEvent = new MoveEvent(tmp);
				this.idleMoveEvent.SetData(eventAsset.GetData().ToDataObject());
				this.idleMoveEvent.StartEvent(this, this.combatant.GameObject);
			}
			else
			{
				this.EventEnded();
			}
		}
		
		private void StopIdle()
		{
			if(this.idleMoveEvent != null && !this.idleMoveEvent.Stopping)
			{
				this.idleMoveEvent.StopEvent();
			}
		}
		
		public void EventEnded()
		{
			this.idleMoveEvent = null;
			this.NextWaypoint();
		}
		
		public void DontDestroy()
		{
		
		}
		
		public GameObject GameObject
		{
			get{ return this.gameObject;}
		}
		
		
		/*
		============================================================================
		Waypoint functions
		============================================================================
		*/
		public void SetWaypoints(GameObject[] wp, bool randomOrder)
		{
			this.waypoint = new List<Vector3>();
			for(int i=0; i<wp.Length; i++)
			{
				if(wp[i] != null)
				{
					this.waypoint.Add(wp[i].transform.position);
				}
			}
			this.waypointIndex = -1;
			this.useRandomWaypoints = false;
			this.waypointRandomOrder = randomOrder;
			
			this.NextWaypoint();
		}
		
		private void CheckNextWaypoint()
		{
			if(this.waypoint.Count > 0)
			{
				if(VectorHelper.Distance(this.transform.position, this.waypoint[this.waypointIndex], true) - 
					(this.settings.waypointIgnoreRadius ? 0 : this.combatant.BoxRadius) <= this.settings.waypointStopDistance || 
					this.combatant.Component.LastMoveTime + this.settings.waypointResetTime < Time.time)
				{
					this.PerformIdle();
				}
			}
			else if(this.settings.randomPatrol)
			{
				this.useRandomWaypoints = true;
				this.NextWaypoint();
			}
		}
		
		private void NextWaypoint()
		{
			if(!this.settings.followLeader || !this.settings.leaderNoWaypoint || this.combatant.IsLeader)
			{
				if(this.useRandomWaypoints && this.settings.randomPatrol)
				{
					this.RandomWaypoint();
				}
				else if(this.waypointRandomOrder)
				{
					this.waypointIndex = Random.Range(0, this.waypoint.Count);
				}
				else
				{
					this.waypointIndex++;
				}
				
				if(this.waypointIndex >= this.waypoint.Count || 
					this.waypointIndex < 0)
				{
					this.waypointIndex = 0;
				}
				
				if(this.waypoint.Count > 0)
				{
					this.SetMode(MoveAIMode.Waypoint);
					this.SetMovePosition(this.waypoint[this.waypointIndex]);
					this.combatant.Component.LastMoveTime = Time.time;
				}
			}
		}
		
		private void RandomWaypoint()
		{
			this.useRandomWaypoints = true;
			
			while(true)
			{
				Vector3 next = this.settings.patrolFromCurrent ? this.transform.position : this.startPosition;
				next.x += Random.Range(-this.settings.patrolRadius, this.settings.patrolRadius);
				next.z += Random.Range(-this.settings.patrolRadius, this.settings.patrolRadius);
				
				if(!ORK.Game.Scene.WithinNoRandomPatrol(next))
				{
					this.waypoint.Clear();
					this.waypoint.Add(next);
					this.waypointIndex = 0;
					return;
				}
			}
		}
	}
}
