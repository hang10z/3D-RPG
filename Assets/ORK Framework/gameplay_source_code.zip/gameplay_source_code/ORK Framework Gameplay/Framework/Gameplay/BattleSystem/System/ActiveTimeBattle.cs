
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActiveTimeBattle : BaseBattle
	{
		[ORKEditorHelp("Time Calculation", "Select the formula used to calculate the value " +
			"that is added to the timebar every tick.\n" +
			"It determines how quickly the timebar of a combatant is filled.", "")]
		[ORKEditorInfo("Active Time Settings", "Settings for the active time battle system.\n" +
			"A combatant will perform actions when his timebar is filled.", "", 
			isPopup=true, popupType=ORKDataType.Formula)]
		public int timeFormulaID = 0;
		
		[ORKEditorHelp("Initial Value (Time)", "The initial value passed to the time formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueTime = 0;
		
		[ORKEditorHelp("Start Calculation", "Select the formula is used to calculate the value " +
			"a combatant's timebar will have at the start of a battle.", "")]
		[ORKEditorInfo(ORKDataType.Formula)]
		public int startFormulaID = 0;
		
		[ORKEditorHelp("Initial Value (Start)", "The initial value passed to the start formula.\n" +
			"The formula will use the initial value as it's base and start the calculation with that value.", "")]
		public float initialValueStart = 0;
		
		
		// timebar borders
		[ORKEditorHelp("Menu Border", "The value the timebar must reach to show the battle menu of a combatant.\n" +
			"Once the timebar reaches this value, the battle menu is called.", "")]
		[ORKEditorInfo(separator=true, labelText="Timebar Settings")]
		[ORKEditorLimit(0.0f, false)]
		public float menuBorder = 1000;
		
		[ORKEditorHelp("Action Border", "The value the timebar must reach to allow performing battle actions.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float actionBorder = 1000;
		
		[ORKEditorHelp("Maximum Timebar", "The maximum value the timebar can reach.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float maxTimebar = 1000;
		
		[ORKEditorHelp("Tick Interval (s)", "The time in seconds between two ticks.\n" +
			"The timebar is filled using the time calculation formula each tick.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float tickInterval = 0.05f;
		
		[ORKEditorHelp("Pause On Menu", "The battle time (filling the timebar) is paused while displaying the battle menu " +
			"(i.e. the battle pauses while you select your actions).", "")]
		public bool menuPause = true;
		
		[ORKEditorHelp("Pause On Action", "The battle time (filling the timebar) is paused while actions are performed " +
			"(i.e. the battle pauses while combatant's attack, use abilities, etc.).", "")]
		public bool actionPause = false;
		
		
		// timebar use
		[ORKEditorHelp("Item End Turn", "Using an item will end the turn of a combantant (i.e. set the timebar to zero).\n" +
			"If disabled, you can define the value that will be subtracted from a combatant's timebar after using an item.", "")]
		[ORKEditorInfo(separator=true, labelText="Timebar Use Settings")]
		public bool itemEndTurn = true;
		
		[ORKEditorHelp("Timebar Use", "The timebar will be reduced by this value when using an item.", "")]
		[ORKEditorLayout("itemEndTurn", false, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float itemTimebarUse = 1000;
		
		[ORKEditorHelp("Defend End Turn", "Using the defend command will end the turn of a combantant (i.e. set the timebar to zero).\n" +
			"If disabled, you can define the value that will be subtracted from a combatant's timebar after using defend.", "")]
		[ORKEditorInfo(separator=true)]
		public bool defendEndTurn = true;
		
		[ORKEditorHelp("Timebar Use", "The timebar will be reduced by this value when using the defend command.", "")]
		[ORKEditorLayout("defendEndTurn", false, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float defendTimebarUse = 1000;
		
		[ORKEditorHelp("Escape End Turn", "Using the escape command will end the turn of a combantant (i.e. set the timebar to zero).\n" +
			"If disabled, you can define the value that will be subtracted from a combatant's timebar after using escape.", "")]
		[ORKEditorInfo(separator=true)]
		public bool escapeEndTurn = true;
		
		[ORKEditorHelp("Timebar Use", "The timebar will be reduced by this value when using the escape command.", "")]
		[ORKEditorLayout("escapeEndTurn", false, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float escapeTimebarUse = 1000;
		
		[ORKEditorHelp("None End Turn", "Using the none command (doing nothing) will end the turn of a combantant (i.e. set the timebar to zero).\n" +
			"If disabled, you can define the value that will be subtracted from a combatant's timebar after doing nothing.", "")]
		[ORKEditorInfo(separator=true)]
		public bool noneEndTurn = true;
		
		[ORKEditorHelp("Timebar Use", "The timebar will be reduced by this value when using the none command (i.e. doing nothing).", "")]
		[ORKEditorLayout("noneEndTurn", false, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float noneTimebarUse = 1000;
		
		[ORKEditorHelp("Change End Turn", "Changing a battle group member will end the turn of a combantant (i.e. set the timebar to zero).\n" +
			"If disabled, you can define the value that will be subtracted from a combatant's timebar after doing nothing.", "")]
		[ORKEditorInfo(separator=true)]
		public bool changeEndTurn = true;
		
		[ORKEditorHelp("Timebar Use", "The timebar will be reduced by this value when changing a battle group member.", "")]
		[ORKEditorLayout("changeEndTurn", false, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float changeTimebarUse = 1000;
		
		
		// multi choice
		[ORKEditorHelp("Use Multi Choice", "The combatants can select multiple actions before using them.", "")]
		[ORKEditorInfo(separator=true, labelText="Multi Choice Settings")]
		public bool multiChoice = false;
		
		[ORKEditorHelp("Use All Actions", "All selected battle actions of a combatant will be used consecutively.\n" +
			"A combatant can only select new actions after all previous actions have been used.", "")]
		[ORKEditorLayout("multiChoice", true)]
		public bool useAllActions = false;
		
		[ORKEditorHelp("Use Actions", "Select when the battle actions of a combatant are performed:\n" +
			"- Action Border: The actions will be performed when the combatant's timebar reaches the action border.\n" +
			"- Max Timebar: The actions will be performed when the combatants timebar reaches the timebar maximum.\n" +
			"- End Turn: The actions will be performed when the combatant ends his turn.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public UseTimebarAction useTimebarAction = UseTimebarAction.ActionBorder;
		
		
		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Active Time' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;
		
		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;
		
		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;
		
		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;
		
		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;
		
		// dynamic combat
		[ORKEditorHelp("Use Dynamic Combat", "Multiple actions are allowed at the same time.\n" +
			"Combatants will attack as soon as they can and wont wait for the last action to finish.\n" +
			"Please note that only camera changes from the latest battle action (battle animation) will be performed.", "")]
		public bool dynamicCombat = false;
		
		[ORKEditorHelp("Time Between Actions (s)", "The minimum time in seconds between two battle actions.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("dynamicCombat", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minTimeBetween = 0;
		
		
		// auto attack settings
		[ORKEditorHelp("Can Auto Attack", "Combatants can perform auto attacks.", "")]
		[ORKEditorInfo("Auto Attack Settings", "Set if combatants can use auto attacks in a battle of this system type.", "")]
		public bool canAutoAttack = true;
		
		[ORKEditorHelp("Menu Block Auto Atk", "A combatant's auto attack is blocked while his battle menu is opened.\n" +
			"Another combatant's menu wont block auto attacks.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("canAutoAttack", true, endCheckGroup=true)]
		public bool blockAutoAttackMenu = false;
		
		
		
		/*
		============================================================================
		Ingame variables
		============================================================================
		*/
		protected float time = 0;
	
		protected int currentTick = 0;
	
		protected bool timeRunning = false;
	
		protected bool actionCheck = false;
		
		protected bool nextCheck = false;
		
		public ActiveTimeBattle()
		{
			
		}
		
		public override bool CanCounter
		{
			get{ return this.canCounter;}
		}
		
		public override bool DeathImmediately
		{
			get{ return this.deathImmediately;}
		}
		
		public override bool EndImmediately
		{
			get{ return this.endImmediately;}
		}
		
		public override bool DefeatOnPlayerDeath
		{
			get{ return this.defeatPlayerDead;}
		}
		
		public override bool DefendFirst
		{
			get{ return this.defendFirst;}
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public override bool IsDynamicCombat()
		{
			return this.dynamicCombat;
		}
		
		public override bool MenuBlockAutoAttack
		{
			get
			{
				return this.blockAutoAttackMenu;
			}
		}
		
		public override bool CanAutoAttack
		{
			get
			{
				return this.canAutoAttack;
			}
		}
		
		
		/*
		============================================================================
		Start functions
		============================================================================
		*/
		public override void StartBattle(bool changed)
		{
			base.StartBattle(changed);
			this.actionCheck = false;
			this.nextCheck = false;
			this.timeRunning = true;
		}
		
		
		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public bool CanTick
		{
			get
			{
				return (!this.menuPause || !this.nextCheck) && 
					(!this.actionPause || !ORK.Battle.Actions.HasActive());
			}
		}
		
		public override void Tick()
		{
			if(this.timeRunning)
			{
				time += ORK.Game.DeltaBattleTime;
				if(time > this.tickInterval)
				{
					time -= this.tickInterval;
					if(this.currentTick == 0)
					{
						this.TimeTick();
					}
					else if(this.currentTick == 1)
					{
						this.ActionTick();
					}
					this.currentTick++;
					if(this.currentTick > 1)
					{
						this.currentTick = 0;
					}
				}
			}
		}
		
		public override bool DoCombatantTick()
		{
			if(this.timeRunning && !this.CanTick)
			{
				return false;
			}
			return base.DoCombatantTick();
		}
		
		public override void BattleMenuFinished()
		{
			this.nextCheck = false;
		}
		
		public override void BattleMenuCanceled(Combatant user)
		{
			this.nextCheck = false;
		}
		
		protected void TimeTick()
		{
			if(!ORK.Game.Paused && !ORK.Battle.BattleEnd && 
				this.CanTick && !ORK.Battle.WaitForLastAction)
			{
				this.TickGroup(ORK.Game.Combatants.Get(true, Consider.No, Consider.Yes));
			}
		}
		
		protected void TickGroup(List<Combatant> group)
		{
			for(int i=0; i<group.Count; i++)
			{
				group[i].CheckDeath();
				if(!group[i].Dead && !group[i].Status.StopMove && 
					!group[i].Actions.FinishAttackQueue)
				{
					if(group[i].TimeBar < this.maxTimebar)
					{
						group[i].TimeBar += ORK.Formulas.Get(this.timeFormulaID).Calculate(this.initialValueTime, group[i], group[i]);
					}
					
					if(group[i].TimeBar > this.maxTimebar)
					{
						group[i].TimeBar = this.maxTimebar;
					}
					
					if(group[i].TimeBar >= this.menuBorder && 
					   group[i].Actions.CanChoose)
					{
						if(this.IsGroupAuto(group[i]))
						{
							group[i].Actions.ChooseAuto();
						}
						else
						{
							if(group[i].IsPlayerControlled() && 
								!group[i].IsAIControlled())
							{
								this.nextCheck = true;
							}
							group[i].Actions.Choose();
						}
					}
					else if(!group[i].Actions.IsChoosing && !group[i].TurnEnded && 
						group[i].UsedTimeBar >= this.maxTimebar)
					{
						group[i].EndTurn();
					}
				}
			}
		}
		
		protected void ActionTick()
		{
			if(!ORK.Game.Paused && !ORK.Battle.BattleEnd && 
				(this.dynamicCombat || !this.actionCheck))
			{
				this.PerformNextAction();
			}
		}
		
		
		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					this.actionCheck = true;
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null)
					{
						if(this.useAllActions && !action.IsType(ActionType.Death) && !action.IsType(ActionType.CounterAttack))
						{
							action.user.Actions.FinishAttackQueue = true;
						}
						if(!action.IsCastingAbility())
						{
							this.PerformAction(action);
						}
						else
						{
							this.PerformAction(null);
						}
					}
					else
					{
						this.PerformAction(null);
					}
				}
			}
		}
		
		public override void PerformingAction(BaseAction action)
		{
			if(this.dynamicCombat)
			{
				if(this.minTimeBetween > 0)
				{
					ORK.StartCoroutine(this.ActionFinished2(action));
				}
				else
				{
					this.ActionFinished(action);
				}
			}
		}
		
		public IEnumerator ActionFinished2(BaseAction action)
		{
			yield return new WaitForSeconds(this.minTimeBetween);
			this.ActionFinished(action);
		}
		
		public override void ActionFinished(BaseAction action)
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					this.PerformNextAction();
				}
				else
				{
					this.actionCheck = false;
				}
			}
		}
		
		
		/*
		============================================================================
		Battle end functions
		============================================================================
		*/
		public override void EndBattle()
		{
			this.timeRunning = false;
		}
	}
}
