
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FieldMode : BaseData
	{
		// block player control settings
		[ORKEditorHelp("Block Player Control", "The player's control will be blocked while he performs an action in the field.", "")]
		[ORKEditorInfo("Field Mode Settings", "Settings for the field mode (i.e. outside of battles).", "", 
			labelText="Player Control Block")]
		public bool blockPlayerControl = false;
		
		[ORKEditorHelp("Block in Battle Menu", "Block the player control while displaying a battle menu (e.g. target selection).", "")]
		public bool playerBattleMenu = false;
		
		
		// block camera control settings
		[ORKEditorHelp("Block Camera Control", "The camera control will be blocked while the player performs an action in the field.", "")]
		[ORKEditorInfo(separator=true, labelText="Camera Control Block")]
		public bool blockCameraControl = false;
		
		[ORKEditorHelp("Block in Battle Menu", "Block the camera control while displaying a battle menu.", "")]
		public bool cameraBattleMenu = false;
		
		
		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in the field.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Options")]
		public bool canCounter = true;
		
		public FieldMode()
		{
			
		}
	}
}
