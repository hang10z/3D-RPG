
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class JoinBattleAction : BaseAction
	{
		public JoinBattleAction(Combatant user)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);
		}
		
		public override bool IsType(ActionType t)
		{
			return ActionType.Join.Equals(t);
		}
		
		
		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null;
		}
		
		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.joinBattleInfo.Show(this.user, "");
			}
			
			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleJoinBattle)
				{
					this.user.Setting.consoleJoinBattle.Print(this.user, this.target, null);
				}
				else
				{
					ORK.ConsoleSettings.actionJoinBattle.Print(this.user, this.target, null);
				}
			}
			
			this.user.GetJoinBattleEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate)
		{
			
		}

		protected override void ActionEndSetup()
		{
			
		}
	}
}
