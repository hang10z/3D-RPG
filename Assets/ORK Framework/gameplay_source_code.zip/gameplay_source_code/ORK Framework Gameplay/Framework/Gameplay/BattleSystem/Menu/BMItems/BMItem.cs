
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public abstract class BMItem
	{
		public ChoiceContent content;
		
		public virtual void CreateDrag(Combatant owner)
		{
			
		}
		
		public virtual bool ActiveCheck(Combatant owner)
		{
			return false;
		}
		
		public abstract void Selected(Combatant owner);
		
		
		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public virtual void Blink(Combatant owner, bool doBlink)
		{
			
		}
		
		public virtual bool Contains(Combatant owner, Combatant target)
		{
			return false;
		}
		
		public virtual bool ContainsAny(Combatant owner, List<Combatant> list)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		public virtual bool ChangeUseLevel(int change, Combatant owner)
		{
			return false;
		}
	}
}
