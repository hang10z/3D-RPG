
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SavePointChoice : BaseData, IChoice
	{
		[ORKEditorHelp("GUI Box", "The GUI box used to display the save point dialogue.", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		public int guiBoxID = 0;
		
		
		// title
		[ORKEditorHelp("Show Title", "Display a title in the name box of the used GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useTitle = false;
		
		[ORKEditorHelp("Title", "The title of the box.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorLayout("useTitle",true, endCheckGroup=true, autoInit=true, autoLangSize=true)]
		public string[] title;
		
		
		// message
		[ORKEditorHelp("Text", "The text displayed in the save point dialogue.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, labelText="Save Point Text")]
		[ORKEditorArray(isDataLabel=true, dataType=ORKDataType.Language)]
		public string[] message = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// save button
		[ORKEditorHelp("Show Save", "A save option is available in the save point dialogue.", "")]
		[ORKEditorInfo("Save Button", "The save button will open the save game menu.", "", 
			separatorForce=true)]
		public bool showSave = true;
		
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showSave", true, endCheckGroup=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] saveButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Save"});
		
		
		// load button
		[ORKEditorHelp("Show Load", "A load option is available in the save point dialogue.", "")]
		[ORKEditorInfo("Load Button", "The load button will open the load game menu.", "", 
			separatorForce=true)]
		public bool showLoad = true;
		
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showLoad", true, endCheckGroup=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] loadButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Load"});
		
		
		// cancel button
		[ORKEditorHelp("Show Cancel", "A cancel option is available in the save point dialogue.", "")]
		[ORKEditorInfo("Cancel Button", "The cancel button will close the save point menu.", "", 
			separatorForce=true)]
		public bool showCancel = true;
		
		[ORKEditorHelp("First Button", "The cancel button will be the first in the list.\n" +
			"If disabled, the cancel button is the last button.", "")]
		[ORKEditorLayout("showCancel", true)]
		public bool cancelFirst = false;
		
		[ORKEditorHelp("Own Button Content", "Override the default 'Cancel' button content (defined in 'Menu/Shop Settings').\n" +
			"If disabled, the default 'Cancel' button will be used.", "")]
		public bool ownCancelButton = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCancelButton", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageContent[] cancelButton = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Cancel"});
		
		
		// bg image
		[ORKEditorHelp("Own Background", "Override the default save menu background image settings.", "")]
		[ORKEditorInfo(separator=true, labelText="Background Image")]
		public bool ownBG = false;
		
		[ORKEditorLayout("ownBG", true, endCheckGroup=true, autoInit=true)]
		[ORKEditorArray(false, "Add Background", "Adds a background image.", "", 
			"Remove", "Removes this background image.", "", foldout=true, 
			foldoutText=new string[] {"Background Image", "Define the background image that will be displayed.", ""})]
		public BackgroundImage[] background;
		
		
		// ingame
		private GUIBox[] bgBox;
		
		private GUIBox box;
		
		private int current = -1;
		
		private ChoiceContent[] choices;

		private int[] choiceActions;
		
		private static int SAVE = 0;
		
		private static int LOAD = 1;
		
		private static int CANCEL = 2;
		
		private IEventStarter starter;
		
		public SavePointChoice()
		{
			
		}
		
		public bool Tick(GUIBox origin)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ok/cancel button functions
		============================================================================
		*/
		public bool ShowOKButton(GUIBox origin)
		{
			return false;
		}
		
		public bool ShowCancelButton(GUIBox origin)
		{
			return false;
		}
		
		public bool IsOKButtonActive(GUIBox origin)
		{
			return true;
		}
		
		public bool IsCancelButtonActive(GUIBox origin)
		{
			return true;
		}
		
		
		/*
		============================================================================
		Background functions
		============================================================================
		*/
		private void ShowBackground()
		{
			ORK.Menu.ShowGeneralSaveBG();
			
			if(this.ownBG && this.background != null && this.background.Length > 0)
			{
				this.bgBox = new GUIBox[this.background.Length];
				for(int i=0; i<this.bgBox.Length; i++)
				{
					this.bgBox[i] = this.background[i].Init();
				}
			}
			else if(!this.ownBG && ORK.MenuSettings.defaultSaveBG.Length > 0)
			{
				this.bgBox = new GUIBox[ORK.MenuSettings.defaultSaveBG.Length];
				for(int i=0; i<this.bgBox.Length; i++)
				{
					this.bgBox[i] = ORK.MenuSettings.defaultSaveBG[i].Init();
				}
			}
		}
		
		private void CloseBackground()
		{
			if(this.bgBox != null)
			{
				for(int i=0; i<this.bgBox.Length; i++)
				{
					if(this.bgBox[i] != null)
					{
						this.bgBox[i].InitOut();
						this.bgBox[i] = null;
					}
				}
				this.bgBox = null;
			}
		}
		
		
		/*
		============================================================================
		Display functions
		============================================================================
		*/
		public void Show(IEventStarter starter)
		{
			this.starter = starter;
			this.Show();
		}
		
		public void Show()
		{
			this.ShowBackground();
			
			this.box = ORK.GUIBoxes.Create(this.guiBoxID);
			this.CreateChoices();
			this.box.Content = new DialogueContent(this.message[ORK.Game.Language], 
				this.useTitle ? this.title[ORK.Game.Language] : "", this.choices, this);
			this.box.InitIn();
			ORK.GUI.FocusBlocked = true;
		}
		
		public void FocusGained(GUIBox origin)
		{
			
		}
		
		public void FocusLost(GUIBox origin)
		{
			
		}
		
		public void Closed(GUIBox origin)
		{
			this.box = null;
			if(this.current == SavePointChoice.SAVE)
			{
				ORK.SaveGameMenu.saveMenu.Show(this, this.starter);
			}
			else if(this.current == SavePointChoice.LOAD)
			{
				ORK.SaveGameMenu.loadMenu.Show(this, this.starter);
			}
			else if(ComponentHelper.IsAlive(this.starter))
			{
				this.starter.EventEnded();
			}
			
			this.CloseBackground();
			ORK.Menu.CloseGeneralSaveBG();
		}
		
		
		/*
		============================================================================
		Choice handling functions
		============================================================================
		*/
		public void CreateChoices()
		{
			List<ChoiceContent> cc = new List<ChoiceContent>();
			List<int> ca = new List<int>();
			
			if(this.showSave)
			{
				cc.Add(new ChoiceContent(this.saveButton[ORK.Game.Language].GetContent()));
				ca.Add(SavePointChoice.SAVE);
			}
			
			if(this.showLoad)
			{
				cc.Add(new ChoiceContent(this.loadButton[ORK.Game.Language].GetContent(),
					ORK.SaveGame.FileExists()));
				ca.Add(SavePointChoice.LOAD);
			}
			
			if(this.showCancel)
			{
				if(this.cancelFirst)
				{
					if(this.ownCancelButton)
					{
						cc.Insert(0, new ChoiceContent(this.cancelButton[ORK.Game.Language].GetContent(),
							ORK.SaveGame.FileExists()));
					}
					else
					{
						cc.Insert(0, new ChoiceContent(ORK.MenuSettings.GetCancelContent()));
					}
					ca.Insert(0, SavePointChoice.CANCEL);
				}
				else
				{
					if(this.ownCancelButton)
					{
						cc.Add(new ChoiceContent(this.cancelButton[ORK.Game.Language].GetContent(),
							ORK.SaveGame.FileExists()));
					}
					else
					{
						cc.Add(new ChoiceContent(ORK.MenuSettings.GetCancelContent()));
					}
					ca.Add(SavePointChoice.CANCEL);
				}
			}
			
			this.choices = cc.ToArray();
			this.choiceActions = ca.ToArray();
		}
		
		public void ChoiceSelected(int index, GUIBox origin)
		{
			this.current = this.choiceActions[index];
			
			this.box.InitOut();
			this.CloseBackground();
		}
		
		public void SelectionChanged(int index, GUIBox origin)
		{
			
		}
		
		public void Canceled(GUIBox origin)
		{
			origin.Audio.PlayCancel();
			this.current = SavePointChoice.CANCEL;
			
			this.box.InitOut();
			this.CloseBackground();
		}
	}
}
