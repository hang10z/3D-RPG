
using UnityEngine;
using ORKFramework.Behaviours;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBox
	{
		private GUIBoxSetting settings;
		
		
		// tick in pause?
		public bool inPause = false;
		
		public bool forceSize = false;
		
		public bool useFullScreen = false;
		
		
		// positions
		public Rect bounds = new Rect(0, 0, 1280, 800);
		
		public Rect nameBounds = new Rect(0, 0, 150, 50);
		
		public Rect windowRect = new Rect(0, 0, 100, 100);

		private Vector2 moveInStart = Vector2.zero;

		private Vector2 moveOutEnd = Vector2.zero;

		private Vector2 currentPos = Vector2.zero;

		public Vector2 nameOffset = Vector2.zero;
		
		private Vector2 baseOffset = Vector2.zero;
		
		private GameObject atObject = null;
		
		private Renderer renderer = null;
		
		private GUIBox relativeToBox = null;
		
		private TextAnchor relativeToBoxAnchor = TextAnchor.UpperLeft;
		
		
		// fading
		public Color color = new Color(1, 1, 1, 1);
		
		public Color lastColor = new Color(1, 1, 1, 1);
		
		private Color colStart = new Color(1, 1, 1, 1);
		
		public bool doFlash = false;
		
		public Color flashColor;

		private float fadeTime = 0;

		private bool fadeInDone = false;

		private bool fadeOutDone = false;
		
		private bool isFading = false;
		
		private bool delayFade = false;
		
		
		// moving
		private Function interpolateMIn;

		private Function interpolateMOut;

		private float moveTime = 0;
		
		private float moveTimeMax = 0;

		private bool moveInDone = false;

		private bool moveOutDone = false;

		private Vector2 mDistance = Vector2.zero;

		private bool isMoving = false;
		
		private bool delayMove = false;
		
		
		// scaling
		private Function interpolateSIn;

		private Function interpolateSOut;
		
		private float scaleTime = 0;
		
		private float scaleTimeMax = 0;

		private bool scaleInDone = false;

		private bool scaleOutDone = false;
		
		public Vector2 currentScale = Vector2.one;
		
		private Vector2 distanceScale = Vector2.one;
		
		public TextAnchor scaleAnchor = TextAnchor.UpperLeft;

		private bool isScaling = false;
		
		private bool delayScale = false;
		
		
		// content
		private GUIBoxContent content;
		
		public bool controlable = true;
		
		public bool focusable = true;
		
		public bool disableChoice = false;
		
		public bool blocked = false;
		
		public bool hidden = false;
		
		private bool registered = false;
		
		
		// unfocused selection
		private int choiceDown = -1;
		
		
		// auto close
		private bool autoClose = false;
		
		private float closeAfter = 0;
		
		
		// new UI
		public GUIBoxComponent uiComponent;
		
		public GameObject gameObject;
		
		public GUIBox(GUIBoxSetting s)
		{
			this.settings = s;
			
			this.bounds = this.settings.boxBounds;
			this.nameBounds = this.settings.nameBounds;
			this.windowRect = this.bounds;
			
			if(this.settings.openBoxBehaviour.moveRelative)
			{
				this.moveInStart = new Vector2(
					this.bounds.x + this.settings.openBoxBehaviour.movePosition.x, 
					this.bounds.y + this.settings.openBoxBehaviour.movePosition.y);
			}
			else
			{
				this.moveInStart = this.settings.openBoxBehaviour.movePosition;
			}
			
			if(this.settings.closeBoxBehaviour.moveRelative)
			{
				this.moveOutEnd = new Vector2(
					this.bounds.x + this.settings.closeBoxBehaviour.movePosition.x, 
					this.bounds.y + this.settings.closeBoxBehaviour.movePosition.y);
			}
			else
			{
				this.moveOutEnd = this.settings.closeBoxBehaviour.movePosition;
			}
			
			this.currentPos = new Vector2(this.bounds.x, this.bounds.y);
			this.useFullScreen = ORK.GUILayers.Get(this.settings.layerID).useFullScreen;
			
			if(this.settings.nameRelative)
			{
				this.nameOffset = new Vector2(this.settings.nameBounds.x, this.settings.nameBounds.y);
			}
			else
			{
				this.nameOffset = new Vector2(this.settings.nameBounds.x - this.bounds.x, this.settings.nameBounds.y - this.bounds.y);
			}
		}
		
		public GUIBoxSetting Settings
		{
			get{ return this.settings;}
		}
		
		public MenuAudioClips Audio
		{
			get
			{
				if(this.settings.ownAudio && this.settings.audio != null)
				{
					return this.settings.audio;
				}
				else
				{
					return ORK.MenuSettings.audio;
				}
			}
		}
		
		public GUIBoxSkins Skins
		{
			get
			{
				if(this.settings.ownSkins && this.settings.skins != null)
				{
					return this.settings.skins;
				}
				else
				{
					return ORK.MenuSettings.skins;
				}
			}
		}
		
		public ChoiceIconSettings ChoiceIcon
		{
			get
			{
				if(this.settings.ownChoiceIcon && this.settings.choiceIcon != null)
				{
					return this.settings.choiceIcon;
				}
				else
				{
					return ORK.MenuSettings.choiceIcon;
				}
			}
		}
		
		public HeaderSettings Headers
		{
			get
			{
				if(this.settings.ownHeaders && this.settings.headerSettings != null)
				{
					return this.settings.headerSettings;
				}
				else
				{
					return ORK.MenuSettings.headerSettings;
				}
			}
		}
		
		
		/*
		============================================================================
		Window and focus functions
		============================================================================
		*/
		public void SetFocus()
		{
			if(this.controlable && this.focusable)
			{
				ORK.GUI.Focus = this;
			}
		}
		
		public bool Focused
		{
			get
			{
				return this.controlable && 
					this.focusable && ORK.GUI.Focus == this;
			}
		}
		
		
		/*
		============================================================================
		Base position functions
		============================================================================
		*/
		public GameObject AtObject
		{
			get{ return this.atObject;}
			set
			{
				this.atObject = value;
				if(this.atObject != null)
				{
					this.renderer = this.atObject.transform.root.GetComponentInChildren<Renderer>();
				}
			}
		}
		
		public void SetRelativeTo(GUIBox box, TextAnchor anchor)
		{
			this.relativeToBox = box;
			this.relativeToBoxAnchor = anchor;
		}
		
		public void SetBaseToCursor()
		{
			Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
			this.SetBasePosition(pos.x, pos.y);
		}
		
		public void SetBasePosition(float newX, float newY)
		{
			if(this.settings.limitToScreen)
			{
				Rect tmp = new Rect(newX, newY, this.bounds.width, this.bounds.height);
				GUIHelper.GetRectAnchor(ref tmp, -tmp.width, -tmp.height, this.settings.boxAnchor);
				ValueHelper.RectAddPadding(ref tmp, this.settings.screenPadding);
				ORK.GameSettings.CheckDragWindowPosition(ref tmp);
				ValueHelper.RectRemovePadding(ref tmp, this.settings.screenPadding);
				GUIHelper.GetRectAnchorReverse(ref tmp, -tmp.width, -tmp.height, this.settings.boxAnchor);
				newX = tmp.x;
				newY = tmp.y;
			}
			if(this.bounds.x != newX || this.bounds.y != newY)
			{
				if(this.settings.openBoxBehaviour.useMove)
				{
					this.moveInStart.x = newX - (this.bounds.x - this.moveInStart.x);
					this.moveInStart.y = newY - (this.bounds.y - this.moveInStart.y);
					if(!this.moveInDone)
					{
						this.mDistance.x = newX - this.moveInStart.x;
						this.mDistance.y = newY - this.moveInStart.y;
					}
				}
				if(this.settings.closeBoxBehaviour.useMove)
				{
					this.moveOutEnd.x = newX - (this.bounds.x - this.moveOutEnd.x);
					this.moveOutEnd.y = newY - (this.bounds.y - this.moveOutEnd.y);
				}
				this.currentPos.x += newX - this.bounds.x;
				this.currentPos.y += newY - this.bounds.y;
				this.bounds.x = newX;
				this.bounds.y = newY;
			}
		}
		
		public void MoveBasePosition(Vector2 change)
		{
			if(change.x != 0 || change.y != 0)
			{
				if(ORK.GameSettings.secureWindowDrag)
				{
					Rect tmp = new Rect(this.currentPos.x + change.x + this.baseOffset.x, 
						this.currentPos.y + change.y + this.baseOffset.y, 
						this.bounds.width, this.bounds.height);
					GUIHelper.GetRectAnchor(ref tmp, -tmp.width, -tmp.height, this.settings.boxAnchor);
					ORK.GameSettings.CheckDragWindowPosition(ref tmp);
					GUIHelper.GetRectAnchorReverse(ref tmp, -tmp.width, -tmp.height, this.settings.boxAnchor);
					this.SetBasePosition(tmp.x - this.baseOffset.x, tmp.y - this.baseOffset.y);
				}
				else
				{
					this.SetBasePosition(this.currentPos.x + change.x, this.currentPos.y + change.y);
				}
			}
		}
		
		public Vector2 BaseOffset
		{
			get{ return this.baseOffset;}
			set{ this.baseOffset = value;}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public void InitIn()
		{
			this.fadeOutDone = false;
			this.moveOutDone = false;
			this.scaleOutDone = false;
			this.isFading = false;
			this.isMoving = false;
			this.isScaling = false;
			this.fadeInDone = true;
			this.moveInDone = true;
			this.scaleInDone = true;
			this.delayFade = false;
			this.delayMove = false;
			this.delayScale = false;
			
			// display at cursor position
			if(this.settings.atCursor)
			{
				this.SetBaseToCursor();
			}
			
			if(this.settings.openBoxBehaviour.useFade && !this.hidden)
			{
				this.fadeTime = 0;
				this.colStart = this.color;
				this.settings.openBoxBehaviour.fade.GetStart(ref this.colStart);
				this.color = this.colStart;
				this.isFading = true;
				this.fadeInDone = false;
				this.delayFade = this.settings.openBoxBehaviour.fadeDelay > 0;
			}
			
			if(this.settings.openBoxBehaviour.useMove && !this.hidden)
			{
				this.moveTime = 0;
				
				if(this.settings.openBoxBehaviour.useMoveCurve)
				{
					this.currentPos = new Vector2(
						this.settings.openBoxBehaviour.moveCurveX != null && 
							this.settings.openBoxBehaviour.moveCurveX.length > 0 ? 
								this.settings.openBoxBehaviour.moveCurveX.Evaluate(0) : 
								(this.settings.openBoxBehaviour.moveRelative ? 0 : this.bounds.x), 
						this.settings.openBoxBehaviour.moveCurveY != null && 
							this.settings.openBoxBehaviour.moveCurveY.length > 0 ? 
								this.settings.openBoxBehaviour.moveCurveY.Evaluate(0) : 
								(this.settings.openBoxBehaviour.moveRelative ? 0 : this.bounds.y));
					if(this.settings.openBoxBehaviour.moveRelative)
					{
						this.currentPos.x += this.bounds.x;
						this.currentPos.y += this.bounds.y;
					}
					
					this.moveTimeMax = Mathf.Max(
						ValueHelper.GetCurveDuration(this.settings.openBoxBehaviour.moveCurveX), 
						ValueHelper.GetCurveDuration(this.settings.openBoxBehaviour.moveCurveY));
				}
				else
				{
					this.moveTimeMax = this.settings.openBoxBehaviour.moveTime;
					this.interpolateMIn = Interpolate.Ease(this.settings.openBoxBehaviour.moveInterpolation);
					this.mDistance.x = this.bounds.x - this.moveInStart.x;
					this.mDistance.y = this.bounds.y - this.moveInStart.y;
					this.currentPos = new Vector2(this.moveInStart.x, this.moveInStart.y);
				}
				
				this.isMoving = true;
				this.moveInDone = false;
				this.delayMove = this.settings.openBoxBehaviour.moveDelay > 0;
			}
			else
			{
				this.currentPos = new Vector2(this.bounds.x, this.bounds.y);
			}
			
			if(this.settings.openBoxBehaviour.useScale)
			{
				this.scaleTime = 0;
				
				if(this.settings.openBoxBehaviour.useScaleCurve)
				{
					this.currentScale = new Vector2(
						this.settings.openBoxBehaviour.scaleCurveX != null && 
							this.settings.openBoxBehaviour.scaleCurveX.length > 0 ? 
								this.settings.openBoxBehaviour.scaleCurveX.Evaluate(0) : 1, 
						this.settings.openBoxBehaviour.scaleCurveY != null && 
							this.settings.openBoxBehaviour.scaleCurveY.length > 0 ? 
								this.settings.openBoxBehaviour.scaleCurveY.Evaluate(0) : 1);
					
					this.scaleTimeMax = Mathf.Max(
						ValueHelper.GetCurveDuration(this.settings.openBoxBehaviour.scaleCurveX), 
						ValueHelper.GetCurveDuration(this.settings.openBoxBehaviour.scaleCurveY));
				}
				else
				{
					this.scaleTimeMax = this.settings.openBoxBehaviour.scaleTime;
					this.interpolateSIn = Interpolate.Ease(this.settings.openBoxBehaviour.scaleInterpolation);
					this.currentScale = this.settings.openBoxBehaviour.scale;
					this.distanceScale = Vector2.one - this.currentScale;
				}
				
				this.scaleAnchor = this.settings.openBoxBehaviour.scaleAnchor;
				this.isScaling = true;
				this.scaleInDone = false;
				this.delayScale = this.settings.openBoxBehaviour.scaleDelay > 0;
			}
			else
			{
				this.currentScale = Vector2.one;
			}
			
			this.windowRect.x = this.currentPos.x + this.baseOffset.x;
			this.windowRect.y = this.currentPos.y + this.baseOffset.y;
			this.windowRect.width = this.bounds.width;
			this.windowRect.height = this.bounds.height;
			
			this.Register();
		}
		
		public void InitOut()
		{
			this.autoClose = false;
			this.fadeInDone = true;
			this.moveInDone = true;
			this.scaleInDone = true;
			this.isFading = false;
			this.isMoving = false;
			this.isScaling = false;
			this.fadeOutDone = true;
			this.moveOutDone = true;
			this.scaleOutDone = true;
			this.delayMove = false;
			this.delayFade = false;
			this.delayScale = false;
			
			if(this.settings.closeBoxBehaviour.useFade && !this.hidden)
			{
				this.fadeTime = 0;
				this.colStart = this.color;
				this.settings.closeBoxBehaviour.fade.GetStart(ref this.colStart);
				this.color = colStart;
				this.isFading = true;
				this.fadeOutDone = false;
				this.delayFade = this.settings.closeBoxBehaviour.fadeDelay > 0;
			}
			
			if(this.settings.closeBoxBehaviour.useMove && !this.hidden)
			{
				this.moveTime = 0;
				
				if(this.settings.closeBoxBehaviour.useMoveCurve)
				{
					this.currentPos = new Vector2(
						this.settings.closeBoxBehaviour.moveCurveX != null && 
							this.settings.closeBoxBehaviour.moveCurveX.length > 0 ? 
								this.settings.closeBoxBehaviour.moveCurveX.Evaluate(0) : 
								(this.settings.closeBoxBehaviour.moveRelative ? 0 : this.bounds.x), 
						this.settings.closeBoxBehaviour.moveCurveY != null && 
							this.settings.closeBoxBehaviour.moveCurveY.length > 0 ? 
								this.settings.closeBoxBehaviour.moveCurveY.Evaluate(0) : 
								(this.settings.closeBoxBehaviour.moveRelative ? 0 : this.bounds.y));
					if(this.settings.closeBoxBehaviour.moveRelative)
					{
						this.currentPos.x += this.bounds.x;
						this.currentPos.y += this.bounds.y;
					}
					
					this.moveTimeMax = Mathf.Max(
						ValueHelper.GetCurveDuration(this.settings.closeBoxBehaviour.moveCurveX), 
						ValueHelper.GetCurveDuration(this.settings.closeBoxBehaviour.moveCurveY));
				}
				else
				{
					this.moveTimeMax = this.settings.closeBoxBehaviour.moveTime;
					this.interpolateMOut = Interpolate.Ease(this.settings.closeBoxBehaviour.moveInterpolation);
					this.mDistance.x = this.moveOutEnd.x - this.currentPos.x;
					this.mDistance.y = this.moveOutEnd.y - this.currentPos.y;
				}
				
				this.isMoving = true;
				this.moveOutDone = false;
				this.delayMove = this.settings.closeBoxBehaviour.moveDelay > 0;
			}
			
			if(this.settings.closeBoxBehaviour.useScale)
			{
				this.scaleTime = 0;
				
				if(this.settings.closeBoxBehaviour.useScaleCurve)
				{
					this.currentScale = new Vector2(
						this.settings.closeBoxBehaviour.scaleCurveX != null && 
							this.settings.closeBoxBehaviour.scaleCurveX.length > 0 ? 
								this.settings.closeBoxBehaviour.scaleCurveX.Evaluate(0) : 1, 
						this.settings.closeBoxBehaviour.scaleCurveY != null && 
							this.settings.closeBoxBehaviour.scaleCurveY.length > 0 ? 
								this.settings.closeBoxBehaviour.scaleCurveY.Evaluate(0) : 1);
					
					this.scaleTimeMax = Mathf.Max(
						ValueHelper.GetCurveDuration(this.settings.closeBoxBehaviour.scaleCurveX), 
						ValueHelper.GetCurveDuration(this.settings.closeBoxBehaviour.scaleCurveY));
				}
				else
				{
					this.scaleTimeMax = this.settings.closeBoxBehaviour.scaleTime;
					this.interpolateSOut = Interpolate.Ease(this.settings.closeBoxBehaviour.scaleInterpolation);
					this.currentScale = Vector2.one;
					this.distanceScale = this.settings.closeBoxBehaviour.scale - this.currentScale;
				}
				
				this.scaleAnchor = this.settings.closeBoxBehaviour.scaleAnchor;
				this.isScaling = true;
				this.scaleOutDone = false;
				this.delayScale = this.settings.closeBoxBehaviour.scaleDelay > 0;
			}
			else
			{
				this.currentScale = Vector2.one;
			}
		}
		
		public void Reset()
		{
			this.fadeTime = 0;
			this.moveTime = 0;
			this.fadeInDone = false;
			this.fadeOutDone = false;
			this.moveInDone = false;
			this.moveOutDone = false;
			this.scaleInDone = false;
			this.scaleOutDone = false;
			this.isFading = false;
			this.isMoving = false;
			this.isScaling = false;
			this.interpolateMIn = null;
			this.interpolateMOut = null;
			this.interpolateSIn = null;
			this.interpolateSOut = null;
			this.mDistance.x = 0;
			this.mDistance.y = 0;
			this.currentPos = Vector2.zero;
			this.currentScale = Vector2.one;
			
			this.color = new Color(1, 1, 1, 1);
			this.autoClose = false;
			
			if(this.content != null)
			{
				this.content.newContent = true;
			}
		}
		
		public void CloseAfter(float t, bool controlable)
		{
			float tmp = 0;
			if(this.settings.closeBoxBehaviour.useFade)
			{
				if(tmp < this.settings.closeBoxBehaviour.fade.time)
				{
					tmp = this.settings.closeBoxBehaviour.fade.time;
				}
			}
			if(this.settings.closeBoxBehaviour.useMove)
			{
				if(this.settings.closeBoxBehaviour.useMoveCurve)
				{
					float tmp2 = ValueHelper.GetCurveDuration(
						this.settings.closeBoxBehaviour.moveCurveX);
					if(tmp < tmp2)
					{
						tmp = tmp2;
					}
					tmp2 = ValueHelper.GetCurveDuration(
						this.settings.closeBoxBehaviour.moveCurveY);
					if(tmp < tmp2)
					{
						tmp = tmp2;
					}
				}
				else if(tmp < this.settings.closeBoxBehaviour.moveTime)
				{
					tmp = this.settings.closeBoxBehaviour.moveTime;
				}
			}
			if(this.settings.closeBoxBehaviour.useScale)
			{
				if(this.settings.closeBoxBehaviour.useScaleCurve)
				{
					float tmp2 = ValueHelper.GetCurveDuration(
						this.settings.closeBoxBehaviour.scaleCurveX);
					if(tmp < tmp2)
					{
						tmp = tmp2;
					}
					tmp2 = ValueHelper.GetCurveDuration(this.settings.closeBoxBehaviour.scaleCurveY);
					if(tmp < tmp2)
					{
						tmp = tmp2;
					}
				}
				else if(tmp < this.settings.closeBoxBehaviour.scaleTime)
				{
					tmp = this.settings.closeBoxBehaviour.scaleTime;
				}
			}
			this.closeAfter = t - tmp;
			this.autoClose = true;
			this.controlable = controlable;
		}
		
		
		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool IsOpened
		{
			get
			{
				return !this.blocked && 
					this.fadeInDone && this.moveInDone && this.scaleInDone && 
					!this.isFading && !this.isMoving && !this.isScaling && 
					!this.fadeOutDone && !this.moveOutDone && !this.scaleOutDone;
			}
		}
		
		public bool IsClosing
		{
			get
			{
				return this.fadeInDone && this.moveInDone && this.scaleInDone && 
					((!this.fadeOutDone && this.isFading) || 
					(!this.moveOutDone && this.isMoving) || 
					(!this.scaleOutDone && this.isScaling));
			}
		}
		
		public bool IsClosed
		{
			get
			{
				return this.fadeOutDone && this.moveOutDone && this.scaleOutDone;
			}
		}
		
		public bool Controlable
		{
			get
			{
				return !this.blocked && this.controlable && 
					this.fadeInDone && this.moveInDone && this.scaleInDone && 
					!this.isFading && !this.isMoving && !this.isScaling && 
					!this.fadeOutDone && !this.moveOutDone && !this.scaleOutDone && 
					(this.inPause || !ORK.Game.Paused);
			}
		}

		public void SetOutDone()
		{
			this.fadeOutDone = true;
			this.moveOutDone = true;
			this.scaleOutDone = true;
		}
		
		public bool IsTooltip
		{
			get
			{
				return this.content != null && 
					((this.content is PrecalcHUDContent && 
						HUDType.Tooltip.Equals(((PrecalcHUDContent)this.content).type)) || 
					this.content is DragContent);
			}
		}
		
		
		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public void Register()
		{
			if(!this.registered)
			{
				if(this.IsTooltip)
				{
					ORK.GUI.AddTooltip(this);
				}
				else
				{
					ORK.GUI.AddBox(this);
				}
				this.registered = true;
			}
		}
		
		public void Unregister()
		{
			this.registered = false;
			if(this.IsTooltip)
			{
				ORK.GUI.RemoveTooltip(this);
			}
			else
			{
				ORK.GUI.RemoveBox(this);
			}
			if(this.content != null)
			{
				this.content.Clear();
			}
			if(this.uiComponent != null)
			{
				GameObject.Destroy(this.uiComponent.gameObject);
			}
		}
		
		
		/*
		============================================================================
		Fade functions
		============================================================================
		*/
		public void Tick(float t)
		{
			if(ORK.GUI.IsNewUI && this.uiComponent != null)
			{
				if(this.blocked || this.hidden || this.content == null)
				{
					this.uiComponent.gameObject.SetActive(false);
				}
				else if(!this.uiComponent.gameObject.activeInHierarchy)
				{
					this.uiComponent.gameObject.SetActive(true);
				}
				if(this.content != null)
				{
					if(this.forceSize)
					{
						this.bounds.width = this.settings.boxBounds.width;
						this.bounds.height = this.settings.boxBounds.height;
					}
					
					this.windowRect.x = this.currentPos.x + this.baseOffset.x;
					this.windowRect.y = this.currentPos.y + this.baseOffset.y;
					
					if(this.content.newContent)
					{
						this.content.Init(this);
						this.content.CreateNewUI();
					}
					if(this.content.newName)
					{
						this.content.CalculateName();
					}
					
					this.windowRect.width = this.bounds.width;
					this.windowRect.height = this.bounds.height;
					
					GUIHelper.GetRectAnchor(ref this.windowRect, 
						-this.windowRect.width, -this.windowRect.height, 
						this.settings.boxAnchor);
					
					// name box
					this.nameBounds.x = this.windowRect.x + this.nameOffset.x;
					this.nameBounds.y = this.windowRect.y + this.nameOffset.y;
					if(!this.settings.nameRelative)
					{
						GUIHelper.GetRectAnchorReverse(ref this.nameBounds, 
							-this.windowRect.width, -this.windowRect.height, 
							this.settings.boxAnchor);
					}
				}
			}
			
			if(this.inPause || !ORK.Game.Paused)
			{
				// at object
				if(this.atObject != null)
				{
					this.blocked = this.renderer == null || !this.renderer.isVisible;
					Vector3 pos = VectorHelper.GetScreenPosition(atObject.transform.position, this.useFullScreen);
					this.SetBasePosition(pos.x, pos.y);
				}
				// relative to box
				else if(this.relativeToBox != null)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.relativeToBox.windowRect, this.relativeToBoxAnchor);
					this.SetBasePosition(tmp.x, tmp.y);
				}
				// at cursor
				else if(this.settings.atCursor && this.settings.followCursor && 
					(this.settings.followAtClose || !this.IsClosing))
				{
					this.SetBaseToCursor();
				}
				
				
				// auto close
				if(this.autoClose)
				{
					this.closeAfter -= t;
					if(this.closeAfter <= 0)
					{
						this.InitOut();
					}
				}
				
				// fade
				this.DoFade(t);
				
				// content
				if(this.content != null)
				{
					this.content.Tick();
				}
				
				// close
				if(this.fadeOutDone && this.moveOutDone && 
					this.scaleOutDone && this.registered)
				{
					this.Unregister();
					if(this.content != null)
					{
						this.content.Closed();
					}
				}
			}
		}
		
		public void DoFade(float t)
		{
			if(this.isFading)
			{
				if(!this.fadeInDone)
				{
					this.DoFadeIn(t);
				}
				else if(!this.fadeOutDone)
				{
					this.DoFadeOut(t);
				}
				else
				{
					this.isFading = false;
				}
			}
			if(this.isMoving)
			{
				if(!this.moveInDone)
				{
					this.DoMoveIn(t);
				}
				else if(!this.moveOutDone)
				{
					this.DoMoveOut(t);
				}
				else
				{
					this.isMoving = false;
				}
			}
			if(this.isScaling)
			{
				if(!this.scaleInDone)
				{
					this.DoScaleIn(t);
				}
				else if(!this.scaleOutDone)
				{
					this.DoScaleOut(t);
				}
				else
				{
					this.isScaling = false;
				}
			}
		}
		
		public void DoFadeIn(float t)
		{
			this.fadeTime += t;
			
			if(this.delayFade)
			{
				if(this.fadeTime >= this.settings.openBoxBehaviour.fadeDelay)
				{
					this.fadeTime = 0;
					this.delayFade = false;
				}
			}
			else if(this.settings.openBoxBehaviour.fade.Fade(
				ref this.color, this.colStart, this.fadeTime))
			{
				this.lastColor = this.color;
				this.isFading = false;
				this.fadeInDone = true;
			}
		}
		
		public void DoFadeOut(float t)
		{
			this.fadeTime += t;
			
			if(this.delayFade)
			{
				if(this.fadeTime >= this.settings.closeBoxBehaviour.fadeDelay)
				{
					this.fadeTime = 0;
					this.delayFade = false;
				}
			}
			else if(this.settings.closeBoxBehaviour.fade.Fade(
				ref this.color, this.colStart, this.fadeTime))
			{
				this.lastColor = this.color;
				this.isFading = false;
				this.fadeOutDone = true;
			}
		}
		
		
		/*
		============================================================================
		Move functions
		============================================================================
		*/
		public void DoMoveIn(float t)
		{
			this.moveTime += t;
			
			if(this.delayMove)
			{
				if(this.moveTime >= this.settings.openBoxBehaviour.moveDelay)
				{
					this.moveTime = 0;
					this.delayMove = false;
				}
			}
			else
			{
				if(this.settings.openBoxBehaviour.useMoveCurve)
				{
					if(this.settings.openBoxBehaviour.moveCurveX != null && 
						this.settings.openBoxBehaviour.moveCurveX.length > 0)
					{
						this.currentPos.x = this.settings.openBoxBehaviour.moveCurveX.
							Evaluate(this.moveTime);
						if(this.settings.openBoxBehaviour.moveRelative)
						{
							this.currentPos.x += this.bounds.x;
						}
					}
					if(this.settings.openBoxBehaviour.moveCurveY != null && 
						this.settings.openBoxBehaviour.moveCurveY.length > 0)
					{
						this.currentPos.y = this.settings.openBoxBehaviour.moveCurveY.
							Evaluate(this.moveTime);
						if(this.settings.openBoxBehaviour.moveRelative)
						{
							this.currentPos.y += this.bounds.y;
						}
					}
				}
				else if(this.interpolateMIn != null)
				{
					if(this.mDistance.x != 0)
					{
						this.currentPos.x = Interpolate.Ease(this.interpolateMIn, this.moveInStart.x, 
							this.mDistance.x, this.moveTime, this.moveTimeMax);
					}
					if(this.mDistance.y != 0)
					{
						this.currentPos.y = Interpolate.Ease(this.interpolateMIn, this.moveInStart.y, 
							this.mDistance.y, this.moveTime, this.moveTimeMax);
					}
				}
				
				if(this.moveTime >= this.moveTimeMax)
				{
					this.isMoving = false;
					this.moveInDone = true;
				}
			}
		}
		
		public void DoMoveOut(float t)
		{
			this.moveTime += t;
			
			if(this.delayMove)
			{
				if(this.moveTime >= this.settings.closeBoxBehaviour.moveDelay)
				{
					this.moveTime = 0;
					this.delayMove = false;
				}
			}
			else
			{
				if(this.settings.closeBoxBehaviour.useMoveCurve)
				{
					if(this.settings.closeBoxBehaviour.moveCurveX != null && 
						this.settings.closeBoxBehaviour.moveCurveX.length > 0)
					{
						this.currentPos.x = this.settings.closeBoxBehaviour.moveCurveX.
							Evaluate(this.moveTime);
						if(this.settings.closeBoxBehaviour.moveRelative)
						{
							this.currentPos.x += this.bounds.x;
						}
					}
					if(this.settings.closeBoxBehaviour.moveCurveY != null && 
						this.settings.closeBoxBehaviour.moveCurveY.length > 0)
					{
						this.currentPos.y = this.settings.closeBoxBehaviour.moveCurveY.
							Evaluate(this.moveTime);
						if(this.settings.closeBoxBehaviour.moveRelative)
						{
							this.currentPos.y += this.bounds.y;
						}
					}
				}
				else if(this.interpolateMOut != null)
				{
					if(this.mDistance.x != 0)
					{
						this.currentPos.x = Interpolate.Ease(this.interpolateMOut, this.bounds.x, 
							this.mDistance.x, this.moveTime, this.moveTimeMax);
					}
					if(this.mDistance.y != 0)
					{
						this.currentPos.y = Interpolate.Ease(this.interpolateMOut, this.bounds.y, 
							this.mDistance.y, this.moveTime, this.moveTimeMax);
					}
				}
				if(this.moveTime >= this.moveTimeMax)
				{
					this.isMoving = false;
					this.moveOutDone = true;
				}
			}
		}
		
		
		/*
		============================================================================
		Scale functions
		============================================================================
		*/
		public void DoScaleIn(float t)
		{
			this.scaleTime += t;
			
			if(this.delayScale)
			{
				if(this.scaleTime >= this.settings.openBoxBehaviour.scaleDelay)
				{
					this.scaleTime = 0;
					this.delayScale = false;
				}
			}
			else
			{
				if(this.settings.openBoxBehaviour.useScaleCurve)
				{
					if(this.settings.openBoxBehaviour.scaleCurveX != null && 
						this.settings.openBoxBehaviour.scaleCurveX.length > 0)
					{
						this.currentScale.x = this.settings.openBoxBehaviour.scaleCurveX.
							Evaluate(this.scaleTime);
					}
					if(this.settings.openBoxBehaviour.scaleCurveY != null && 
						this.settings.openBoxBehaviour.scaleCurveY.length > 0)
					{
						this.currentScale.y = this.settings.openBoxBehaviour.scaleCurveY.
							Evaluate(this.scaleTime);
					}
				}
				else if(this.interpolateSIn != null)
				{
					this.currentScale = Interpolate.Ease(this.interpolateSIn, 
						this.settings.openBoxBehaviour.scale, 
						this.distanceScale, this.scaleTime, this.scaleTimeMax);
				}
				
				if(this.scaleTime >= this.scaleTimeMax)
				{
					this.currentScale = Vector2.one;
					this.isScaling = false;
					this.scaleInDone = true;
				}
			}
		}
		
		public void DoScaleOut(float t)
		{
			this.scaleTime += t;
			
			if(this.delayScale)
			{
				if(this.scaleTime >= this.settings.closeBoxBehaviour.scaleDelay)
				{
					this.scaleTime = 0;
					this.delayScale = false;
				}
			}
			else
			{
				if(this.settings.closeBoxBehaviour.useScaleCurve)
				{
					if(this.settings.closeBoxBehaviour.scaleCurveX != null && 
						this.settings.closeBoxBehaviour.scaleCurveX.length > 0)
					{
						this.currentScale.x = this.settings.closeBoxBehaviour.scaleCurveX.
							Evaluate(this.scaleTime);
					}
					if(this.settings.closeBoxBehaviour.scaleCurveY != null && 
						this.settings.closeBoxBehaviour.scaleCurveY.length > 0)
					{
						this.currentScale.y = this.settings.closeBoxBehaviour.scaleCurveY.
							Evaluate(this.scaleTime);
					}
				}
				else if(this.interpolateSOut != null)
				{
					this.currentScale = Interpolate.Ease(this.interpolateSOut, Vector2.one, 
						this.distanceScale, this.scaleTime, this.scaleTimeMax);
				}
				
				if(this.scaleTime >= this.scaleTimeMax)
				{
					this.isScaling = false;
					this.scaleOutDone = true;
				}
			}
		}
		
		
		/*
		============================================================================
		GUI functions
		============================================================================
		*/
		public GUIBoxContent Content
		{
			get{ return this.content;}
			set
			{
				if(this.content != null)
				{
					this.content.Clear();
				}
				this.content = value;
				this.content.box = this;
				this.content.newContent = true;
			}
		}
		
		public void ContentUpdated()
		{
			if(this.settings.limitToScreen)
			{
				this.SetBasePosition(this.bounds.x, this.bounds.y);
			}
		}
		
		public void SetGUIColor(bool blockFlash)
		{
			if(this.doFlash && !blockFlash)
			{
				GUI.color = this.flashColor;
				GUI.backgroundColor = this.flashColor;
				GUI.contentColor = this.flashColor;
			}
			else if(this.controlable && this.focusable && !this.Focused)
			{
				this.InactiveColor.SetColors();
			}
			else
			{
				GUI.color = this.color;
				GUI.backgroundColor = this.color;
				GUI.contentColor = this.color;
			}
		}
		
		public InactiveColor InactiveColor
		{
			get
			{
				if(this.settings.ownInactive)
				{
					return this.settings.inactive;
				}
				else
				{
					return ORK.MenuSettings.inactive;
				}
			}
		}
		
		public void ShowGUI()
		{
			if(!this.blocked)
			{
				GUISkin tmp = GUI.skin;
				if(this.content != null)
				{
					// matrix
					if(this.useFullScreen)
					{
						GUI.matrix = ORK.Core.FullScreenMatrix;
					}
					else
					{
						GUI.matrix = ORK.Core.GUIMatrix;
					}
					
					if(this.forceSize)
					{
						this.bounds.width = this.settings.boxBounds.width;
						this.bounds.height = this.settings.boxBounds.height;
					}
					
					if(this.Skins.skin)
					{
						GUI.skin = this.Skins.skin;
					}
					
					this.content.Init(this);
					
					Color c = GUI.color;
					Color bc = GUI.backgroundColor;
					Color cc = GUI.contentColor;
					
					GUI.color = this.color;
					
					this.SetGUIColor(false);
					
					this.windowRect.x = this.currentPos.x + this.baseOffset.x;
					this.windowRect.y = this.currentPos.y + this.baseOffset.y;
					this.windowRect.width = this.bounds.width;
					this.windowRect.height = this.bounds.height;
					
					GUIHelper.GetRectAnchor(ref this.windowRect, 
						-this.windowRect.width, -this.windowRect.height, 
						this.settings.boxAnchor);
					
					if(this.currentScale != Vector2.one)
					{
						Vector3 guiScale = this.useFullScreen ? 
							new Vector3(ORK.Core.RealScale.x * this.currentScale.x, 
								ORK.Core.RealScale.y * this.currentScale.y, 1) :
							new Vector3(ORK.Core.GUIScale.x * this.currentScale.x, 
								ORK.Core.GUIScale.y * this.currentScale.y, 1);
						if(guiScale.x <= 0.0001f)
						{
							guiScale.x = 0.0001f;
						}
						if(guiScale.y <= 0.0001f)
						{
							guiScale.y = 0.0001f;
						}
						
						Vector3 tmpPos = GUIHelper.GetRectAnchor(this.windowRect, this.scaleAnchor);
						tmpPos.x *= ORK.Core.GUIScale.x;
						tmpPos.y *= ORK.Core.GUIScale.y;
						
						GUI.matrix = Matrix4x4.TRS((this.useFullScreen ? Vector3.zero : ORK.Core.GUITranslate) + tmpPos - 
								new Vector3(tmpPos.x * this.currentScale.x, tmpPos.y * this.currentScale.y, 0), 
							Quaternion.identity, guiScale);
					}
					
					// name box
					this.nameBounds.x = this.windowRect.x + this.nameOffset.x;
					this.nameBounds.y = this.windowRect.y + this.nameOffset.y;
					if(!this.settings.nameRelative)
					{
						GUIHelper.GetRectAnchorReverse(ref this.nameBounds, 
							-this.windowRect.width, -this.windowRect.height, 
							this.settings.boxAnchor);
					}
					
					
					if(!this.hidden)
					{
						this.content.ShowBefore();
						
						// content box
						if(this.Settings.showBox)
						{
							GUI.Box(this.windowRect, "");
						}
						
						GUI.BeginGroup(this.windowRect);
						this.content.ShowWindow();
						GUI.EndGroup();
						
						// ok/cancel buttons
						this.content.ShowButtons();
						
						// show name
						this.content.ShowName();
						
						// selection icon
						this.content.ShowSelectionIcon();
						
						this.content.ShowAfter();
					}
					
					GUI.color = c;
					GUI.backgroundColor = bc;
					GUI.contentColor = cc;
					
					if(this.currentScale != Vector2.one)
					{
						GUI.matrix = ORK.Core.GUIMatrix;
					}
				}
				GUI.skin = tmp;
			}
		}
		
		public bool Button(Rect buttonBounds, bool showButton, int index, bool last)
		{
			if(this.Focused && this.IsOpened && !this.IsClosing)
			{
				if(GUI.Button(buttonBounds, "", showButton ? "button" : ""))
				{
					return true;
				}
				// unfocused selection
				else if(this.choiceDown >= 0 && 
					Event.current.type == EventType.mouseUp)
				{
					if(this.choiceDown == index)
					{
						this.choiceDown = -1;
						
						Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
						pos.x -= this.windowRect.x + this.settings.boxPadding.x;
						pos.y -= this.windowRect.y + this.settings.boxPadding.y;
						
						if(buttonBounds.Contains(pos))
						{
							return true;
						}
					}
					else if(last)
					{
						this.choiceDown = -1;
					}
				}
			}
			else if(showButton)
			{
				GUI.Box(buttonBounds, "", "button");
				
				// unfocused selection
				if(this.settings.unfocusedChoice && 
					Event.current.type == EventType.mouseDown)
				{
					Vector2 pos = ORK.GUILayers.Get(this.settings.layerID).GetPoint(ORK.Control.MousePosition);
					pos.x -= this.windowRect.x + this.settings.boxPadding.x;
					pos.y -= this.windowRect.y + this.settings.boxPadding.y;
					
					if(buttonBounds.Contains(pos))
					{
						this.choiceDown = index;
					}
				}
			}
			return false;
		}
		
		public bool TabButton(Rect buttonBounds)
		{
			if(!Application.isPlaying || !this.IsOpened || this.IsClosing)
			{
				GUI.Box(buttonBounds, "", this.settings.tabsButtonSettings.showButton ? "button" : "");
			}
			else
			{
				if(GUI.Button(buttonBounds, "", this.settings.tabsButtonSettings.showButton ? "button" : ""))
				{
					return true;
				}
			}
			return false;
		}
	}
}
