
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ImageContent : GUIBoxContent
	{
		private BaseImage image;
		
		private Rect imageBounds;
		
		public ImageContent(BaseImage image)
		{
			this.image = image;
		}
		
		public void Update(BaseImage image)
		{
			this.image = image;
			this.newContent = true;
		}

		public override void Closed()
		{
			
		}

		public override void Init(GUIBox box)
		{
			if(this.newContent && this.image != null)
			{
				this.box = box;
				
				if(this.image.useImage && this.image.image != null)
				{
					if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
						!this.box.forceSize)
					{
						this.box.bounds.height = this.image.image.height + 
							this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
						
						if(this.box.Settings.useAutoMinHeight && 
							this.box.bounds.height < this.box.Settings.boxBounds.height)
						{
							this.box.bounds.height = this.box.Settings.boxBounds.height;
						}
					}
					else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
					{
						this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
							this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
							this.image.image.height);
					}
				}
				
				this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
					this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
				this.imageBounds = new Rect(0, 0, this.contentBounds.width, this.contentBounds.height);
				
				this.newContent = false;
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.CreatePanel();
				
				int tmpIndex = 0;
				this.image.Create(this.imageBounds).CreateObject(parent, null, ref tmpIndex);
			}
		}

		public override void ShowBefore()
		{
			
		}

		public override void ShowAfter()
		{
			
		}

		public override void ShowWindow()
		{
			if(this.box != null)
			{
				if(this.box.doFlash)
				{
					GUI.color = this.box.flashColor;
				}
				else
				{
					GUI.color = this.box.color;
				}
				
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.skin.horizontalScrollbar = GUIStyle.none;
					this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
					GUI.BeginGroup(this.scrollRect);
				}
				else
				{
					GUI.BeginGroup(this.contentBounds);
				}
				
				
				// image
				this.image.Show(this.imageBounds);
				
				GUI.EndGroup();
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.EndScrollView();
				}
			}
		}
		
		public override bool CheckDrop(DragInfo drag, Vector2 position)
		{
			return this.box != null && this.InBox(position);
		}
	}
}
