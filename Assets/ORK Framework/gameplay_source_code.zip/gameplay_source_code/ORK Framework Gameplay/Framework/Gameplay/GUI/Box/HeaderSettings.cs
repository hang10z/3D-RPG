
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HeaderSettings : BaseData
	{
		[ORKEditorHelp("Padding", "The padding of the header texts - " +
			"left (x), top (y), right (z) and bottom (w).", "")]
		public Vector4 padding = new Vector4(10, 10, 10, 10);
		
		[ORKEditorHelp("Is One Line", "Choices are forced to display only one line of text.", "")]
		public bool oneline = false;
		
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		public float lineSpacing = 10;
		
		[ORKEditorInfo("Header Text Format", "Define the appearance of the header's text, " +
			"e.g. color, shadow, font size.", "", 
			endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		public HeaderSettings()
		{
			
		}
	}
}
