
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextDurability : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Absolute Change", "Use the absolute value of the durability change " +
			"(i.e. negative values will become positive).", "")]
		public bool absoluteChange = false;
		
		[ORKEditorHelp("Text", "The text used to display an equipment's durability change.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, label=new string[] {
				"%un = user name, %n = equip name, %i = equip icon", 
				"% = durability (0), %1 = durability (0.0), %2 = durability (0.00)", 
				"%m = max durability (0), %m1 = max durability (0.0), %m2 = max durability (0.00)", 
				"%c = change (0), %c1 = change (0.0), %c2 = change (0.00)"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextDurability()
		{
			
		}
		
		public ConsoleTextDurability(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void Print(Combatant combatant, EquipShortcut equip, float change)
		{
			if(this.absoluteChange)
			{
				change = Mathf.Abs(change);
			}
			
			ORK.Game.Console.AddLine(
				this.text[ORK.Game.Language].
					Replace("%un", combatant.GetName()).
					Replace("%n", equip.GetName()).
					Replace("%i", equip.GetIconTextCode()).
					Replace("%c2", change.ToString("0.00")).
					Replace("%c1", change.ToString("0.0")).
					Replace("%c", change.ToString("0")).
					Replace("%m2", equip.MaxDurability.ToString("0.00")).
					Replace("%m1", equip.MaxDurability.ToString("0.0")).
					Replace("%m", equip.MaxDurability.ToString("0")).
					Replace("%2", equip.Durability.ToString("0.00")).
					Replace("%1", equip.Durability.ToString("0.0")).
					Replace("%", equip.Durability.ToString("0")), 
				this.typeID);
		}
	}
}
