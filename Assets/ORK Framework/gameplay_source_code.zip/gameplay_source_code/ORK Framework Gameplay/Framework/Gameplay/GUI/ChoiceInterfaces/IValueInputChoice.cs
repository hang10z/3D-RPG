
using System;

namespace ORKFramework
{
	public interface IValueInputChoice
	{
		void ValueInputChanged(int index, GUIBox origin);
	}
}
