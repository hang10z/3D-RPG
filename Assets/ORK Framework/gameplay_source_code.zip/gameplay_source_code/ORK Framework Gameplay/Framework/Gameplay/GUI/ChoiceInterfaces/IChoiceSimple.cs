
namespace ORKFramework
{
	public interface IChoiceSimple
	{
		void Show();
	}
}

