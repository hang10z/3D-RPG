
using UnityEngine;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InventorySpaceHUD : BaseData
	{
		// value bar
		[ORKEditorHelp("Use Bar", "The inventory space will be displayed as a bar instead of text.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useBar = false;
		
		[ORKEditorHelp("Bar Bounds", "The position and size of the bar.\n" +
			"The coordinates X=0, Y=0 are located at the upper left corner of this element's bounds.", "")]
		[ORKEditorLayout("useBar", true)]
		public Rect barBounds = new Rect(0, 0, 100, 10);
		
		[ORKEditorLayout(autoInit=true)]
		public ValueBar bar;
		
		
		// text
		[ORKEditorInfo(separator=true, label=new string[] {"% = used space, %m = total space"})]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public StatusTextHUD text;
		
		public InventorySpaceHUD()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Combatant combatant, Rect bounds)
		{
			label = new List<BaseLabel>();
			
			if(this.useBar)
			{
				this.bar.Create(ref label, 
					new Rect(this.barBounds.x + bounds.x, this.barBounds.y + bounds.y, this.barBounds.width, this.barBounds.height), 
					combatant.Inventory.Space, 0, combatant.Inventory.TotalSpace);
			}
			else
			{
				label.AddRange(new MultiContent(
					TextHelper.ReplaceSpecials(this.text.text[ORK.Game.Language].
						Replace("%m", combatant.Inventory.TotalSpace.ToString()).
						Replace("%", combatant.Inventory.Space.ToString())), 
					null, null, bounds, this.text.lineSpacing, this.text.alignment, 
					this.text.vAlignment, BoxHeightAdjustment.Auto, false, 
					this.text.textFormat).label);
			}
		}
	}
}
