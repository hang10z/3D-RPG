
using UnityEngine;
using ORKFramework.Events;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ValueInputContent : GUIBoxContent
	{
		// content
		public string text = "";
		
		public MultiContent content;
		
		private bool markUpdate = false;
		
		
		// text typing
		private int typingIndex = 0;
		
		private bool isTyping = false;
		
		private float typingInterval = 0;
		
		private float typingAudioInterval = 0;
		
		
		// portrait
		private Portrait portrait;
		
		public PortraitPosition setPortraitPosition;
		
		private PortraitPosition portraitPosition;
		
		
		// input
		private List<BaseValueInput> input;
		
		private float choiceTimeout = 0;
		
		public ValueInputContent(string text, string name, List<BaseValueInput> input, 
			IChoice ci, Portrait speakerPortrait)
		{
			this.text = text;
			this.SetName(name);
			this.controlInterface = ci;
			this.portrait = speakerPortrait;
			
			this.input = input;
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.markUpdate)
				{
					this.markUpdate = false;
					this.newContent = true;
				}
				else
				{
					if(this.isTyping && this.box.Settings.useTextTyping && 
						ORK.Game.TextSpeed > 0)
					{
						// index
						if(this.typingInterval <= 0)
						{
							this.typingIndex += this.box.Settings.typingIncrease;
							this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
							
							if(ORK.GUI.IsNewUI && this.content != null)
							{
								this.content.DoNewUITyping(ref this.isTyping, ref this.typingIndex, 
									ref this.typingInterval, ref this.typingAudioInterval);
							}
						}
						else
						{
							this.typingInterval -= ORK.Core.GUITimeDelta;
						}
						// audio
						if(this.box.Settings.typingClip != null)
						{
							if(this.typingAudioInterval <= 0)
							{
								ORK.Audio.PlayOneShot(this.box.Settings.typingClip, 
									this.box.Settings.typingVolume * ORK.Game.SoundVolume);
								this.typingAudioInterval = this.box.Settings.typingAudioInterval / ORK.Game.TextSpeed;
							}
							else
							{
								this.typingAudioInterval -= ORK.Core.GUITimeDelta;
							}
						}
					}
					
					// choice icon fade
					if(this.input != null && this.selection >= 0 && 
						this.selection < this.input.Count && 
						!this.box.disableChoice && this.box.Controlable)
					{
						this.box.ChoiceIcon.Tick(ORK.Core.GUITimeDelta, 
							ref this.iconFadingBack, ref this.iconFadePos, ref this.iconTime);
						
						if(this.choiceIconObject != null)
						{
							this.box.ChoiceIcon.SetObjectPosition(this.choiceIconObject, 
								this.iconFadePos, this.input[this.selection].bounds, 
								this.contentBounds, this.scroll.y, this.box.Focused);
						}
					}
					else if(this.choiceIconObject != null)
					{
						this.choiceIconObject.gameObject.SetActive(false);
					}
					
					if(this.box.Controlable && 
						this.controlInterface != null && this.box.Focused && 
						!this.controlInterface.Tick(this.box))
					{
						if(!this.box.disableChoice)
						{
							if(ORK.InputKeys.Get(ORK.GameControls.acceptKey).GetButton())
							{
								if(this.input != null && this.input.Count > 0 && 
									this.selection >= 0 && this.selection < this.input.Count && 
									this.input[this.selection].OkPressed())
								{
									this.box.Audio.PlayAccept();
									if(this.controlInterface != null && 
										this.controlInterface is IValueInputChoice)
									{
										((IValueInputChoice)this.controlInterface).ValueInputChanged(this.selection, this.box);
									}
									ORK.InputKeys.ResetInputAxes();
								}
								else
								{
									this.OkPressed();
								}
							}
							else if(this.input != null && this.input.Count > 0 && 
								(Time.realtimeSinceStartup - this.choiceTimeout) > ORK.GameControls.cursorTimeout)
							{
								float v = ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis();
								
								if(v < -0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelection(1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
								else if(v > 0.3)
								{
									this.box.Audio.PlayCursorMove();
									this.ChangeSelection(-1);
									this.choiceTimeout = Time.realtimeSinceStartup;
								}
								else if(this.selection >= 0 && this.selection < this.input.Count)
								{
									float h = ORK.InputKeys.Get(ORK.GameControls.horizontalAxis).GetAxis();
									
									if(h < -0.3)
									{
										if(this.input[this.selection].HorizontalChange(-1))
										{
											this.box.Audio.PlayValueInput();
											this.choiceTimeout = Time.realtimeSinceStartup;
											if(this.controlInterface != null && 
												this.controlInterface is IValueInputChoice)
											{
												((IValueInputChoice)this.controlInterface).ValueInputChanged(this.selection, this.box);
											}
										}
									}
									else if(h > 0.3)
									{
										if(this.input[this.selection].HorizontalChange(1))
										{
											this.box.Audio.PlayValueInput();
											this.choiceTimeout = Time.realtimeSinceStartup;
											if(this.controlInterface != null && 
												this.controlInterface is IValueInputChoice)
											{
												((IValueInputChoice)this.controlInterface).ValueInputChanged(this.selection, this.box);
											}
										}
									}
								}
							}
						}
						
						if(ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
						{
							this.CancelPressed();
						}
						else if(this.input == null || this.input.Count == 0 || this.box.disableChoice)
						{
							float v = ORK.InputKeys.Get(ORK.GameControls.verticalAxis).GetAxis();
							if(v < -0.3)
							{
								this.scroll.y += ORK.MenuSettings.scrollSpeed;
							}
							else if(v > 0.3)
							{
								this.scroll.y -= ORK.MenuSettings.scrollSpeed;
							}
						}
					}
				}
			}
		}
		
		public override void OkPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.box.Audio.PlayAccept();
				if(this.isTyping)
				{
					this.isTyping = false;
						
					if(ORK.GUI.IsNewUI && this.content != null)
					{
						this.content.NewUIFullTyped();
					}
				}
				else if(this.content.remainingText != "")
				{
					this.text = this.content.remainingText;
					this.newContent = true;
				}
				else
				{
					this.controlInterface.ChoiceSelected(this.selection, this.box);
				}
			}
		}
		
		public override void CancelPressed()
		{
			ORK.InputKeys.ResetInputAxes();
			if(this.controlInterface != null)
			{
				this.controlInterface.Canceled(this.box);
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Focus functions
		============================================================================
		*/
		public override void FocusGained()
		{
			// select choice
			if(ORK.GUI.IsNewUI && this.input != null && 
				this.selection >= 0 && this.selection < this.input.Count && 
				this.input[this.selection].gameObject != null && 
				ORK.GUI.EventSystem != null)
			{
				ORK.GUI.EventSystem.SetSelectedGameObject(this.input[this.selection].gameObject);
			}
			
			// notify interface
			if(this.controlInterface != null && this.box != null)
			{
				this.controlInterface.FocusGained(this.box);
			}
		}
		
		
		/*
		============================================================================
		Selection functions
		============================================================================
		*/
		public override int Selection
		{
			get{ return this.selection;}
			set
			{
				if(this.selection != value)
				{
					if(this.input != null && this.input.Count > 0 && 
						value >= 0 && value < this.input.Count)
					{
						if(this.input[value].bounds.y < this.scroll.y)
						{
							this.scroll.y = this.input[value].bounds.y;
						}
						else if((this.scroll.y + this.contentBounds.height) < this.input[value].bounds.y + this.input[value].bounds.height)
						{
							this.scroll.y += (this.input[value].bounds.y + this.input[value].bounds.height) - (this.scroll.y + this.contentBounds.height);
						}
						
						if(ORK.GUI.IsNewUI && 
							this.input[value].gameObject != null && 
							ORK.GUI.EventSystem != null)
						{
							ORK.GUI.EventSystem.SetSelectedGameObject(this.input[value].gameObject);
						}
					}
					this.selection = value;
				}
				if(this.controlInterface != null)
				{
					this.controlInterface.SelectionChanged(this.selection, this.box);
				}
			}
		}
		
		private void ChangeSelection(int add)
		{
			
			if(this.input != null && this.input.Count > 0)
			{
				int index = this.selection + add;
				
				if(this.box.Settings.loop)
				{
					if(index < 0)
					{
						index = this.input.Count - 1;
					}
					else if(index >= this.input.Count)
					{
						index = 0;
					}
				}
				else
				{
					if(index < 0)
					{
						index = 0;
					}
					else if(index >= this.input.Count)
					{
						index = this.input.Count - 1;
					}
				}
				
				this.Selection = index;
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.content == null)
			{
				this.box = box;
				
				this.CalculateContent(this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), false);
				
				if(this.portrait != null && this.portrait.image != null)
				{
					this.portrait.image.wrapMode = TextureWrapMode.Clamp;
					
					if(this.setPortraitPosition != null)
					{
						this.portraitPosition = this.setPortraitPosition;
					}
					else if(this.portrait.ownPortraitPosition)
					{
						this.portraitPosition = this.portrait.portraitPosition;
					}
					else if(this.box.Settings.ownPortraitPosition)
					{
						this.portraitPosition = this.box.Settings.portraitPosition;
					}
					else
					{
						this.portraitPosition = ORK.MenuSettings.portraitPosition;
					}
				}
				
				this.newContent = false;
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			Rect textBounds = new Rect(0, 0, 
				(baseWidth - (this.box.Settings.textColumnSpacing * (this.box.Settings.textColumns - 1))) / this.box.Settings.textColumns, 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			// content
			TextHelper.ReplaceSpecials(ref this.text);
			
			this.content = new MultiContent(this.text, null, null, 
				textBounds, this.box.Settings.lineSpacing, 
				this.box.Settings.alignment, this.box.Settings.vAlignment, 
				this.box.Settings.heightAdjustment, this.box.Settings.oneline, 
				this.box.Settings.textFormat, this.box.Settings.textColumns, 
				this.box.Settings.textColumnSpacing);
			
			this.typingIndex = 0;
			this.isTyping = this.box.Settings.useTextTyping && ORK.Game.TextSpeed > 0;
			if(this.isTyping)
			{
				this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
				this.typingAudioInterval = 0;
			}
			
			float contentHeight = this.content.bounds.height;
			textBounds.width = baseWidth;
			
			// input fields
			textBounds.y = this.content.bounds.height;
			
			if(this.input != null)
			{
				float maxXPos = 0;
				for(int i=0; i<this.input.Count; i++)
				{
					if(this.input[i] != null)
					{
						this.input[i].CreateField(this.box, ref textBounds, ref contentHeight, ref maxXPos);
					}
				}
				
				if(this.box.Settings.alignInputFields)
				{
					for(int i=0; i<this.input.Count; i++)
					{
						if(this.input[i] != null)
						{
							this.input[i].SetFieldX(this.box, maxXPos);
						}
					}
				}
			}
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
				
				if(this.box.Settings.useAutoMinHeight && 
					this.box.bounds.height < this.box.Settings.boxBounds.height)
				{
					this.box.bounds.height = this.box.Settings.boxBounds.height;
				}
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
			else
			{
				this.CalculateButtons();
				this.box.ContentUpdated();
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.CreatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// text
				if(this.isTyping && this.box.Settings.useTextTyping)
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
						this.content.label[i].NewUITyping(0, false);
					}
				}
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
					}
				}
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// input fields
				if(this.input != null)
				{
					for(int i=0; i<this.input.Count; i++)
					{
						if(this.input[i] != null)
						{
							this.input[i].CreateObject(i, this.box, parent, this.ValueInputChanged);
							
						}
					}
				}
				
				// choice icon
				if(this.input != null && this.input.Count > 0 && 
					this.box.ChoiceIcon.icon != null)
				{
					if(this.choiceIconObject == null)
					{
						this.choiceIconObject = this.box.ChoiceIcon.CreateObject(this.box.gameObject);
						this.box.ChoiceIcon.SetObjectPosition(this.choiceIconObject, 
							this.iconFadePos, this.input[this.selection].bounds, 
							this.contentBounds, this.scroll.y, this.box.Focused);
					}
				}
				else if(this.choiceIconObject != null)
				{
					GameObject.Destroy(this.choiceIconObject.gameObject);
				}
				
				// portrait
				this.CreatePortraitObject(this.portrait, this.portraitPosition);
				
				// select choice
				if(this.box.Focused && this.input != null && 
					this.selection >= 0 && this.selection < this.input.Count && 
					this.input[this.selection].gameObject != null && 
					ORK.GUI.EventSystem != null)
				{
					ORK.GUI.EventSystem.SetSelectedGameObject(this.input[this.selection].gameObject);
				}
			}
		}
		
		public void ValueInputChanged(int index)
		{
			if(this.input != null && !this.box.disableChoice && 
				index >= 0 && index < this.input.Count)
			{
				this.input[index].UpdateObjectInput();
				
				// notify of change
				if(this.controlInterface != null && 
					this.controlInterface is IValueInputChoice)
				{
					((IValueInputChoice)this.controlInterface).ValueInputChanged(index, this.box);
				}
				this.box.Audio.PlayValueInput();
				this.Selection = index;
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.Behind.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}
		
		public override void ShowAfter()
		{
			if(this.box != null && this.portrait != null && this.portrait.image != null && 
				this.portraitPosition != null && PortraitBoxPosition.InFront.Equals(this.portraitPosition.boxPosition))
			{
				this.portraitPosition.Show(this.portrait, this.box.windowRect);
			}
		}

		public override void ShowWindow()
		{
			if(this.box != null)
			{
				if(this.box.doFlash)
				{
					GUI.color = this.box.flashColor;
				}
				else
				{
					GUI.color = this.box.color;
				}
				
				if(this.box.controlable && this.box.focusable && !this.box.Focused)
				{
					this.box.InactiveColor.SetColors();
				}
				
				// within box potrait
				if(this.portrait != null && this.portrait.image != null && 
					this.portraitPosition != null && PortraitBoxPosition.Within.Equals(this.portraitPosition.boxPosition))
				{
					this.portraitPosition.Show(this.portrait, this.box.windowRect);
				}
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.skin.horizontalScrollbar = GUIStyle.none;
					this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
					GUI.BeginGroup(this.scrollRect);
				}
				else
				{
					GUI.BeginGroup(this.contentBounds);
				}
				
				
				// content typing
				if(this.isTyping)
				{
					this.content.DoTyping(ref this.isTyping, ref this.typingIndex, 
						ref this.typingInterval, ref this.typingAudioInterval, textStyle);
				}
				// no typing
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].Show(textStyle);
					}
				}
				
				// input fields
				if(this.input != null)
				{
					for(int i=0; i<this.input.Count; i++)
					{
						if(this.input[i] != null)
						{
							if(this.input[i].ShowField(this.box, i, this.selection == i, textStyle))
							{
								// notify of change
								if(this.controlInterface != null && 
									this.controlInterface is IValueInputChoice)
								{
									((IValueInputChoice)this.controlInterface).ValueInputChanged(i, this.box);
								}
								this.box.Audio.PlayValueInput();
								this.Selection = i;
							}
						}
					}
				}
				
				GUI.EndGroup();
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.EndScrollView();
				}
			}
		}
		
		public override void ShowSelectionIcon()
		{
			if(this.box != null && !this.box.disableChoice && this.input != null && 
				this.box.ChoiceIcon.icon != null && 
				(this.box.ChoiceIcon.showUnfocused || this.box.Focused) && 
				this.box.Controlable && 
				this.selection >= 0 && this.selection < this.input.Count)
			{
				Rect selBounds = this.input[this.selection].bounds;
				selBounds.x += this.box.Settings.boxPadding.x;
				selBounds.y += this.box.Settings.boxPadding.y - this.scroll.y;
				
				if((selBounds.y >= this.contentBounds.y || 
						selBounds.y + selBounds.height >= this.contentBounds.y) && 
					(selBounds.y < this.contentBounds.y + this.contentBounds.height || 
						selBounds.y + selBounds.height < this.contentBounds.y + this.contentBounds.height))
				{
					selBounds.x += this.box.windowRect.x;
					selBounds.y += this.box.windowRect.y;
					this.DrawChoiceIcon(selBounds);
				}
			}
		}
	}
}
