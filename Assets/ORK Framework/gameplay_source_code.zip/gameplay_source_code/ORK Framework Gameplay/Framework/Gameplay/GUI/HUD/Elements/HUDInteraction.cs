
using UnityEngine;
using ORKFramework.Display;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class HUDInteraction : HUDElement
	{
		[ORKEditorHelp("Text", "The text that will be displayed.", "")]
		[ORKEditorInfo(separator=true, isTextArea=true, label=new string[] {
			"You can use scene object or combatant component information:", 
			"%n = name, %d = description, %i = icon"
		})]
		[ORKEditorArray(ORKDataType.Language)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// text format
		[ORKEditorHelp("Line Spacing", "The space between text lines.", "")]
		[ORKEditorInfo("Text Formatting", "Define the appearance of the text, e.g. alignment, text/shadow color, font size/style.", "", 
			separatorForce=true)]
		public float lineSpacing = 10;
		
		[ORKEditorHelp("Text Alignment", "Select how the text will be aligned horizontally.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public TextAlignment alignment = TextAlignment.Left;
		
		[ORKEditorHelp("Line Alignment", "Select how text lines will be aligned vertically.\n" +
			"This is used to align text lines consisting of labels with different heights (e.g. text and icons).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public VerticalTextAlignment vAlignment = VerticalTextAlignment.Bottom;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		public TextFormat textFormat = TextFormat.Default;
		
		public HUDInteraction()
		{
			
		}
		
		
		/*
		============================================================================
		Create label functions
		============================================================================
		*/
		public void CreateLabels(out List<BaseLabel> label, Rect displayBounds, InteractionCheck interaction)
		{
			label = new MultiContent(
				TextHelper.ReplaceSpecials(this.GetText(interaction.GetFirst(ORK.Control.InteractionController))), 
				null, null, displayBounds, this.lineSpacing, 
				this.alignment, this.vAlignment, BoxHeightAdjustment.Auto, false, this.textFormat).label;
		}
		
		public void CreateLabelsEditor(out List<BaseLabel> label, Rect displayBounds, InteractionCheck interaction)
		{
			SceneObject content = ORK.SceneObjects.Get(0);
			label = new MultiContent(
				TextHelper.ReplaceSpecials(this.text[ORK.Game.Language].
					Replace("%n", content.GetName()).
					Replace("%d", content.GetDescription()).
					Replace("%i", content.GetIconTextCode())), 
				null, null, displayBounds, this.lineSpacing, 
				this.alignment, this.vAlignment, BoxHeightAdjustment.Auto, false, this.textFormat).label;
		}
		
		private string GetText(BaseInteraction baseInteraction)
		{
			if(baseInteraction != null)
			{
				IContent content = ComponentHelper.GetContent(baseInteraction.gameObject);
				if(content != null)
				{
					return this.text[ORK.Game.Language].
						Replace("%n", content.GetName()).
						Replace("%d", content.GetDescription()).
						Replace("%i", content.GetIconTextCode());
				}
			}
			return this.text[ORK.Game.Language].
				Replace("%n", "").
				Replace("%d", "").
				Replace("%i", "");
		}
	}
}
