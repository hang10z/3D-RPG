
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBoxSkins : BaseData
	{
		// legacy
		// skins
		[ORKEditorHelp("Base Skin", "The GUISkin used to display a GUI box.\n" +
			"Uses the box, label, button and scrollbar style of the skin.", "")]
		[ORKEditorLayout("gui:legacy")]
		public GUISkin skin;
		
		[ORKEditorHelp("Selected Choice", "The GUISkin used to display a selected choice.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin selectSkin;
		
		[ORKEditorHelp("Ok/Cancel Button", "The GUISkin used to display the 'Ok' and 'Cancel' buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin okSkin;
		
		[ORKEditorHelp("Name Box", "The GUISkin used to display the name box.\n" +
			"Uses the label and box style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin nameSkin;
		
		[ORKEditorHelp("Tabs Choice", "The GUISkin used to display tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the base skin is used.", "")]
		public GUISkin tabsSkin;
		
		[ORKEditorHelp("Tabs Selected Choice", "The GUISkin used to display selected tab buttons.\n" +
			"Uses the label and button style of the skin. If no skin is selected, the selected skin or the base skin is used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public GUISkin tabsSelectSkin;
		
		
		// new UI
		// content box
		[ORKEditorHelp("Content Box Prefab", "Select the prefab that will be used to display the box of the GUI box.", "")]
		[ORKEditorInfo(labelText="Content Box Settings")]
		[ORKEditorLayout("gui:newui")]
		public GameObject contentBoxPrefab;
		
		[ORKEditorHelp("Content Box Child", "The defined child object of the content box that will be used to place content on.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string contentBoxChild = "";
		
		[ORKEditorHelp("Content Mask", "Select the image that will be used as content mask.\n" +
			"If no image is selected, the whole content bounds are used as mask.", "")]
		public Texture contentMask;
		
		// name box
		[ORKEditorHelp("Name Box Prefab", "Select the prefab that will be used to display the box of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Name Box Settings")]
		public GameObject nameBoxPrefab;
		
		[ORKEditorHelp("Name Box Child", "The defined child object of the name box that will be used to place content on.\n" +
			"If the child can't be found, the game object itself will be used.\n" +
			"Define the child as Path/To/Child, use / to separate game objects in the hierarchy.\n" +
			"Leave empty if no child object should be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string nameBoxChild = "";
		
		// buttons
		[ORKEditorHelp("Choice Prefab", "Select the prefab that will be used to display the choice buttons of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Button Settings")]
		public GameObject buttonPrefab;
		
		[ORKEditorHelp("Fade Button Children", "Fade the color of child objects " +
			"(e.g. text, image) displaying the button's content on button state changes:\n" +
			"- None: Doesn't fade child objects.\n" +
			"- Alpha: Only fades alpha values.\n" +
			"- Color: Fades the color.", "")]
		[ORKEditorLayout("buttonPrefab", null, elseCheckGroup=true, endCheckGroup=true)]
		public ChildColorFadeMode buttonFadeMode = ChildColorFadeMode.None;
		
		[ORKEditorHelp("Ok Button Prefab", "Select the prefab that will be used to display the ok button of the GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject okPrefab;
		
		[ORKEditorHelp("Fade Button Children", "Fade the color of child objects " +
			"(e.g. text, image) displaying the button's content on button state changes:\n" +
			"- None: Doesn't fade child objects.\n" +
			"- Alpha: Only fades alpha values.\n" +
			"- Color: Fades the color.", "")]
		[ORKEditorLayout("okPrefab", null, elseCheckGroup=true, endCheckGroup=true)]
		public ChildColorFadeMode okFadeMode = ChildColorFadeMode.None;
		
		[ORKEditorHelp("Cancel Button Prefab", "Select the prefab that will be used to display the cancel button of the GUI box.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject cancelPrefab;
		
		[ORKEditorHelp("Fade Button Children", "Fade the color of child objects " +
			"(e.g. text, image) displaying the button's content on button state changes:\n" +
			"- None: Doesn't fade child objects.\n" +
			"- Alpha: Only fades alpha values.\n" +
			"- Color: Fades the color.", "")]
		[ORKEditorLayout("cancelPrefab", null, elseCheckGroup=true, endCheckGroup=true)]
		public ChildColorFadeMode cancelFadeMode = ChildColorFadeMode.None;
		
		// tab
		[ORKEditorHelp("Tab Prefab", "Select the prefab that will be used to display the tab buttons of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Tab Settings")]
		public GameObject tabPrefab;
		
		[ORKEditorHelp("Fade Button Children", "Fade the color of child objects " +
			"(e.g. text, image) displaying the button's content on button state changes:\n" +
			"- None: Doesn't fade child objects.\n" +
			"- Alpha: Only fades alpha values.\n" +
			"- Color: Fades the color.", "")]
		[ORKEditorLayout("tabPrefab", null, elseCheckGroup=true, endCheckGroup=true)]
		public ChildColorFadeMode tabFadeMode = ChildColorFadeMode.None;
		
		[ORKEditorHelp("Tab Mask", "Select the image that will be used as tab mask.\n" +
			"If no image is selected, the whole tab bounds are used as mask.", "")]
		public Texture tabMask;
		
		// scrollbar
		[ORKEditorHelp("Scrollbar Prefab", "Select the prefab that will be used to display the vertical scrollbar of the GUI box.", "")]
		[ORKEditorInfo(separator=true, labelText="Scrollbar Settings")]
		public GameObject scrollbarPrefab;
		
		// value inputs
		[ORKEditorHelp("Text Input Prefab", "Select the prefab that will be used to display a text field.", "")]
		[ORKEditorInfo(separator=true, labelText="Value Input Settings")]
		public GameObject textInputPrefab;
		
		[ORKEditorHelp("Keep Text Input Height", "Keep the height of the text input prefab.\n" +
			"If disabled, the height will be adjusted using the font size of the GUI box.", "")]
		public bool keepTextInputHeight = false;
		
		[ORKEditorHelp("Toggle Input Prefab", "Select the prefab that will be used to display a toggle field.", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject toggleInputPrefab;
		
		[ORKEditorHelp("Keep Toggle Input Height", "Keep the height of the toggle input prefab.\n" +
			"If disabled, the height will be adjusted using the font size of the GUI box.", "")]
		public bool keepToggleInputHeight = false;
		
		[ORKEditorHelp("Slider Input Prefab", "Select the prefab that will be used to display a slider field (int and float values).", "")]
		[ORKEditorInfo(separator=true)]
		public GameObject sliderInputPrefab;
		
		[ORKEditorHelp("Keep Slider Input Height", "Keep the height of the slider input prefab.\n" +
			"If disabled, the height will be adjusted using the font size of the GUI box.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool keepSliderInputHeight = false;
		
		public GUIBoxSkins()
		{
			
		}
	}
}
