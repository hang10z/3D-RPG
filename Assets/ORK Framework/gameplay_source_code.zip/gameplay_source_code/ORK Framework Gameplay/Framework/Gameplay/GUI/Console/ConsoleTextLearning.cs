
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleTextLearning : BaseData
	{
		[ORKEditorHelp("Console Type", "Select the console type this text will be displayed in.", "")]
		[ORKEditorInfo(ORKDataType.ConsoleType)]
		public int typeID = 0;
		
		[ORKEditorHelp("Text", "The text used to display learning/forgetting an ability tree, ability, crafting recipe or log.\n" +
			"Please note that crafting recipes and logs are only available for the player.", "")]
		[ORKEditorInfo(isTextArea=true, separator=true, 
			label=new string[] {"%un = user name, %n = name, %i = icon"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] text = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		public ConsoleTextLearning()
		{
			
		}
		
		public ConsoleTextLearning(string text)
		{
			this.text = ArrayHelper.CreateArray(ORK.Languages.Count, text);
		}
		
		public void PrintNoRange(Combatant user, IContentSimple content)
		{
			ORK.Game.Console.AddLine(
				this.text[ORK.Game.Language].
					Replace("%un", user.GetName()).
					Replace("%n", content != null ? content.GetName() : "").
					Replace("%i", content != null ? content.GetIconTextCode() : ""), 
				this.typeID);
		}
		
		public void PrintLearnRange(Combatant user, IContentSimple content)
		{
			if(ORK.ConsoleSettings.learningRange.InRange(user))
			{
				this.PrintNoRange(user, content);
			}
		}
		
		public void PrintForgetRange(Combatant user, IContentSimple content)
		{
			if(ORK.ConsoleSettings.forgettingRange.InRange(user))
			{
				this.PrintNoRange(user, content);
			}
		}
	}
}
