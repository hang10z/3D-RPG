
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ORKGUILayer : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the GUI layer.\n" +
			"GUI layers are used to organize the order of GUI box displays " +
			"and to allow filtering GUI boxes in lists.", "")]
		[ORKEditorInfo("GUI Layer Settings", "GUI layers are used to organize the order of GUI box displays " +
			"and to allow filtering GUI boxes in lists.", "", expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Screen Fader", "The screen fader will be displayed " +
			"after this GUI layer (and before the next).\n" +
			"If no GUI layer is set to display the screen fader, " +
			"it will be displayed after the last GUI layer.", "")]
		[ORKEditorInfo(callbackAfter="check:screenfader")]
		public bool isScreenFader = false;
		
		[ORKEditorHelp("Use Full Screen", "This GUI layer will ignore the GUI settings in the " +
			"'Game Settings' and use the full screen for placement.\n" +
			"The GUI boxes and images on this layer will use 'Stretch to Fill' scaling without padding.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool useFullScreen = false;
		
		public ORKGUILayer()
		{
			
		}
		
		public ORKGUILayer(string n)
		{
			this.name = n;
		}
		
		
		/*
		============================================================================
		Matrix functions
		============================================================================
		*/
		public Vector2 GetPoint(Vector2 position)
		{
			if(this.useFullScreen)
			{
				return ORK.Core.FullScreenRevertMatrix.MultiplyPoint3x4(
					ORK.Core.GUIMatrix.MultiplyPoint3x4(position));
			}
			return position;
		}
		
		public Vector3 GetPoint(Vector3 position)
		{
			if(this.useFullScreen)
			{
				return ORK.Core.FullScreenRevertMatrix.MultiplyPoint3x4(
					ORK.Core.GUIMatrix.MultiplyPoint3x4(position));
			}
			return position;
		}
		
		public Vector3 GetScale()
		{
			return this.useFullScreen ? ORK.Core.RealScale : ORK.Core.GUIScale;
		}
	}
}
