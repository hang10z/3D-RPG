
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GUIBoxFade : BaseData
	{
		// fade settings
		[ORKEditorHelp("Use Fade", "This GUI box will faded.", "")]
		[ORKEditorInfo("Fade Settings", "Optionally fade the GUI box.", "")]
		public bool useFade = false;
		
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to fade.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useFade", true)]
		public float fadeDelay = 0;
		
		[ORKEditorInfo(endFoldout=true, separator=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public FadeColorSettings fade = new FadeColorSettings(0.3f, 0, 1);
		
		
		// move settings
		[ORKEditorHelp("Use Move", "The GUI box will be moved.", "")]
		[ORKEditorInfo("Move Settings", "Optionally move the GUI box.", "")]
		public bool useMove = false;
		
		[ORKEditorHelp("Relative Move", "The position is defined relative to the bounds of the content box.", "")]
		[ORKEditorLayout("useMove", true)]
		public bool moveRelative = false;
		
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to move.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float moveDelay = 0;
		
		// curve move
		[ORKEditorHelp("Use Curve", "Use curves to move the GUI box.\n" +
			"If disabled, interpolation will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMoveCurve = false;
		
		[ORKEditorHelp("X-Axis Curve", "Define the curve used for the X-axis movement.\n" +
			"The X-axis position will be set to the bound's X-axis position.", "")]
		[ORKEditorLayout("useMoveCurve", true, autoInit=true)]
		public AnimationCurve moveCurveX;
		
		[ORKEditorHelp("Y-Axis Curve", "Define the curve used for the Y-axis movement.\n" +
			"The Y-axis position will be set to the bound's Y-axis position.", "")]
		[ORKEditorLayout(autoInit=true)]
		public AnimationCurve moveCurveY;
		
		// interpolate move
		[ORKEditorHelp("Time (s)", "The time in seconds used to move.", "")]
		[ORKEditorLimit(0.01f, false)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public float moveTime = 0.3f;
		
		[ORKEditorHelp("Position", "The position used for moving.\n" +
			"When opening the GUI box, this is the start position of the move.\n" +
			"When closing the GUI box, this is the end position of the move.", "")]
		public Vector2 movePosition = Vector2.zero;
		
		[ORKEditorHelp("Interpolation", "The interpolation used to move.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public EaseType moveInterpolation = EaseType.Linear;
		
		
		// scale
		[ORKEditorHelp("Use Scaling", "Scale the GUI box when moving in.", "")]
		[ORKEditorInfo("Scale Settings", "Optionally scale GUI box.\n" +
			"When opening the GUI box, the scale will be reset to X=1, Y=1 after the scaling.\n" +
			"When closing the GUI box, the scale will start at X=1, Y=1.", "")]
		public bool useScale = false;
		
		[ORKEditorHelp("Scale Anchor", "Select the anchor of the GUI box for scaling.", "")]
		[ORKEditorLayout("useScale", true)]
		public TextAnchor scaleAnchor = TextAnchor.MiddleCenter;
		
		[ORKEditorHelp("Delay (s)", "The time in seconds before starting to scale.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float scaleDelay = 0;
		
		// curve scale
		[ORKEditorHelp("Use Curve", "Use curves to scale the GUI box.\n" +
			"If disabled, interpolation will be used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useScaleCurve = false;
		
		[ORKEditorHelp("X-Axis Curve", "Define the curve used for the X-axis scaling.\n" +
			"The X-axis scale will be set to 1 after scaling.", "")]
		[ORKEditorLayout("useScaleCurve", true, autoInit=true)]
		public AnimationCurve scaleCurveX;
		
		[ORKEditorHelp("Y-Axis Curve", "Define the curve used for the Y-axis scaling.\n" +
			"The Y-axis scale will be set to 1 after scaling.", "")]
		[ORKEditorLayout(autoInit=true)]
		public AnimationCurve scaleCurveY;
		
		// interpolate scale
		[ORKEditorHelp("Time (s)", "The time in seconds used to scale.", "")]
		[ORKEditorLimit(0.01f, false)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public float scaleTime = 0.3f;
		
		[ORKEditorHelp("Start Scale", "Define the scale the GUI box will have when starting to move in.\n" +
			"The scale will be X=1, Y=1 at the end of the move.\n" +
			"Don't use values below 0!", "")]
		public Vector2 scale = new Vector2(0.5f, 0.5f);
		
		[ORKEditorHelp("Interpolation", "The interpolation used to scale.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public EaseType scaleInterpolation = EaseType.Linear;
		
		public GUIBoxFade()
		{
			
		}
		
		public GUIBoxFade(bool isClose)
		{
			if(isClose)
			{
				this.fade = new FadeColorSettings(0.3f, 1, 0);
			}
		}
	}
}
