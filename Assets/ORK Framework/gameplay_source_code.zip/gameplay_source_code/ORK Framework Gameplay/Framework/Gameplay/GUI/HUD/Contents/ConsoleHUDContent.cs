
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ConsoleHUDContent : GUIBoxContent
	{
		private HUDSetting hudSetting;
		
		private List<int> consoleTypes;
		
		
		// content
		public MultiContent content;
		
		private bool markUpdate = false;
		
		
		// tabs
		private ChoiceContent[] tabs;
		
		private int tabsSelection = 0;
		
		private Rect tabsContentBounds;
		
		private Rect tabsBounds;
		
		private bool tabsScrollButtons = false;
		
		private int tabsScrollOffset = 0;
		
		private ChoiceContent tabsLeftArrow;
		
		private ChoiceContent tabsRightArrow;
		
		
		// text typing
		private int typingIndex = 0;
		
		private bool isTyping = false;
		
		private float typingInterval = 0;
		
		private float typingAudioInterval = 0;
		
		
		// new UI
		private GameObject bgObject;
		
		private GameObject fgObject;
		
		public ConsoleHUDContent(HUDSetting setting, List<int> consoleTypes)
		{
			this.hudSetting = setting;
			this.consoleTypes = consoleTypes;
			ORK.Game.Console.UpdateHUD += this.Recalculate;
			this.newContent = true;
		}
		
		public override void SetTabs(ChoiceContent[] tabs)
		{
			this.tabs = tabs;
		}
		
		public override void Clear()
		{
			base.Clear();
			if(this.bgObject != null)
			{
				GameObject.Destroy(this.bgObject);
			}
			if(this.fgObject != null)
			{
				GameObject.Destroy(this.fgObject);
			}
		}
		
		
		/*
		============================================================================
		Control functions
		============================================================================
		*/
		public override void Tick()
		{
			base.Tick();
			if(this.box != null)
			{
				if(this.markUpdate)
				{
					this.markUpdate = false;
					this.newContent = true;
				}
				else
				{
					if(this.isTyping && this.box.Settings.useTextTyping && 
						ORK.Game.TextSpeed > 0)
					{
						// index
						if(this.typingInterval <= 0)
						{
							this.typingIndex += this.box.Settings.typingIncrease;
							this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
							
							if(ORK.GUI.IsNewUI && this.content != null)
							{
								this.content.DoNewUITyping(ref this.isTyping, ref this.typingIndex, 
									ref this.typingInterval, ref this.typingAudioInterval);
							}
						}
						else
						{
							this.typingInterval -= ORK.Core.GUITimeDelta;
						}
						// audio
						if(this.box.Settings.typingClip != null)
						{
							if(this.typingAudioInterval <= 0)
							{
								ORK.Audio.PlayOneShot(this.box.Settings.typingClip, 
									this.box.Settings.typingVolume * ORK.Game.SoundVolume);
								this.typingAudioInterval = this.box.Settings.typingAudioInterval / ORK.Game.TextSpeed;
							}
							else
							{
								this.typingAudioInterval -= ORK.Core.GUITimeDelta;
							}
						}
					}
					
					// interface tick
					if(this.box.Controlable && this.controlInterface != null && this.box.Focused)
					{
						this.controlInterface.Tick(this.box);
					}
				}
			}
		}
		
		public override void Closed()
		{
			if(this.controlInterface != null)
			{
				this.controlInterface.Closed(this.box);
			}
		}
		
		
		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public override void Init(GUIBox box)
		{
			if(this.newContent || this.content == null)
			{
				this.box = box;
				
				this.CalculateContent(this.box.bounds.width, false);
				
				this.newContent = false;
			}
		}
		
		private void CalculateContent(float baseWidth, bool recalced)
		{
			Rect textBounds = new Rect(0, 0, 
				baseWidth - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			// init tabs
			if(this.tabs != null && this.tabs.Length > 0)
			{
				Rect textBounds2 = new Rect(0, 0, 
					baseWidth - (this.box.Settings.tabsPadding.x + this.box.Settings.tabsPadding.z), 
					this.box.bounds.height - (this.box.Settings.tabsPadding.y + this.box.Settings.tabsPadding.w));
				
				// init content and info
				Vector2 biggest = Vector2.zero;
				for(int i=0; i<this.tabs.Length; i++)
				{
					this.tabs[i].InitContent(textBounds2, this.box.Settings.tabsButtonSettings, null, true);
					this.tabs[i].SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					
					if(biggest.x < this.tabs[i].buttonBounds.width)
					{
						biggest.x = this.tabs[i].buttonBounds.width;
					}
					if(biggest.y < this.tabs[i].buttonBounds.height)
					{
						biggest.y = this.tabs[i].buttonBounds.height;
					}
				}
				
				// calculate positions
				float tabsWidth = 0;
				for(int i=0; i<this.tabs.Length; i++)
				{
					this.tabs[i].SetHeight(biggest.y);
					this.tabs[i].SetPosition(new Vector2(tabsWidth, 0));
					
					if(this.box.Settings.tabsSetWidth)
					{
						this.tabs[i].buttonBounds.width = this.box.Settings.tabsWidth;
					}
					else if(this.box.Settings.tabsAdjustWidth)
					{
						this.tabs[i].buttonBounds.width = biggest.x;
					}
					tabsWidth += this.tabs[i].buttonBounds.width + this.box.Settings.tabsSpacing;
				}
				
				this.tabsContentBounds = new Rect(this.box.Settings.tabsPadding.x, this.box.Settings.tabsPadding.y, tabsWidth, biggest.y);
				this.tabsBounds = new Rect(0, 0, tabsWidth, biggest.y);
				textBounds.height -= this.tabsContentBounds.height;
				
				if(textBounds2.width < this.tabsContentBounds.width)
				{
					this.tabsScrollButtons = true;
					if(this.tabsLeftArrow == null)
					{
						this.tabsLeftArrow = this.box.Settings.tabsLeftArrow[ORK.Game.Language].GetChoiceContent();
						this.tabsLeftArrow.InitContent(textBounds2, 
							this.box.Settings.tabsButtonSettings, null, true);
						this.tabsLeftArrow.SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					}
					if(this.tabsRightArrow == null)
					{
						this.tabsRightArrow = this.box.Settings.tabsRightArrow[ORK.Game.Language].GetChoiceContent();
						this.tabsRightArrow.InitContent(textBounds2, 
							this.box.Settings.tabsButtonSettings, null, true);
						this.tabsRightArrow.SetToContentSize(this.box.Settings.tabsButtonSettings.padding);
					}
					this.tabsContentBounds.width = textBounds2.width - (this.tabsLeftArrow.buttonBounds.width + this.tabsRightArrow.buttonBounds.width);
					
					if(ArrowButtonPosition.Left.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsContentBounds.x += this.tabsLeftArrow.buttonBounds.width + 
							this.tabsRightArrow.buttonBounds.width + this.box.Settings.tabsSpacing * 2;
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
					}
					else if(ArrowButtonPosition.LeftRight.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsContentBounds.x += this.tabsLeftArrow.buttonBounds.width + this.box.Settings.tabsSpacing;
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + 
								this.tabsContentBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
					}
					else if(ArrowButtonPosition.Right.Equals(this.box.Settings.tabsArrowPosition))
					{
						this.tabsLeftArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsContentBounds.width + this.box.Settings.tabsSpacing, 
								this.box.Settings.tabsPadding.y));
						this.tabsRightArrow.SetPosition(
							new Vector2(this.box.Settings.tabsPadding.x + this.tabsLeftArrow.buttonBounds.width + 
								this.tabsContentBounds.width + this.box.Settings.tabsSpacing * 2, 
								this.box.Settings.tabsPadding.y));
					}
					
					// correct scroll offset
					for(int i=0; i<this.tabsScrollOffset; i++)
					{
						this.tabsBounds.x -= this.tabs[i].buttonBounds.width;
					}
				}
				else
				{
					this.tabsScrollOffset = 0;
					this.tabsScrollButtons = false;
				}
				
				if(this.tabsSelection < 0)
				{
					this.tabsSelection = 0;
				}
				else if(this.tabsSelection >= this.tabs.Length)
				{
					this.tabsSelection = this.tabs.Length - 1;
				}
			}
			
			
			// content
			string text = "";
			
			if(this.hudSetting.allConsoleTypes || 
				(this.hudSetting.consoleTabs && this.consoleTypes[this.tabsSelection] == -1))
			{
				text = ORK.Game.Console.GetLines(this.hudSetting.consoleInvert);
			}
			else if(this.hudSetting.consoleTabs)
			{
				text = ORK.Game.Console.GetLines(this.consoleTypes[this.tabsSelection], this.hudSetting.consoleInvert);
			}
			else
			{
				text = ORK.Game.Console.GetLines(this.consoleTypes, this.hudSetting.consoleInvert);
			}
			
			this.content = new MultiContent(text, null, null, 
				textBounds, this.box.Settings.lineSpacing, 
				this.box.Settings.alignment, this.box.Settings.vAlignment, 
				this.box.Settings.heightAdjustment, this.box.Settings.oneline, 
				this.box.Settings.textFormat);
			
			this.typingIndex = 0;
			this.isTyping = this.box.Settings.useTextTyping && ORK.Game.TextSpeed > 0;
			if(this.isTyping)
			{
				this.typingInterval = this.box.Settings.typingInterval / ORK.Game.TextSpeed;
				this.typingAudioInterval = 0;
			}
			
			float contentHeight = this.content.bounds.height;
			
			if(BoxHeightAdjustment.Auto.Equals(this.box.Settings.heightAdjustment) && 
				!this.box.forceSize)
			{
				this.box.bounds.height = contentHeight + this.tabsContentBounds.height + this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w;
				
				if(this.box.Settings.useAutoMinHeight && 
					this.box.bounds.height < this.box.Settings.boxBounds.height)
				{
					this.box.bounds.height = this.box.Settings.boxBounds.height;
				}
			}
			else if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				this.scrollRect = new Rect(this.box.Settings.boxPadding.x, this.box.Settings.boxPadding.y, 
					baseWidth, contentHeight);
			}
			
			this.contentBounds = new Rect(this.box.Settings.boxPadding.x, 
				this.box.Settings.boxPadding.y + (TabsPosition.Top.Equals(this.box.Settings.tabsPosition) ? this.tabsContentBounds.height : 0), 
				this.box.bounds.width - (this.box.Settings.boxPadding.x + this.box.Settings.boxPadding.z), 
				this.box.bounds.height - this.tabsContentBounds.height - (this.box.Settings.boxPadding.y + this.box.Settings.boxPadding.w));
			
			if(TabsPosition.Bottom.Equals(this.box.Settings.tabsPosition))
			{
				this.tabsContentBounds.y = this.box.bounds.height - this.tabsContentBounds.height - this.box.Settings.tabsPadding.w;
				if(this.tabsScrollButtons)
				{
					this.tabsLeftArrow.buttonBounds.y = this.tabsContentBounds.y;
					this.tabsRightArrow.buttonBounds.y = this.tabsContentBounds.y;
				}
			}
			
			if(!recalced && contentHeight > this.contentBounds.height && 
				BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
			{
				float scrollbarWidth = 0;
				if(ORK.GUI.IsNewUI)
				{
					if(this.box.Skins.scrollbarPrefab != null)
					{
						RectTransform rect = this.box.Skins.scrollbarPrefab.GetComponent<RectTransform>();
						if(rect != null)
						{
							scrollbarWidth = rect.sizeDelta.x;
						}
					}
				}
				else
				{
					scrollbarWidth = GUI.skin.verticalScrollbar.fixedWidth;
				}
				this.CalculateContent(baseWidth - (scrollbarWidth + this.box.Settings.scrollPadding), true);
			}
			else
			{
				this.CalculateButtons();
				this.box.ContentUpdated();
			}
		}
		
		public override void CreateNewUI()
		{
			if(ORK.GUI.IsNewUI && 
				this.box.gameObject != null)
			{
				GameObject parent = this.UpdatePanel();
				
				// create
				int index = 0;
				if(this.labelObject == null)
				{
					this.labelObject = new List<RectTransform>();
				}
				else
				{
					for(int i=0; i<this.labelObject.Count; i++)
					{
						if(this.labelObject[i] == null)
						{
							this.labelObject.RemoveAt(i--);
						}
						else
						{
							this.labelObject[i].SetParent(null, false);
						}
					}
				}
				
				// text
				if(this.isTyping && this.box.Settings.useTextTyping)
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
						this.content.label[i].NewUITyping(0, false);
					}
				}
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].CreateObject(parent, this.labelObject, ref index);
					}
				}
				
				// tabs
				this.CreateTabsObjects(this.tabsContentBounds, this.tabsBounds, this.tabs, 
					this.tabsScrollButtons, this.tabsLeftArrow, this.tabsRightArrow, 
					this.tabsScrollOffset, this.labelObject, ref index, this.TabClicked);
				
				// update labels
				for(int i=0; i<this.labelObject.Count; i++)
				{
					// remove empty
					if(this.labelObject[i] == null)
					{
						this.labelObject.RemoveAt(i--);
					}
					// remove exceeding labels
					else if(i >= index)
					{
						GameObject.Destroy(this.labelObject[i].gameObject);
						this.labelObject.RemoveAt(i--);
					}
				}
				
				// background image
				if(this.hudSetting != null && this.bgObject == null && 
					this.hudSetting.showBackground && this.hudSetting.bgImage != null)
				{
					this.bgObject = this.CreateImage(this.hudSetting.bgImage, 
						this.hudSetting.bgRelative, this.hudSetting.bgRelativeTo, 0);
				}
				// foreground image
				if(this.hudSetting != null && this.fgObject == null && 
					this.hudSetting.showForeground && this.hudSetting.fgImage != null)
				{
					this.fgObject = this.CreateImage(this.hudSetting.fgImage, 
						this.hudSetting.fgRelative, this.hudSetting.fgRelativeTo, 1);
				}
				
				this.box.uiComponent.UpdateColors();
			}
		}
		
		public void TabClicked(int index)
		{
			if(this.tabs != null && !this.box.disableChoice)
			{
				if(index >= 0 && index < this.tabs.Length)
				{
					if(this.tabs[index].Active)
					{
						this.box.Audio.PlayAccept();
						if(this.tabsSelection != index)
						{
							this.tabsSelection = index;
							this.newContent = true;
						}
					}
					else
					{
						this.box.Audio.PlayFail();
					}
				}
				else if(this.tabsScrollButtons)
				{
					if(index == -1)
					{
						this.box.Audio.PlayCursorMove();
						this.tabsScrollOffset--;
						
						if(this.tabsRect != null)
						{
							this.tabsRect.anchoredPosition += new Vector2(
								this.tabs[this.tabsScrollOffset].buttonBounds.width, 0);
						}
					}
					else if(index == -2)
					{
						this.box.Audio.PlayCursorMove();
						
						if(this.tabsRect != null)
						{
							this.tabsRect.anchoredPosition -= new Vector2(
								this.tabs[this.tabsScrollOffset].buttonBounds.width, 0);
						}
						this.tabsScrollOffset++;
					}
					
					if(this.tabsLeftArrow != null)
					{
						this.tabsLeftArrow.Active = this.tabsScrollOffset > 0;
					}
					if(this.tabsRightArrow != null)
					{
						this.tabsRightArrow.Active = this.tabsScrollOffset < this.tabs.Length - 1;
					}
				}
			}
		}
		
		public void Recalculate()
		{
			this.markUpdate = true;
		}
		
		
		/*
		============================================================================
		Show GUI functions
		============================================================================
		*/
		public override void ShowBefore()
		{
			if(this.hudSetting.showBackground && this.hudSetting.bgImage != null)
			{
				if(this.hudSetting.bgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.bgRelativeTo);
					this.hudSetting.bgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.bgImage.Show();
				}
			}
		}
		
		public override void ShowAfter()
		{
			if(this.hudSetting.showForeground && this.hudSetting.fgImage != null)
			{
				if(this.hudSetting.fgRelative)
				{
					Vector2 tmp = GUIHelper.GetRectAnchor(this.box.windowRect, this.hudSetting.fgRelativeTo);
					this.hudSetting.fgImage.Show(tmp.x, tmp.y);
				}
				else
				{
					this.hudSetting.fgImage.Show();
				}
			}
		}

		public override void ShowWindow()
		{
			if(this.box != null)
			{
				if(this.box.doFlash)
				{
					GUI.color = this.box.flashColor;
				}
				else
				{
					GUI.color = this.box.color;
				}
				
				if(this.box.controlable && this.box.focusable && !this.box.Focused)
				{
					this.box.InactiveColor.SetColors();
				}
				
				GUIStyle textStyle = new GUIStyle(GUI.skin.label);
				textStyle.wordWrap = false;
				
				
				// content
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.skin.horizontalScrollbar = GUIStyle.none;
					this.scroll = GUI.BeginScrollView(this.contentBounds, this.scroll, this.scrollRect);
					GUI.BeginGroup(this.scrollRect);
				}
				else
				{
					GUI.BeginGroup(this.contentBounds);
				}
				
				
				// content typing
				if(this.isTyping)
				{
					this.content.DoTyping(ref this.isTyping, ref this.typingIndex, 
						ref this.typingInterval, ref this.typingAudioInterval, textStyle);
				}
				// no typing
				else
				{
					for(int i=0; i<this.content.label.Count; i++)
					{
						this.content.label[i].Show(textStyle);
					}
				}
				
				GUI.EndGroup();
				if(BoxHeightAdjustment.Scroll.Equals(this.box.Settings.heightAdjustment))
				{
					GUI.EndScrollView();
				}
				
				
				// tabs
				if(this.tabs != null && this.tabs.Length > 0)
				{
					textStyle = new GUIStyle(GUI.skin.label);
					textStyle.wordWrap = false;
					
					GUI.BeginGroup(this.tabsContentBounds);
					
					int lastSelection = this.tabsSelection;
					
					GUISkin tmpSkin = GUI.skin;
					if(this.box.Skins.tabsSkin)
					{
						GUI.skin = this.box.Skins.tabsSkin;
					}
					
					GUI.BeginGroup(this.tabsBounds);
					for(int i=0; i<this.tabs.Length; i++)
					{
						// button and alpha
						if(!this.tabs[i].Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						
						// selected skin
						GUISkin tmpSkin2 = GUI.skin;
						if(!this.box.disableChoice && this.tabsSelection == i && 
							this.tabs[i].isButton)
						{
							if(this.box.Skins.tabsSelectSkin)
							{
								GUI.skin = this.box.Skins.tabsSelectSkin;
							}
							else if(this.box.Skins.selectSkin)
							{
								GUI.skin = this.box.Skins.selectSkin;
							}
						}
						
						if(this.tabs[i].isButton)
						{
							if(this.box.TabButton(this.tabs[i].buttonBounds) && 
								!this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								if(this.tabs[i].Active)
								{
									this.box.Audio.PlayAccept();
									this.tabsSelection = i;
									this.newContent = true;
								}
								else
								{
									this.box.Audio.PlayFail();
								}
							}
						}
						
						GUI.BeginGroup(this.tabs[i].buttonBounds);
						
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabs[i].Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabs[i].cImgBounds, new GUIContent(this.tabs[i].Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabs[i].contentLabel != null && this.tabs[i].contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabs[i].contentLabel.label.Count; j++)
							{
								this.tabs[i].contentLabel.label[j].Show(textStyle);
							}
						}
						
						// info
						if(this.tabs[i].infoLabel != null && this.tabs[i].infoLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabs[i].infoLabel.label.Count; j++)
							{
								this.tabs[i].infoLabel.label[j].Show(textStyle);
							}
						}
						
						GUI.skin = tmpSkin2;
						
						// reset alpha
						GUI.color = this.box.color;
						
						GUI.EndGroup();
					}
					GUI.EndGroup();
					GUI.EndGroup();
					
					if(this.tabsScrollButtons)
					{
						this.tabsLeftArrow.Active = this.tabsScrollOffset > 0;
						this.tabsRightArrow.Active = this.tabsScrollOffset < this.tabs.Length - 1;
						
						// left arrow
						Color tmpCol = GUI.color;
						if(!this.tabsLeftArrow.Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						if(this.tabsLeftArrow.isButton)
						{
							if(this.box.TabButton(this.tabsLeftArrow.buttonBounds) && 
								this.tabsLeftArrow.Active && !this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								this.box.Audio.PlayCursorMove();
								this.tabsScrollOffset--;
								this.tabsBounds.x += this.tabs[this.tabsScrollOffset].buttonBounds.width;
							}
						}
						GUI.BeginGroup(this.tabsLeftArrow.buttonBounds);
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabsLeftArrow.Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabsLeftArrow.cImgBounds, new GUIContent(this.tabsLeftArrow.Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabsLeftArrow.contentLabel != null && this.tabsLeftArrow.contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabsLeftArrow.contentLabel.label.Count; j++)
							{
								this.tabsLeftArrow.contentLabel.label[j].Show(textStyle);
							}
						}
						GUI.EndGroup();
						GUI.color = tmpCol;
						
						// right arrow
						if(!this.tabsRightArrow.Active && 
							GUI.color.a > this.box.Settings.tabsInactiveAlpha)
						{
							Color c = GUI.color;
							c.a = this.box.Settings.tabsInactiveAlpha;
							GUI.color = c;
						}
						if(this.tabsRightArrow.isButton)
						{
							if(this.box.TabButton(this.tabsRightArrow.buttonBounds) && 
								this.tabsRightArrow.Active && !this.box.disableChoice && 
								(this.box.inPause || !ORK.Game.Paused))
							{
								this.box.Audio.PlayCursorMove();
								this.tabsBounds.x -= this.tabs[this.tabsScrollOffset].buttonBounds.width;
								this.tabsScrollOffset++;
							}
						}
						GUI.BeginGroup(this.tabsRightArrow.buttonBounds);
						// content
						if(!this.box.Settings.buttonSettings.alignIcons && this.tabsRightArrow.Content.image != null)
						{
							textStyle.alignment = TextAnchor.MiddleLeft;
							GUI.Label(this.tabsRightArrow.cImgBounds, new GUIContent(this.tabsRightArrow.Content.image), textStyle);
							textStyle.alignment = TextAnchor.UpperLeft;
						}
						if(this.tabsRightArrow.contentLabel != null && this.tabsRightArrow.contentLabel.label.Count > 0)
						{
							for(int j=0; j<this.tabsRightArrow.contentLabel.label.Count; j++)
							{
								this.tabsRightArrow.contentLabel.label[j].Show(textStyle);
							}
						}
						GUI.EndGroup();
						GUI.color = tmpCol;
					}
					
					GUI.skin = tmpSkin;
				}
			}
		}
	}
}
