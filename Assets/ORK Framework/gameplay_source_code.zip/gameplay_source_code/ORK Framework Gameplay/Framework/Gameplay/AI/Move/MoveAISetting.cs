
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAISetting : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the AI movement.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of the battle AI.", "", expandWidth=true)]
		public string name = "";
		
		// auto stop
		[ORKEditorHelp("Use Auto Stop", "The combatant will automatcially stop when " +
			"being close to the target for a defined amount of time.\n" +
			"Use this when the combatant seems to move in circles at the target location.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Stop Settings")]
		public bool autoStop = true;
		
		[ORKEditorHelp("Stop Distance", "The distance in world units the combatant must be to auto stop.", "")]
		[ORKEditorLayout("autoStop", true)]
		public float stopDistance = 0.5f;
		
		[ORKEditorHelp("Stop Time (s)", "The time in seconds the combatant ", "")]
		public float stopTime = 0.5f;
		
		[ORKEditorHelp("Clear Target", "Clear the target the combatant was following or hunting when auto stopping.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool stopClear = false;
		
		// move position/speed component calls
		[ORKEditorHelp("Component Type", "Select the component used to move the combatant:\n" +
			"- Default: A simple movement component that will move directly to the target.\n" +
			"- Nav Mesh Agent: Unity's built in NavMesh is used.\n" +
			"- Custom: A custom component is used.", "")]
		[ORKEditorInfo(separator=true, labelText="Move Component Settings")]
		public MoveComponentType compType = MoveComponentType.Default;
		
		[ORKEditorHelp("Add Component", "The component will be added to the combatant's game object, if it isn't added already.\n" +
			"If disabled, the component must already be attached to the combatant's game object (i.e. it's prefab).", "")]
		public bool compAdd = false;
		
		[ORKEditorHelp("Component Name", "The name of the custom component used to move the combatant.\n" +
			"If the component is in a namespace, you must define the full path (e.g. MyNamespace.Script.ComponentName).", "")]
		[ORKEditorLayout("compType", MoveComponentType.Custom)]
		[ORKEditorInfo(expandWidth=true)]
		public string compName = "";
		
		[ORKEditorHelp("Speed Method Name", "The name of the method used to set the move speed.\n" +
			"Requires a method that takes a float value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compSpeedMethod = "";
		
		[ORKEditorHelp("Position Method Name", "The name of the method used to set the move position.\n" +
			"Requires a method that takes a Vector3 value as parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string compPositionMethod = "";
		
		[ORKEditorHelp("Stop Method Name", "The name of the method used to stop the movement.\n" +
			"Requires a method that takes no parameters.", "")]
		[ORKEditorInfo(endFoldout=true, expandWidth=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string compStopMethod = "";
		
		
		// speed settings
		[ORKEditorInfo("Speed Settings", "Define the move speed for the different modes of the move AI (i.e. following, hunting, fleeing).", "", 
			labelText="Follow Speed")]
		public MoveSpeed followSpeed = new MoveSpeed(MoveSpeedType.Run, 5);
		
		[ORKEditorInfo(separator=true, labelText="Give Way Speed")]
		public MoveSpeed giveWaySpeed = new MoveSpeed(MoveSpeedType.Walk, 5);
		
		[ORKEditorInfo(separator=true, labelText="Hunting Speed")]
		public MoveSpeed huntingSpeed = new MoveSpeed(MoveSpeedType.Run, 5);
		
		[ORKEditorInfo(separator=true, labelText="Flee Speed")]
		public MoveSpeed fleeSpeed = new MoveSpeed(MoveSpeedType.Run, 5);
		
		[ORKEditorInfo(separator=true, labelText="Waypoint Speed", endFoldout=true)]
		public MoveSpeed waypointSpeed = new MoveSpeed(MoveSpeedType.Run, 5);
		
		
		// waypoint settings
		[ORKEditorHelp("Stop Distance", "The distance in world units the combatant will stop before reaching a waypoint.", "")]
		[ORKEditorInfo("Waypoint Settings", "The combatant can follow defind waypoints or randomly patrol in the scene.\n" +
			"To follow waypoints, you have to add the waypoints to the combatant's settings in the scene (inspector).\n" +
			"Uses the 'Waypoint Speed' to move.\n" +
			"Randomly patroling or following defind waypoints is only done if the combatant isn't " +
			"following someone (e.g. the leader or an enemy).", "")]
		[ORKEditorLimit(0.0f, false)]
		public float waypointStopDistance = 0.1f;
		
		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will " +
			"be ignored when calculating the distance to a waypoint.", "")]
		public bool waypointIgnoreRadius = false;
		
		[ORKEditorHelp("Reset Time (s)", "The time in seconds before the combatant switches to the " +
			"next waypoint when not reaching the current one.\n" +
			"The combatant needs to stand still for the time to start.", "")]
		public float waypointResetTime = 1;
		
		[ORKEditorHelp("Enable Random Patrol", "The combatant will randomly patrol in the scene.\n" +
			"The random patrol can be overridden by waypoints added to a spawned combatant (e.g. in their inspector in the scene).", "")]
		[ORKEditorInfo(separator=true)]
		public bool randomPatrol = false;
		
		[ORKEditorHelp("Patrol Radius", "The radius around the original spawn point used to patrol.\n" +
			"If in a group, the group leader will be the center of the area.", "")]
		[ORKEditorLayout("randomPatrol", true)]
		public float patrolRadius = 20.0f;
		
		[ORKEditorHelp("From Current Position", "The patrol radius is used from the current position of the combatant.\n" +
			"If disabled, the patrol radius is used from the original start position of the combatant.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool patrolFromCurrent = false;
		
		
		// idle behaviour
		[ORKEditorHelp("Enable Idle", "Use move events as idle behaviours.\n" +
			"If disabled, the combatant wont use idle behaviours and wont stop between waypoints.", "")]
		[ORKEditorInfo("Idle Settings", "Define how the combatant acts while standing still, e.g. while waiting at a waypoint.", "")]
		public bool useIdle = false;
		
		[ORKEditorHelp("Random", "A random idle behaviour will be used.\n" +
			"If disabled, the idle behaviours will be used in sequence.", "")]
		[ORKEditorLayout("useIdle", true)]
		public bool idleRandom = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Idle Behaviour", "Adds an idle behaviour setting.", "", 
			"Remove", "Removes this idle behaviour setting.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Idle Behaviour", "Idle behaviours use move events to define how a combatant acts while standing still.\n" +
				"If the chance fails, no other move event will be selected instead.", ""})]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true)]
		public IdleBehaviour[] idleBehaviour;
		
		
		// follow leader
		[ORKEditorHelp("Follow Leader", "The combatant will follow it's group leader if outside a defined range to the leader.", "")]
		[ORKEditorInfo("Group Settings", "Define if the combatant will follow it's group leader.", "")]
		public bool followLeader = false;
		
		[ORKEditorHelp("Stop Hunting", "The combatant wont hunt if following it's group leader.\n" +
			"Only the leader of a group will hunt (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still hunt, even while following it's leader.", "")]
		[ORKEditorLayout("followLeader", true)]
		public bool leaderStopHunt = true;
		
		[ORKEditorHelp("No Waypoints", "The combatant wont follow waypoints or randomly patrol if following it's group leader.\n" +
			"Only the leader of a group will follow waypoints (if all group members have this option enabled).\n" +
			"If disabled, the combatant will still follow waypoints, even while following it's leader " +
			"(when not outside the follow range).", "")]
		public bool leaderNoWaypoint = true;
		
		[ORKEditorInfo(separator=true, labelText="Follow Range", label=new string[] {
			"The combatant will follow his leader when being outside this range."
		})]
		public Range followLeaderRange = new Range(5, true, false, 0.5f);
		
		// give way
		[ORKEditorHelp("Give Way", "The combatant will move out of the way of it's leader if inside a defined range to the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Give Way")]
		public bool giveWay = false;
		
		[ORKEditorLayout("giveWay", true, endCheckGroup=true)]
		public Range giveWayRange = new Range(1, true, false, 0.5f);
		
		// auto respawn
		[ORKEditorHelp("Auto Respawn", "The combatant will automatically respawn near it's leader if outside a defined range to the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Auto Respawn")]
		public bool autoRespawn = false;
		
		[ORKEditorLayout("autoRespawn", true, endCheckGroup=true, endGroups=2)]
		public Range autoRespawnRange = new Range(50);
		
		// leader priority
		[ORKEditorHelp("Prioritise Leader", "Following the leader takes priority over " +
			"other movement when outside a defined range.\n" +
			"If disabled, the combatant will continue movement toward his current target ignoring the leader.", "")]
		[ORKEditorInfo(separator=true, labelText="Prioritise Leader")]
		public bool leaderPriority = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("leaderPriority", true, endCheckGroup=true)]
		public Range leaderPriorityRange = new Range(10, true, false, 0.5f);
		
		
		// enemy detection
		// base range
		[ORKEditorHelp("Use Detection", "Use enemy detection - this is needed for hunting and fleeing.\n" +
			"If disabled, the combatant can't hunt or flee from enemy combatants.", "")]
		[ORKEditorInfo("Enemy Detection", "Define how enemies are detected.\n" +
			"Only detected enemy combatants can be hunted or fled from.", "")]
		public bool useDetection = false;
		
		[ORKEditorHelp("Detect Only Leader", "Only enemy group leaders will be detected.\n" +
			"If disabled, all ememy group members can be detected.", "")]
		[ORKEditorLayout("useDetection", true)]
		public bool detectOnlyLeader = false;
		
		[ORKEditorHelp("Detect On Damage", "Detect combatants that damage the combatant.", "")]
		public bool detectOnDamage = false;
		
		[ORKEditorHelp("Use Attack Allies", "Allies will also be detected as targets when a status value " +
			"with 'Attack Allies' enabled is applied to the combatant.", "")]
		public bool detectAttackAllies = false;
		
		[ORKEditorHelp("Timeout (s)", "The time in seconds between two detection checks.\n" +
			"Set to 0 to check every Update call.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float detectionTimeout = 1;
		
		[ORKEditorInfo(separator=true, labelText="Base Detection Range")]
		public Range detectionRange = new Range(20, true, false, 0.5f);
		
		[ORKEditorHelp("Needed", "Select if all or just one move detection must detect the target.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Move Detections")]
		public Needed detectionNeeded = Needed.One;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Detection", "Adds a move detection setting.\n" +
			"You can use multiple move detections to detect enemy movement.", "", 
			"Remove", "Removes this move detection setting.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Move Detection", "Move detections determine how an enemy combatant will be detected.", ""})]
		[ORKEditorLayout(autoInit=true, endCheckGroup=true)]
		public MoveDetection[] detection;
		
		
		// target check intervalls
		[ORKEditorHelp("Ignore Y Distance", "The distance along the Y-axis will be ignored when " +
			"calculating the distance for the check, i.e. the height difference is ignored.", "")]
		[ORKEditorInfo("Target Position Check", "If the move AI has a target (e.g. hunting another combatant, following it's leader), " +
			"the position of the target will be checked frequently and forwarded to the component handling the movement.\n" +
			"You can define several intervals based on different distances, " +
			"the combatant will move to the position of the last check.\n" +
			"The interval between two checks should decrease as the combatant gets nearer to the target.", "")]
		public bool tcIgnYDist = true;
		
		[ORKEditorHelp("No Combatant Radius", "The combatant radius setting of the combatants will " +
			"be ignored when calculating the distance for the check.", "")]
		public bool tcIgnComRad = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Target Check", "Adds a target check to this move AI.", "", 
			"Remove", "Removes this target check.", "", noRemoveCount=1, isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Check", 
				"Define the minimum distance to the target to use this interval.", ""})]
		public MoveTargetCheck[] targetCheck = new MoveTargetCheck[] {new MoveTargetCheck()};
		
		
		// hunting settings
		[ORKEditorHelp("Use Hunting", "The hunting settings are enabled.\n" +
			"If disabled, the combatant wont react to enemy combatants.\n" +
			"Please note that only aggressive combatants will hunt enemies.", "")]
		[ORKEditorInfo("Hunting Settings", "This settings determine if and how a combatant reacts to enemy combatants.", "")]
		[ORKEditorLayout("useDetection", true)]
		public bool useHunting = false;
		
		// lose target settings
		[ORKEditorHelp("Target Lost Interval (s)", "The time in seconds until the target is lost after leaving the detection area.\n" +
			"If the target leaves the detection area (i.e. no move detections can detect the target), " +
			"the combatant will still follow the target for the defined time.", "")]
		[ORKEditorLayout("useHunting", true)]
		[ORKEditorLimit(0.0f, false)]
		public float huntingLostInterval = 1;
		
		[ORKEditorHelp("Lost Position Check", "Check the target's position while the target is lost " +
			"(i.e. the target left the detection area, but the 'target lost interval' is still running).\n" +
			"If disabled, the target's position wont be checked, " +
			"resulting in the combatant moving to the last known position of the target.", "")]
		public bool huntingLostUpdate = false;
		
		// hunting range
		[ORKEditorHelp("Use Hunting Range", "The combatant will only hunt within a range of it's start position " +
			"(i.e. the position it has been spawned at).\n" +
			"When leaving it's hunting range, the combatant will return to it's start position." +
			"If disabled, there is no limit to the hunting range.", "")]
		[ORKEditorInfo(separator=true, labelText="Hunting Range")]
		public bool useHuntingRange = false;
		
		[ORKEditorLayout("useHuntingRange", true, endCheckGroup=true, autoInit=true)]
		public Range huntingRange;
		
		// hunting stop range
		[ORKEditorHelp("Use Stop Range", "The combatant will stop when being within a defined range to the target." +
			"If disabled, the combatant will keep running toward the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Stop Range")]
		public bool useHuntingStopRange = false;
		
		[ORKEditorLayout("useHuntingStopRange", true, endCheckGroup=true, autoInit=true)]
		public Range huntingStopRange;
		
		// hunting conditions
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to hunt the target.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Hunting Conditions")]
		public Needed huntingNeeded = Needed.One;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorArray(false, "Add Hunting Condition", "Adds a hunting condition.\n" +
			"You can use multiple conditions to determine if the combatant hunts the target.", "", 
			"Remove", "Removes this hunting condition.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Hunting Condition", "Hunting conditions determine if the combatant hunts the target.", ""})]
		public MoveCondition[] huntingCondition = new MoveCondition[0];
		
		
		// flee settings
		[ORKEditorHelp("Flee", "The combatant will flee (run into the opposite direction) from a target if certain level conditions are met.", "")]
		[ORKEditorInfo("Flee Settings", "The combatant can optionally flee from enemy combatants if a defined level difference occurs.", "")]
		public bool useFlee = false;
		
		[ORKEditorHelp("Flee Time (s)", "The time in seconds the combatant will flee from the target.\n" +
			"The combatant will ignore detections and will simply run into the opposite direction.\n" +
			"Set to 0 to ignore flee time and still use detections.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useFlee", true)]
		public float fleeTime = 2;
		
		[ORKEditorHelp("Conditions Needed", "Select if all or just one condition must be valid to flee from the target.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Flee Conditions")]
		public Needed fleeNeeded = Needed.One;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		[ORKEditorArray(false, "Add Flee Condition", "Adds a flee condition.\n" +
			"You can use multiple conditions to determine if the combatant flees from the target.", "", 
			"Remove", "Removes this flee condition.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Flee Condition", "Flee conditions determine if the combatant flees from the target.", ""})]
		public MoveCondition[] fleeCondition = new MoveCondition[0];
		
		public MoveAISetting()
		{
			
		}
		
		public MoveAISetting(string name)
		{
			this.name = name;
		}
		
		
		/*
		============================================================================
		Idle functions
		============================================================================
		*/
		public ORKMoveEvent GetIdleEvent(ref int lastIndex)
		{
			if(this.useIdle && this.idleBehaviour != null && this.idleBehaviour.Length > 0)
			{
				if(this.idleRandom)
				{
					return this.idleBehaviour[Random.Range(0, this.idleBehaviour.Length)].GetEvent();
				}
				else
				{
					lastIndex++;
					if(lastIndex < 0 || lastIndex >= this.idleBehaviour.Length)
					{
						lastIndex = 0;
					}
					return this.idleBehaviour[lastIndex].GetEvent();
				}
			}
			return null;
		}
		
		
		/*
		============================================================================
		Target distance check functions
		============================================================================
		*/
		public float GetTargetCheckInterval(Combatant combatant, Combatant target)
		{
			float distance = combatant.DistanceTo(target, this.tcIgnYDist, tcIgnComRad);
			for(int i=this.targetCheck.Length - 1; i>=0; i--)
			{
				if(distance >= this.targetCheck[i].distance)
				{
					return this.targetCheck[i].interval;
				}
			}
			return 0;
		}
		
		public float GetTargetCheckInterval(GameObject combatant, GameObject target)
		{
			float distance = VectorHelper.Distance(combatant.transform.position, target.transform.position, this.tcIgnYDist);
			for(int i=this.targetCheck.Length - 1; i>=0; i--)
			{
				if(distance >= this.targetCheck[i].distance)
				{
					return this.targetCheck[i].interval;
				}
			}
			return 0;
		}
		
		
		/*
		============================================================================
		Detection functions
		============================================================================
		*/
		public bool IsDetectionEnabled()
		{
			return this.useDetection && this.detection != null && this.detection.Length > 0 && 
				(this.useHunting || this.useFlee);
		}
		
		public List<Combatant> DetectTargets(Combatant combatant)
		{
			List<Combatant> targets = new List<Combatant>();
			if(this.useDetection)
			{
				List<Combatant> list = ORK.Game.Combatants.Get(combatant, true, this.detectionRange, 
					this.detectAttackAllies && combatant.Status.AttackAllies ? 
						Consider.Ignore : Consider.Yes, 
					Consider.No, Consider.Ignore);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null && !list[i].Dead && 
						(!this.detectOnlyLeader || list[i] == list[i].Group.Leader) && 
						this.Detect(combatant, list[i]))
					{
						targets.Add(list[i]);
					}
				}
			}
			return targets;
		}
		
		public bool Detect(Combatant combatant, Combatant target)
		{
			if(this.detection != null)
			{
				for(int i=0; i<this.detection.Length; i++)
				{
					if(this.detection[i].Detected(combatant, target))
					{
						if(Needed.One.Equals(this.detectionNeeded))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(this.detectionNeeded))
					{
						return false;
					}
				}
				if(Needed.All.Equals(this.detectionNeeded))
				{
					return true;
				}
			}
			return false;
		}
		
		
		/*
		============================================================================
		Hunting functions
		============================================================================
		*/
		public bool IsHunting(Combatant combatant, Combatant target)
		{
			if(this.useHunting && combatant.IsAggressive)
			{
				if(this.huntingCondition != null && this.huntingCondition.Length > 0)
				{
					for(int i=0; i<this.huntingCondition.Length; i++)
					{
						if(this.huntingCondition[i].IsValid(combatant, target))
						{
							if(Needed.One.Equals(this.huntingNeeded))
							{
								return true;
							}
						}
						else if(Needed.All.Equals(this.huntingNeeded))
						{
							return false;
						}
					}
					
					if(Needed.All.Equals(this.huntingNeeded))
					{
						return true;
					}
					else if(Needed.One.Equals(this.huntingNeeded))
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Flee functions
		============================================================================
		*/
		public bool IsFlee(Combatant combatant, Combatant target)
		{
			if(this.useFlee)
			{
				if(this.fleeCondition != null && this.fleeCondition.Length > 0)
				{
					for(int i=0; i<this.fleeCondition.Length; i++)
					{
						if(this.fleeCondition[i].IsValid(combatant, target))
						{
							if(Needed.One.Equals(this.fleeNeeded))
							{
								return true;
							}
						}
						else if(Needed.All.Equals(this.fleeNeeded))
						{
							return false;
						}
					}
					
					if(Needed.All.Equals(this.fleeNeeded))
					{
						return true;
					}
					else if(Needed.One.Equals(this.fleeNeeded))
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}
		
		
		/*
		============================================================================
		Component functions
		============================================================================
		*/
		public MoveAIComponent AddAIMover(Combatant combatant)
		{
			MoveAIComponent comp = combatant.GameObject.GetComponent<MoveAIComponent>();
			if(comp == null)
			{
				comp = combatant.GameObject.AddComponent<MoveAIComponent>();
				comp.combatant = combatant;
				comp.settings = this;
			}
			return comp;
		}
	}
}
