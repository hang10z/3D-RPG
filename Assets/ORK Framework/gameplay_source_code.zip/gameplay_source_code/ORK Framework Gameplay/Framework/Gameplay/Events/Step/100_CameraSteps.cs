
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;
using System.Text;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Change Camera Position", "Sets or fades the camera position, rotation and field of view.\n" +
		"If all spawned instances of a prefab are used, the first prefab will be used to change the camera.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class ChangeCameraPositionStep : BaseEventStep
	{
		// use object position
		[ORKEditorHelp("Use Target Position", "Use the target game object's position instead of a camera position.", "")]
		public bool useObject = false;
		
		
		// set pos
		[ORKEditorHelp("Set Position", "The position of the camera is set to the position of the target object.", "")]
		[ORKEditorLayout("useObject", true)]
		public bool setPosition = false;
		
		[ORKEditorHelp("Local Space", "The offset to the position is added in local space.", "")]
		[ORKEditorLayout("setPosition", true)]
		public bool localSpace = true;
		
		[ORKEditorHelp("Position Offset", "The offset added to the position of the target object.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public Vector3 pOffset = Vector3.zero;
		
		
		// set rot
		[ORKEditorHelp("Set Rotation", "The rotation of the camera is set to the rotation of the target object.", "")]
		public bool setRotation = false;
		
		[ORKEditorHelp("Rotation Offset", "Offset added to the target's rotation.", "")]
		[ORKEditorLayout("setRotation", true, endCheckGroup=true)]
		public Vector3 rOffset = Vector3.zero;
		
		
		// set FoV
		[ORKEditorHelp("Set Field of View", "The field of view of the camera is changed.", "")]
		public bool setFoV = false;
		
		[ORKEditorHelp("Field of View", "The field of view of the camera will be set to this value.", "")]
		[ORKEditorLayout("setFoV", true, endCheckGroup=true)]
		public float fov = 40;
		
		
		// camera position
		[ORKEditorHelp("Camera Position", "Select the camera position that will be used.", "")]
		[ORKEditorInfo(ORKDataType.CameraPosition)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;
		
		
		// target object
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Use Center", "The center of all target objects will be used.\n" +
			"If disabled, either the first target object or all target objects will be used.", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Use All", "The camera will be placed at all target objects in sequence.\n" +
			"If disabled, the camera will be placed at the first target object.", "")]
		[ORKEditorLayout("useCenter", false)]
		public bool useAll = false;
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between placing the camera on two objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useAll", true, setDefault=true, defaultValue=0.0f)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for the camera to be placed using all objects before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, setDefault=true, defaultValue=true)]
		public bool waitBetween = true;
		
		
		// fade settings
		[ORKEditorHelp("Fade Position", "The camera position is changed over time to the new position.\n" +
			"If disabled, the camera is set to the new position immediately.", "")]
		[ORKEditorInfo(separator=true, labelText="Fade Settings")]
		public bool fade = false;
		
		[ORKEditorInfo(separator=true, labelText="Time (s)", label=new string[] {
			"The time in seconds used to fade the camera."
		})]
		[ORKEditorLayout("fade", true, autoInit=true)]
		public EventFloat time;
		
		[ORKEditorHelp("Wait", "Wait until the fading is done before the next step is executed.", "")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading the camera.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private float tmpTime = 0;
		
		private Transform camera;
		
		private GameObject centerObj;
		
		public ChangeCameraPositionStep()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<float>("time"))
			{
				this.time = new EventFloat();
				this.time.type = NumberValueType.Value;
				data.Get("time", ref this.time.value);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent.PerformCamera)
			{
				this.camera = baseEvent.GetCamera();
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.camera != null && this.list.Count > 0)
				{
					this.tmpTime = this.fade ? this.time.GetValue(baseEvent) : 0;
					
					if(this.useCenter)
					{
						if(this.list.Count > 1)
						{
							this.centerObj = new GameObject("_CenterObj");
							CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
							mover.SetCenter(this.list, false, Vector3.zero, this.tmpTime);
							this.list = new List<GameObject>();
							this.list.Add(this.centerObj);
						}
					}
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else if(this.fade && this.wait)
			{
				baseEvent.StartTime(this.time.GetValue(baseEvent), this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.fade)
				{
					CameraEventMover mover = ComponentHelper.Get<CameraEventMover>(this.camera.gameObject);
					
					if(this.useObject)
					{
						// position
						Vector3 pos = this.camera.position;
						if(this.setPosition)
						{
							if(this.localSpace)
							{
								pos = this.list[this.index].transform.TransformPoint(this.pOffset);
							}
							else
							{
								pos = this.list[this.index].transform.position + this.pOffset;
							}
						}
						// rotation
						Quaternion rot = this.camera.rotation;
						if(this.setRotation)
						{
							Vector3 tmp = this.list[this.index].transform.eulerAngles + this.rOffset;
							rot = Quaternion.Euler(tmp.x, tmp.y, tmp.z);
						}
						// FoV
						float field = 40;
						if(this.setFoV)
						{
							field = this.fov;
						}
						else
						{
							Camera cam = this.camera.GetComponent<Camera>();
							if(cam != null)
							{
								field = cam.fieldOfView;
							}
						}
						mover.SetTargetData(pos, rot, field, this.camera, 
							this.interpolation, this.tmpTime);
					}
					else
					{
						mover.SetTargetData(
							ORK.CameraPositions.Get(this.id), this.camera, this.list[this.index].transform, 
							this.interpolation, this.tmpTime);
					}
				}
				else
				{
					if(this.useObject)
					{
						if(this.setPosition)
						{
							if(this.localSpace)
							{
								this.camera.position = this.list[this.index].transform.TransformPoint(this.pOffset);
							}
							else
							{
								this.camera.position = this.list[this.index].transform.position + this.pOffset;
							}
						}
						if(this.setRotation)
						{
							this.camera.eulerAngles = this.list[this.index].transform.eulerAngles + this.rOffset;
						}
						if(this.setFoV)
						{
							Camera cam = this.camera.GetComponent<Camera>();
							if(cam != null)
							{
								cam.fieldOfView = this.fov;
							}
						}
					}
					else
					{
						ORK.CameraPositions.Get(this.id).Use(this.camera, this.list[this.index].transform);
					}
				}
			}
			
			this.index++;
			// execute next
			if(!this.useCenter && this.useAll && this.index < this.list.Count)
			{
				if(this.timeBetween > 0 || this.tmpTime > 0)
				{
					baseEvent.StartContinue(this.timeBetween + this.tmpTime, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.fade && this.wait)
					{
						if(this.centerObj != null)
						{
							GameObject.Destroy(this.centerObj, this.tmpTime);
						}
						baseEvent.StartTime(this.tmpTime, this.next);
					}
					else
					{
						if(this.centerObj != null)
						{
							GameObject.Destroy(this.centerObj);
						}
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.centerObj = null;
				this.camera = null;
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.fade ? 
				"Fade to position, " + this.time.GetInfoText() + "s " + (this.wait ? "(wait)" : "") : 
				"Set to position";
		}
	}
	
	[ORKEditorHelp("Initial Camera Position", "Resets or fades the camera to the position, rotation and " +
		"field of view it had at the beginning of this game event.\n" +
		"This step will unmount the camera from it's parent object.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class InitialCameraPositionStep : BaseEventStep
	{
		[ORKEditorHelp("Fade Position", "The camera position is changed over time to the initial position.\n" +
			"If disabled, the camera is set to the initial position immediately.", "")]
		public bool fade = false;
		
		[ORKEditorInfo(separator=true, labelText="Time (s)", label=new string[] {
			"The time in seconds used to fade the camera."
		})]
		[ORKEditorLayout("fade", true, autoInit=true)]
		public EventFloat time;
		
		[ORKEditorHelp("Wait", "Wait until the fading is done before the next step is executed.", "")]
		public bool wait = false;
		
		[ORKEditorHelp("Interpolation", "The interpolation used for fading the camera.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public EaseType interpolation = EaseType.Linear;
		
		public InitialCameraPositionStep()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<float>("time"))
			{
				this.time = new EventFloat();
				this.time.type = NumberValueType.Value;
				data.Get("time", ref this.time.value);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpTime = this.time != null ? this.time.GetValue(baseEvent) : 0;
			if(baseEvent.PerformCamera)
			{
				Transform camera = baseEvent.GetCamera();
				if(camera != null)
				{
					if(this.fade)
					{
						camera.parent = null;
						CameraEventMover mover = camera.gameObject.GetComponent<CameraEventMover>();
						if(mover == null)
						{
							mover = camera.gameObject.AddComponent<CameraEventMover>();
						}
						mover.SetTargetData(
							baseEvent.InitialCamPosition, baseEvent.InitialCamRotation, 
							baseEvent.InitialFieldOfView, camera, this.interpolation, tmpTime);
					}
					else
					{
						baseEvent.ResetCameraPosition();
					}
				}
			}
			if(this.fade && this.wait)
			{
				baseEvent.StartTime(tmpTime, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.fade ? 
				"Fade to position, " + this.time.GetInfoText() + "s " + (this.wait ? "(wait)" : "") : 
				"Set to position";
		}
	}
	
	[ORKEditorHelp("Shake Camera", "Shakes the camera.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class ShakeCameraStep : BaseEventStep
	{
		[ORKEditorInfo(separator=true, labelText="Time (s)", label=new string[] {
			"The time in seconds the camera will shake."
		})]
		public EventFloat time = new EventFloat(0.5f);
		
		[ORKEditorHelp("Wait", "Wait until the shaking is done before the next step is executed.", "")]
		public bool wait = false;
		
		
		// x-axis
		[ORKEditorHelp("Shake X-Axis", "Shake the camera along the X-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public bool xShake = true;
		
		[ORKEditorHelp("Intensity", "How hard the camera will shake.\n" +
			"Use a value between 0 and 1.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		[ORKEditorLayout("xShake", true, endCheckGroup=true)]
		public float intensity = 0.2f;
		
		
		// y-axis
		[ORKEditorHelp("Shake Y-Axis", "Shake the camera along the Y-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public bool yShake = false;
		
		[ORKEditorHelp("Intensity Y", "How hard the camera will shake on the Y-axis.\n" +
			"Use a value between 0 and 1.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		[ORKEditorLayout("yShake", true, endCheckGroup=true)]
		public float yIntensity = 0.2f;
		
		
		// z-axis
		[ORKEditorHelp("Shake Z-Axis", "Shake the camera along the Z-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public bool zShake = false;
		
		[ORKEditorHelp("Intensity Z", "How hard the camera will shake on the Z-axis.\n" +
			"Use a value between 0 and 1.", "")]
		[ORKEditorLimit(0.0f, 1.0f)]
		[ORKEditorLayout("zShake", true, endCheckGroup=true)]
		public float zIntensity = 0.2f;
		
		
		// speed
		[ORKEditorHelp("Speed", "The speed at which the camera will shake.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float speed = 75;
		
		public ShakeCameraStep()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<float>("time"))
			{
				this.time = new EventFloat();
				this.time.type = NumberValueType.Value;
				data.Get("time", ref this.time.value);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpTime = this.time.GetValue(baseEvent);
			if(baseEvent.PerformCamera)
			{
				Transform camera = baseEvent.GetCamera();
				if(camera != null)
				{
					CameraEventMover mover = ComponentHelper.Get<CameraEventMover>(camera.gameObject);
					mover.CameraShake(camera, tmpTime, 
						this.xShake ? this.intensity : 0, 
						this.yShake ? this.yIntensity : 0, 
						this.zShake ? this.zIntensity : 0, 
						this.speed);
				}
			}
			if(this.wait)
			{
				baseEvent.StartTime(tmpTime, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.time.GetInfoText() + "s " + (this.wait ? "(wait)" : "");
		}
	}
	
	[ORKEditorHelp("Rotate Camera Around", "Rotates the camera around a game object.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class RotateCameraAroundStep : BaseEventStep
	{
		public EventObjectSetting onObject = new EventObjectSetting();
		
		[ORKEditorHelp("Use Center", "The center of all target objects will be used.\n" +
			"If disabled, either the first target object or all target objects will be used.", "")]
		public bool useCenter = false;
		
		[ORKEditorHelp("Use All", "The camera will rotate around all target objects in sequence.\n" +
			"If disabled, the camera will rotate around the first target object.", "")]
		[ORKEditorLayout("useCenter", false)]
		public bool useAll = false;
		
		[ORKEditorHelp("Time Between (s)", "The time in seconds between rotating around objects.\n" +
			"Only used if greater than 0 and more than one object will be used.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useAll", true, setDefault=true, defaultValue=0.0f)]
		public float timeBetween = 0;
		
		[ORKEditorHelp("Wait Between", "Wait for the camera to start rotating around all objects before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, setDefault=true, defaultValue=true)]
		public bool waitBetween = true;
		
		
		// time
		[ORKEditorInfo(separator=true, labelText="Time (s)", label=new string[] {
			"The time in seconds the camera will rotate."
		})]
		public EventFloat time = new EventFloat(1);
		
		[ORKEditorHelp("Wait", "Wait until the rotation is done before the next step is executed.", "")]
		[ORKEditorLayout(new string[] {"useCenter", "useAll", "waitBetween"}, 
			new System.Object[] {true, true, true}, needed=Needed.One, endCheckGroup=true)]
		public bool wait = false;
		
		[ORKEditorHelp("Speed", "The speed at which the camera will rotate.", "")]
		[ORKEditorInfo(separator=true, labelText="Rotation Settings")]
		[ORKEditorLimit(0.0f, false)]
		public float speed = 75;
		
		[ORKEditorHelp("Rotation Axes", "The camera rotates around axes that aren't 0.\n" +
			"A value of 1 will let the camera rotate along this axis, " +
			"e.g. X=0, Y=1, Z=0 will rotate the camera around the Y-axis.\n" +
			"Use negative values to invert the rotation.", "")]
		public Vector3 angles = new Vector3(0, 1, 0);
		
		
		// ingame
		private List<GameObject> list;
		
		private int index = 0;
		
		private float tmpTime = 0;
		
		private Transform camera;
		
		private GameObject centerObj;
		
		public RotateCameraAroundStep()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<float>("time"))
			{
				this.time = new EventFloat();
				this.time.type = NumberValueType.Value;
				data.Get("time", ref this.time.value);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent.PerformCamera)
			{
				this.tmpTime = this.time.GetValue(baseEvent);
				this.camera = baseEvent.GetCamera();
				this.list = this.onObject.GetObject(baseEvent);
				this.index = 0;
				
				if(this.camera != null && this.list.Count > 0)
				{
					if(this.useCenter)
					{
						if(this.list.Count > 1)
						{
							this.centerObj = new GameObject("_CenterObj");
							CenterEventMover mover = this.centerObj.AddComponent<CenterEventMover>();
							mover.SetCenter(this.list, false, Vector3.zero, this.tmpTime);
							this.list = new List<GameObject>();
							this.list.Add(this.centerObj);
						}
					}
					this.Continue(baseEvent);
					
					if(!this.waitBetween)
					{
						baseEvent.StepFinished(this.next);
					}
				}
				else
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else if(this.wait)
			{
				baseEvent.StartTime(this.time.GetValue(baseEvent), this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}
		
		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				CameraEventMover mover = ComponentHelper.Get<CameraEventMover>(camera.gameObject);
				mover.CameraRotate(camera, this.list[this.index].transform, 
					this.angles, this.tmpTime, this.speed);
			}
			
			this.index++;
			// execute next
			if(this.useAll && this.index < this.list.Count)
			{
				if(this.timeBetween > 0 || this.tmpTime > 0)
				{
					baseEvent.StartContinue(this.timeBetween + this.tmpTime, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait)
					{
						if(this.centerObj != null)
						{
							GameObject.Destroy(this.centerObj, this.tmpTime);
						}
						
						baseEvent.StartTime(this.tmpTime, this.next);
					}
					else
					{
						if(this.centerObj != null)
						{
							GameObject.Destroy(this.centerObj);
						}
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.centerObj = null;
				this.camera = null;
				this.list = null;
				this.index = 0;
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.time.GetInfoText() + "s " + (this.wait ? "(wait)" : "");
		}
	}
	
	[ORKEditorHelp("Orthographic Camera", "Sets the camera to be orthographic or perspective.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class OrthographicCameraStep : BaseEventStep
	{
		[ORKEditorHelp("Orthographic", "If enabled, the camera will be set orthographic.\n" +
			"If disabled, the camera will be set perspective.", "")]
		public bool orthographic = false;
		
		[ORKEditorHelp("Orthographic Size", "Camera's half-size when in orthographic mode.\n" +
			"The smaller the size, the nearer the camera will be to the player.", "")]
		[ORKEditorLayout("orthographic", true, endCheckGroup=true)]
		public EventFloat orthographicSize = new EventFloat(5);
		
		public OrthographicCameraStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent.PerformCamera)
			{
				Transform transform = baseEvent.GetCamera();
				if(transform != null)
				{
					Camera cam = transform.GetComponent<Camera>();
					if(cam != null)
					{
						cam.orthographic = this.orthographic;
						if(this.orthographic)
						{
							cam.orthographicSize = this.orthographicSize.GetValue(baseEvent);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orthographic ? "Orthographic, " + this.orthographicSize : "Perspective";
		}
	}
	
	[ORKEditorHelp("Is Camera Orthographic", "If the camera is orthographic, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Camera Steps", "Check Steps")]
	public class IsCameraOrthographicStep : BaseEventCheckStep
	{
		public IsCameraOrthographicStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool ok = false;
			
			Transform transform = baseEvent.GetCamera();
			if(transform != null)
			{
				Camera camera = transform.GetComponent<Camera>();
				if(camera != null && camera.orthographic)
				{
					ok = true;
				}
			}
			
			if(ok)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
	
	[ORKEditorHelp("Mount Camera", "Mounts or unmounts the camera to a game object.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class MountCameraStep : BaseEventStep
	{
		[ORKEditorHelp("Mount", "If enabled, the camera will be mounted to a game object.\n" +
			"If disabled, the camera will be unmounted from it's current parent object.", "")]
		public bool mount = false;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("mount", true, autoInit=true)]
		public EventObjectSetting targetObject;
		
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public MountSettings mountSettings;
		
		public MountCameraStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent.PerformCamera)
			{
				Transform camera = baseEvent.GetCamera();
				List<GameObject> target = this.targetObject.GetObject(baseEvent);
				
				int index = 0;
				for(int i=0; i<target.Count; i++)
				{
					if(target[i] != null)
					{
						index = i;
						break;
					}
				}
				
				if(camera != null)
				{
					// mount
					if(this.mount)
					{
						if(target.Count > 0 && target[index] != null)
						{
							this.mountSettings.MountTo(target[index].transform, camera);
						}
					}
					// unmount
					else
					{
						camera.parent = null;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Block Camera Control", "Blocks or unblocks the camera control.\n" +
		"For each block, the block counter will increase by 1, for each unblock, the counter will decrease by 1.\n" +
		"As long as the counter is above 0 the camera control will remain blocked.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps", "Base Steps")]
	public class BlockCameraControlStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the camera control will be blocked.\n" +
			"If disabled, the camera control will be unblocked.", "")]
		public bool block = false;
		
		public BlockCameraControlStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.DoCameraBlock(this.block ? 1 : -1);
			baseEvent.StepFinished(this.next);
		}
		
		public override bool ExecuteOnStop
		{
			get{ return true;}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.block ? "Block" : "Unblock";
		}
	}
	
	[ORKEditorHelp("Camera Control Target", 
		"Changes the camera control target to a selected object.\n" +
		"The camera control must descent from the 'BaseCameraControl' class " +
		"(like all built-in camera controls).", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps", "Base Steps")]
	public class CameraControlTargetStep : BaseEventStep
	{
		[ORKEditorHelp("Reset", "Resets the camera control target to the player.", "")]
		public bool reset = false;
		
		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("reset", false, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting onObject;
		
		public CameraControlTargetStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.reset)
			{
				ORK.Control.SetCameraControlTarget(null);
			}
			else
			{
				List<GameObject> list = this.onObject.GetObject(baseEvent);
				for(int i=0; i<list.Count; i++)
				{
					if(list[i] != null)
					{
						ORK.Control.SetCameraControlTarget(list[i]);
						break;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.reset ? "Reset" : "";
		}
	}
	
	[ORKEditorHelp("Collision Camera", 
		"Enable or disable the collision camera - " +
		"can only be used when a 'Collision Camera' component is attached to the camera.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Camera Steps", "Base Steps")]
	public class CollisionCameraStep : BaseEventStep
	{
		[ORKEditorHelp("Enable/Disable", "If enabled, the collision camera will be enabled.\n" +
			"If disabled, the collision camera will be disabled.\n" +
			"Please note that a 'Collision Camera' component has to be attached to the camera, " +
			"i.e. either manually or automatically using the collision camera settings.", "")]
		public bool enable = false;
		
		public CollisionCameraStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Transform camera = baseEvent.GetCamera();
			if(camera != null)
			{
				CollisionCamera comp = camera.GetComponentInChildren<CollisionCamera>();
				if(comp != null)
				{
					comp.enabled = this.enable;
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.enable ? "Enable" : "Disable";
		}
	}
	
	[ORKEditorHelp("Change Camera Options", "Change various settings on a camera, e.g. culling mask, depth, etc.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Camera Steps")]
	public class ChangeCameraOptionsStep : BaseEventStep
	{
		// background color
		[ORKEditorHelp("Change BG Color", "Change the background color of the camera.", "")]
		[ORKEditorInfo(labelText="Background Color")]
		public bool changeBGColor = false;
		
		[ORKEditorHelp("Background Color", "Select the background color that will be used.", "")]
		[ORKEditorLayout("changeBGColor", true, endCheckGroup=true)]
		public Color bgColor = Color.blue;
		
		
		// clear flags
		[ORKEditorHelp("Change Clear Flags", "Change the clear flags of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Clear Flags")]
		public bool changeClearFlags = false;
		
		[ORKEditorHelp("Clear Flags", "Select how the camera clears the background.", "")]
		[ORKEditorLayout("changeClearFlags", true, endCheckGroup=true)]
		public CameraClearFlags clearFlags = CameraClearFlags.Color;
		
		
		// culling mask
		[ORKEditorHelp("Change Culling Mask", "Change the culling mask of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Culling Mask")]
		public bool changeCullingMask = false;
		
		[ORKEditorHelp("Culling Mask", "Select the layers that will be displayed by the camera.", "")]
		[ORKEditorLayout("changeCullingMask", true, endCheckGroup=true)]
		public LayerMask cullingMask = -1;
		
		
		// depth texture mode
		[ORKEditorHelp("Change Texture Mode", "Change the depth texture generation mode of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Depth Texture Mode")]
		public bool changeDepthTextureMode = false;
		
		[ORKEditorHelp("Depth Texture Mode", "Select the depth texture mode that will be used.", "")]
		[ORKEditorLayout("changeDepthTextureMode", true, endCheckGroup=true)]
		public DepthTextureMode depthTextureMode = DepthTextureMode.None;
		
		
		// event mask
		[ORKEditorHelp("Change Event Mask", "Change the event mask of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Event Mask")]
		public bool changeEventMask = false;
		
		[ORKEditorHelp("Event Mask", "Select the layers that can trigger events on the camera.", "")]
		[ORKEditorLayout("changeEventMask", true, endCheckGroup=true)]
		public LayerMask eventMask = -1;
		
		
		// rendering path
		[ORKEditorHelp("Change Rendering Path", "Change the rendering path of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Rendering Path")]
		public bool changeRenderingPath = false;
		
		[ORKEditorHelp("Rendering Path", "Select the rendering path that will be used.", "")]
		[ORKEditorLayout("changeRenderingPath", true, endCheckGroup=true)]
		public RenderingPath renderingPath = RenderingPath.UsePlayerSettings;
		
		
		// rendering path
		[ORKEditorHelp("Change Transparency Sort Mode", "Change the transparency sort mode of the camera.", "")]
		[ORKEditorInfo(separator=true, labelText="Rendering Path")]
		public bool changeTransparencySortMode = false;
		
		[ORKEditorHelp("Rendering Path", "Select the transparency sort mode that will be used.", "")]
		[ORKEditorLayout("changeTransparencySortMode", true, endCheckGroup=true)]
		public TransparencySortMode transparencySortMode = TransparencySortMode.Default;
		
		public ChangeCameraOptionsStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			Transform cam = baseEvent.GetCamera();
			if(cam != null)
			{
				Camera camera = cam.GetComponent<Camera>();
				if(camera != null)
				{
					if(this.changeBGColor)
					{
						camera.backgroundColor = this.bgColor;
					}
					if(this.changeClearFlags)
					{
						camera.clearFlags = this.clearFlags;
					}
					if(this.changeCullingMask)
					{
						camera.cullingMask = this.cullingMask;
					}
					if(this.changeDepthTextureMode)
					{
						camera.depthTextureMode = this.depthTextureMode;
					}
					if(this.changeEventMask)
					{
						camera.eventMask = this.eventMask;
					}
					if(this.changeRenderingPath)
					{
						camera.renderingPath = this.renderingPath;
					}
					if(this.changeTransparencySortMode)
					{
						camera.transparencySortMode = this.transparencySortMode;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			StringBuilder builder = new StringBuilder();
			if(this.changeBGColor)
			{
				builder.Append("BG Color");
			}
			if(this.changeClearFlags)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Clear Flags");
				}
				else
				{
					builder.Append("Clear Flags");
				}
			}
			if(this.changeCullingMask)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Culling Mask");
				}
				else
				{
					builder.Append("Culling Mask");
				}
			}
			if(this.changeDepthTextureMode)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Depth Texture Mode");
				}
				else
				{
					builder.Append("Depth Texture Mode");
				}
			}
			if(this.changeEventMask)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Event Mask");
				}
				else
				{
					builder.Append("Event Mask");
				}
			}
			if(this.changeRenderingPath)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Rendering Path");
				}
				else
				{
					builder.Append("Rendering Path");
				}
			}
			if(this.changeTransparencySortMode)
			{
				if(builder.Length > 0)
				{
					builder.Append(", Transparency Sort Mode");
				}
				else
				{
					builder.Append("Transparency Sort Mode");
				}
			}
			return builder.ToString();
		}
	}
}
