
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Call Save Menu", "Calls the save point, save or load menu.\n" +
		"The event continues after the menu is closed.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class CallSaveLoadMenuStep : BaseEventStep
	{
		[ORKEditorHelp("Call Save Point", "Display the save point menu.\n" +
			"If disabled, either the save or load menu are displayed.", "")]
		public bool savePoint = false;
		
		[ORKEditorHelp("Call Load Menu", "Display the load menu.\n" +
			"If disabled, the save menu will be displayed.", "")]
		[ORKEditorLayout("savePoint", false, endCheckGroup=true)]
		public bool loadMenu = false;
		
		public CallSaveLoadMenuStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.SetNextStep(this.next);
			if(this.savePoint)
			{
				ORK.SaveGameMenu.savePoint.Show(baseEvent);
			}
			else if(this.loadMenu)
			{
				ORK.SaveGameMenu.loadMenu.Show(null, baseEvent);
			}
			else
			{
				ORK.SaveGameMenu.saveMenu.Show(null, baseEvent);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.savePoint ? "Save Point" : (this.loadMenu ? "Load Menu" : "Save Menu");
		}
	}
	
	[ORKEditorHelp("Auto Save Game", "Saves the game to the AUTO save game file or creates a temporary retry save game.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class AutoSaveGameStep : BaseEventStep
	{
		[ORKEditorHelp("Save To Retry", "Creates a temporary retry save game.\n" +
			"The retry save game will be lost when loading it or quitting the game.\n" +
			"If disabled, the game will use the AUTO save game file to create a permanently save game.", "")]
		public bool retry = false;
		
		public AutoSaveGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry)
			{
				ORK.SaveGame.Save(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.Save(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.retry ? "Retry" : "AUTO";
		}
	}
	
	[ORKEditorHelp("Auto Load Game", "Loads the game from the AUTO save game file or a temporary retry save game.\n" +
		"The event ends after this step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class AutoLoadGameStep : BaseEventStep
	{
		[ORKEditorHelp("Load From Retry", "Loads a temporary retry save game.\n" +
			"If no retry save game is available, the last AUTO save game is used.", "")]
		public bool retry = false;
		
		public AutoLoadGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry && ORK.SaveGame.RetryAvailable())
			{
				ORK.SaveGame.Load(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.Load(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.retry ? "Retry" : "AUTO") + 
				": Ends the event";
		}
	}
	
	[ORKEditorHelp("Has Auto Save Game", "Checks if an auto save game exists on the current auto save slot.\n" +
		"If the save game exists, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class HasAutoSaveGameStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Retry", "Checks if a retry save game exists.\n" +
			"A retry save game is either a temporary save game, or the last used save slot.", "")]
		public bool retry = false;
		
		public HasAutoSaveGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = false;
			if(this.retry)
			{
				check = ORK.SaveGame.RetryAvailable();
			}
			else
			{
				check = ORK.SaveGame.FileExists(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			
			if(check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.retry ? "Retry" : "AUTO";
		}
	}
	
	[ORKEditorHelp("Continue", "Loads the last used save game or auto save slot.\n" +
		"The event ends after this step.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class ContinueStep : BaseEventStep
	{
		public ContinueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.SaveGame.Continue();
			baseEvent.StepFinished(baseEvent.step.Length);
		}
		
		public override int GetNextCount()
		{
			return 0;
		}
		
		public override int GetNext(int index)
		{
			return -1;
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Ends the event";
		}
	}
	
	[ORKEditorHelp("Can Continue", "Checks if the game can be continued, " +
		"i.e. a last used save game (or auto save slot) exists.\n" +
		"If the save game exists, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleStartEvent), typeof(BattleEndEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class CanContinueStep : BaseEventCheckStep
	{
		public CanContinueStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.SaveGame.HasContinue())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
	
	[ORKEditorHelp("Delete Auto Save", "Deletes the AUTO save slot's save game or the temporary retry save game.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class DeleteAutoSaveStep : BaseEventStep
	{
		[ORKEditorHelp("Delete Retry", "Deletes the temporary retry save game.", "")]
		public bool retry = false;
		
		public DeleteAutoSaveStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.retry)
			{
				ORK.SaveGame.DeleteFile(SaveGameHandler.RETRY_INDEX);
			}
			else
			{
				ORK.SaveGame.DeleteFile(SaveGameHandler.AUTOSAVE_INDEX - ORK.Game.AutoSaveSlot);
			}
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.retry ? "Retry" : "AUTO";
		}
	}
	
	[ORKEditorHelp("Delete Save Game", "Deletes a defined save game or AUTO save game.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Save Game Steps")]
	public class DeleteSaveGameStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Save Game Index", 
			label=new string[]{"The index of the save game."})]
		public EventInteger index = new EventInteger();
		
		[ORKEditorHelp("Is Auto Save", "Delete an auto save game instead of a regular save game.", "")]
		public bool isAutoSave = false;
		
		public DeleteSaveGameStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			int saveIndex = this.index.GetValue(baseEvent);
			if(saveIndex >= 0)
			{
				if(this.isAutoSave)
				{
					ORK.SaveGame.DeleteFile(SaveGameHandler.AUTOSAVE_INDEX - saveIndex);
				}
				else
				{
					ORK.SaveGame.DeleteFile(saveIndex);
				}
			}
			
			baseEvent.StepFinished(this.next);
		}
		
		
		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.index.GetInfoText() + 
				(this.isAutoSave ? " (AUTO)" : "");
		}
	}

	[ORKEditorHelp("Check Auto Save Slot", "Checks the currently used auto save slot.\n" +
		"If the check is valid, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Save Game Steps", "Check Steps")]
	public class CheckAutoSlotStep : BaseEventCheckStep
	{
		[ORKEditorInfo(ORKDataType.Difficulty, labelText="Auto Save Slot")]
		public EventInteger slot = new EventInteger();

		[ORKEditorHelp("Check Type", "Checks if the current auto save slot is equal, not equal, less or greater than the defined slot.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueCheck check = ValueCheck.IsEqual;

		public CheckAutoSlotStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ValueHelper.CheckValue(ORK.Game.AutoSaveSlot, this.slot.GetValue(baseEvent), this.check))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.slot;
		}
	}
}
