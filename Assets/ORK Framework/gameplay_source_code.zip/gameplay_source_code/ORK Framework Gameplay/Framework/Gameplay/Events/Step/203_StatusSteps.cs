
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Regenerate", "Regenerates all 'Consumable' type status values of a combatant or the combatant's group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class RegenerateStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be regenrated.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Revive Dead", "Dead members will be revived.", "")]
		public bool reviveDead = false;

		[ORKEditorHelp("Whole Group", "The whole group of the combatant will be regenerated.\n" +
			"If disabled, only the selected combatant will be regenerated.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be regenerated.\n" +
			"If disabled, all active members of the combatant's group will be regenerated.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;

		public RegenerateStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						if(list[i].Group != null)
						{
							list[i].Group.Regenerate(this.onlyBattle, this.reviveDead);
						}
					}
					else
					{
						list[i].Status.Regenerate(this.reviveDead);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Revive", "Revives a combatant or the combatant's group.\n" +
		"This step doesn't change 'Consumable' type status values, " +
		"i.e. the combatant will die again if the status value causing the death is still the same.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ReviveStep : BaseEventStep
	{
		[ORKEditorHelp("Whole Group", "The whole group of the combatant will be regenerated.\n" +
			"If disabled, only the selected combatant will be regenerated.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be regenerated.\n" +
			"If disabled, all active members of the combatant's group will be regenerated.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;

		[ORKEditorInfo(separator=true, labelText="Combatant Object")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public ReviveStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						if(list[i].Group != null)
						{
							List<Combatant> group = this.onlyBattle ?
								list[i].Group.GetBattle() : list[i].Group.GetGroup();
							for(int j = 0; j < group.Count; j++)
							{
								group[j].Dead = false;
								group[j].MarkResetStatus();
							}
						}
					}
					else
					{
						list[i].Dead = false;
						list[i].MarkResetStatus();
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() +
				(this.wholeGroup ?
					(this.onlyBattle ? " (Battle Group)" : " (Group)") :
					"");
		}
	}

	[ORKEditorHelp("Change Status Value", "Changes the status value of a combatant or it's whole group.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ChangeStatusValueStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Whole Group", "The status value of the whole group of the combatant will be changed.\n" +
			"If disabled, only the status value of the selected combatant will be changed.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be used.\n" +
			"If disabled, all active members of the combatant's group will be used.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;


		// changes
		[ORKEditorHelp("Status Value", "Select the status value that will be changed.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue, separator=true, labelText="Status Value Changes")]
		public int id2 = 0;

		[ORKEditorHelp("Initialize", "Initializes the status value with the defined value.\n" +
			"The status value's base and current value will be set to the defined value.", "")]
		public bool init = false;

		[ORKEditorHelp("Ignore Barrier", "Ignore the barrier values of 'Consumable' type status values and " +
			"target the status value directly.\n" +
			"If disabled, any barrier status values will first try to consume damage.", "")]
		[ORKEditorLayout("init", false)]
		public bool ignoreBarrier = false;

		[ORKEditorHelp("Show Notification", "The status value's change text and HUD flash will be displayed.", "")]
		public bool notify = false;

		[ORKEditorHelp("Show Critical", "The notification will use the critical notification settings " +
			"of the status value (if defined).", "")]
		[ORKEditorLayout("notify", true, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool notifyCritical = false;

		[ORKEditorHelp("Show Console", "The status value's change will be displayed in the console.", "")]
		public bool console = false;

		[ORKEditorHelp("Set In", "Either set the value in Percent or the given Value.\n" +
			"'Consumable' type status values use their maximum status value to calculate the Percent value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public ValueSetter setIn = ValueSetter.Value;

		[ORKEditorHelp("Operator", "Decides how the status value will be changed.\n" +
			"- Add: The value will be added to the status value.\n" +
			"- Sub: The value will be subtracted from the status value.\n" +
			"- Set: The status value will be set to the value.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		[ORKEditorLayout(endCheckGroup=true)]
		public SimpleOperator op = SimpleOperator.Add;

		public EventInteger value = new EventInteger();

		public ChangeStatusValueStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						if(list[i].Group != null)
						{
							List<Combatant> cs = null;
							if(this.onlyBattle)
							{
								cs = list[i].Group.GetBattle();
							}
							else
							{
								cs = list[i].Group.GetGroup();
							}
							for(int j = 0; j < cs.Count; j++)
							{
								this.Change(cs[j], baseEvent);
							}
						}
					}
					else
					{
						this.Change(list[i], baseEvent);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}

		private void Change(Combatant c, BaseEvent baseEvent)
		{
			StatusValue status = c.Status[this.id2];
			int tmpValue = this.value.GetValue(baseEvent);
			if(this.init)
			{
				status.InitValue(tmpValue);
			}
			else
			{
				if(ValueSetter.Percent.Equals(this.setIn))
				{
					float tmp = status.GetMaxValue();
					tmp *= tmpValue;
					tmp /= 100;
					tmpValue = (int)tmp;
				}

				if(SimpleOperator.Add.Equals(this.op))
				{
					if(status.IsNormal())
					{
						status.AddBaseValue(tmpValue);
					}
					status.AddValue(tmpValue, this.notifyCritical, false, false,
						this.ignoreBarrier, this.notify, this.console);
				}
				else if(SimpleOperator.Sub.Equals(this.op))
				{
					if(status.IsNormal())
					{
						status.AddBaseValue(-tmpValue);
					}
					status.AddValue(-tmpValue, this.notifyCritical, false, false,
						this.ignoreBarrier, this.notify, this.console);
				}
				else if(SimpleOperator.Set.Equals(this.op))
				{
					if(status.IsNormal())
					{
						status.SetBaseValue(tmpValue);
					}
					status.SetValue(tmpValue, this.notifyCritical, false, false,
						this.ignoreBarrier, this.notify, this.console);
				}
			}
			c.MarkStatusBoundsCheck();
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.StatusValues.GetName(this.id2) + " " +
				this.op + " " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Change Status Effect", "Changes the status effects of a combatant or it's whole group.\n" +
		"The combatant is used as caster and target of the status effect.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ChangeStatusEffectStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be used.\n" +
			"If the actor doesn't have a combatant, next step will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Whole Group", "The status effects of the whole group of the combatant will be changed.\n" +
			"If disabled, only the status effects of the selected combatant will be changed.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be used.\n" +
			"If disabled, all active members of the combatant's group will be used.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;


		// changes
		[ORKEditorArray(true, "Add Status Effect", "Add a status effect cast to the list.", "",
			"Remove", "Remove this status effect cast from the list.", "", noRemoveCount=1)]
		[ORKEditorInfo(separator=true, labelText="Status Effect Changes")]
		public StatusEffectCast[] effect = new StatusEffectCast[] {new StatusEffectCast()};

		public ChangeStatusEffectStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						if(list[i].Group != null)
						{
							List<Combatant> cs = null;
							if(this.onlyBattle)
							{
								cs = list[i].Group.GetBattle();
							}
							else
							{
								cs = list[i].Group.GetGroup();
							}
							for(int j = 0; j < cs.Count; j++)
							{
								this.Change(cs[j]);
							}
						}
					}
					else
					{
						this.Change(list[i]);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}

		private void Change(Combatant c)
		{
			for(int i = 0; i < this.effect.Length; i++)
			{
				this.effect[i].ChangeEffect(c, c);
			}
		}
	}

	[ORKEditorHelp("Level Up", "Increases the level or class level of a combatant or it's whole group by one.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class LevelUpStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be leveled up.\n" +
			"If the actor doesn't have a combatant, no one will level up.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Whole Group", "The whole group of the combatant will be leveled up.\n" +
			"If disabled, only the selected combatant will be checked.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be leveled up.\n" +
			"If disabled, all active members of the combatant's group will be leveled up.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;

		[ORKEditorHelp("Class Level Up", "The combatant's class level will be leveld up.\n" +
			"If disabled, the combatant's base level will be leveled up.", "")]
		public bool doClass = false;

		public LevelUpStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						List<Combatant> group = this.onlyBattle ?
							list[i].Group.GetBattle() :
							list[i].Group.GetGroup();

						for(int j = 0; j < group.Count; j++)
						{
							if(group[j] != null)
							{
								this.LevelUp(group[j]);
							}
						}
					}
					else
					{
						this.LevelUp(list[i]);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}

		private void LevelUp(Combatant combatant)
		{
			if(this.doClass)
			{
				combatant.ForceClassLevelUp();
			}
			else
			{
				combatant.ForceLevelUp();
			}
		}
	}

	[ORKEditorHelp("Initialize to Level", "Initialize a combatant or it's whole group to a defined level.\n" +
		"The current equipment of the combatant(s) will be unequipped.\n" +
		"All progress a combatant made will be lost.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class InitializeToLevelStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be initialized to a level.\n" +
			"If the actor doesn't have a combatant, no one will be initialized.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Whole Group", "The whole group of the combatant will be leveled up.\n" +
			"If disabled, only the selected combatant will be checked.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be leveled up.\n" +
			"If disabled, all active members of the combatant's group will be leveled up.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;


		// level
		[ORKEditorInfo(separator=true, labelText="Level Settings")]
		public LevelInitSettings level = new LevelInitSettings();


		// class level
		[ORKEditorInfo(separator=true, labelText="Class Level Settings")]
		public LevelInitSettings classLevel = new LevelInitSettings();

		public InitializeToLevelStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.wholeGroup)
					{
						List<Combatant> group = this.onlyBattle ?
							list[i].Group.GetBattle() :
							list[i].Group.GetGroup();

						for(int j = 0; j < group.Count; j++)
						{
							if(group[j] != null)
							{
								this.InitLevel(group[j]);
							}
						}
					}
					else
					{
						this.InitLevel(list[i]);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}

		private void InitLevel(Combatant combatant)
		{
			combatant.Equipment.UnequipAll(combatant.Inventory);
			combatant.Init(this.level.GetLevel(combatant),
				this.classLevel.GetClassLevel(combatant),
				combatant.ClassID);
		}
	}

	[ORKEditorHelp("Change Class", "Change the class of a combatant.\n" +
		"The combatant will unequip all equipment before changing class.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ChangeClassStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will change class.\n" +
			"If the actor doesn't have a combatant, no one will change class.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		public ClassChange change = new ClassChange();

		public ChangeClassStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				this.change.Change(list[i]);
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "Actor " + this.id + ": " + change.GetInfoText();
		}
	}

	[ORKEditorHelp("Learn Ability", "A combatant will learn a defined ability.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class LearnAbilityStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will learn the ability.\n" +
			"If the actor doesn't have a combatant, no one will learn the ability.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Ability", "Select the ability the combatant will learn.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int id2 = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be learned.", "")]
		[ORKEditorLimit(1, false)]
		public int lvl = 1;

		[ORKEditorHelp("Group Ability", "The ability will be learned by the group of the actor, " +
			"i.e. all group members will have access to it.\n" +
			"If disabled, only one combatant learns the ability.", "")]
		public bool isGroupAbility = false;

		[ORKEditorHelp("Show Console", "Learning the ability will be displayed in the console.", "")]
		public bool showConsole = true;

		public LearnAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.isGroupAbility)
					{
						list[i].Group.Abilities.Learn(this.id2, this.lvl, this.showConsole);
					}
					else
					{
						list[i].Abilities.Learn(this.id2, this.lvl, this.showConsole);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Abilities.Get(this.id2).GetName(lvl);
		}
	}

	[ORKEditorHelp("Forget Ability", "A combatant will forget a defined ability.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ForgetAbilityStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will forget the ability.\n" +
			"If the actor doesn't have a combatant, no one will forget the ability.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Ability", "Select the ability the combatant will forget.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int id2 = 0;

		[ORKEditorHelp("Group Ability", "The ability will be forgotten by the group of the actor, " +
			"i.e. all group members that only had the ability through " +
			"group abilities will not be able to use it any longer.\n" +
			"If disabled, only one combatant learns the ability.", "")]
		public bool isGroupAbility = false;

		[ORKEditorHelp("Show Console", "Forgetting this ability will be displayed in the console.", "")]
		public bool showConsole = true;

		public ForgetAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.isGroupAbility)
					{
						list[i].Group.Abilities.Forget(this.id2, this.showConsole);
					}
					else
					{
						list[i].Abilities.Forget(this.id2, this.showConsole);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Abilities.GetName(this.id2);
		}
	}

	[ORKEditorHelp("Learn Ability Tree", "A combatant will learn a defined ability tree.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class LearnAbilityTreeStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will learn the ability tree.\n" +
			"If the actor doesn't have a combatant, no one will learn the ability tree.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Ability Tree", "Select the ability tree the combatant will learn.", "")]
		[ORKEditorInfo(ORKDataType.AbilityTree)]
		public int id2 = 0;

		[ORKEditorHelp("Show Console", "Learning this ability tree will be displayed in the console.", "")]
		public bool showConsole = true;

		public LearnAbilityTreeStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.LearnTree(this.id2, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.AbilityTrees.GetName(this.id2);
		}
	}

	[ORKEditorHelp("Forget Ability Tree", "A combatant will forget a defined ability tree.\n" +
		"Abilities already learned through the ability tree will still be available to the combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ForgetAbilityTreeStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will forget the ability tree.\n" +
			"If the actor doesn't have a combatant, no one will forget the ability tree.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Ability Tree", "Select the ability tree the combatant will forget.\n" +
			"Abilities already learned through the ability tree will still be available to the combatant.", "")]
		[ORKEditorInfo(ORKDataType.AbilityTree)]
		public int id2 = 0;

		[ORKEditorHelp("Show Console", "Forgetting this ability tree will be displayed in the console.", "")]
		public bool showConsole = true;

		public ForgetAbilityTreeStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.ForgetTree(this.id2, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.AbilityTrees.GetName(this.id2);
		}
	}

	[ORKEditorHelp("Add Temporary Ability", "Adds a temporary ability to a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class AddTemporaryAbilityStep : BaseEventStep
	{
		[ORKEditorHelp("Ability", "Select the ability that will be added as temporary ability.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be added.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Auto Remove After", "The ability will automatically be removed after:" +
			"- None: Doesn't remove the ability automatically.\n" +
			"- Turn: Removes the ability after a defined amount of turns.\n" +
			"- Time: Removes the ability after a defind amount of time in seconds.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter removeType = EndAfter.None;

		[ORKEditorLayout("removeType", EndAfter.None, elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventFloat removeAfter;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public AddTemporaryAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.AddTemporaryAbility(this.abilityID, this.level, 
						this.removeType, !EndAfter.None.Equals(this.removeType) ? 
							this.removeAfter.GetValue(baseEvent) : -1);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				ORK.Abilities.Get(this.abilityID).GetName(level);
		}
	}

	[ORKEditorHelp("Remove Temporary Ability", "Removes a temporary ability from a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class RemoveTemporaryAbilityStep : BaseEventStep
	{
		[ORKEditorHelp("Remove All", "All temporary abilities will be removed.", "")]
		public bool all = false;

		[ORKEditorHelp("Ability", "Select the ability that will be removed from the temporary abilities.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int abilityID = 0;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public RemoveTemporaryAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.all)
					{
						list[i].Abilities.ClearTemporaryAbilities();
					}
					else
					{
						list[i].Abilities.RemoveTemporaryAbility(this.abilityID);
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + 
				(this.all ? ": All" : ": " + ORK.Abilities.Get(this.abilityID).GetName());
		}
	}

	[ORKEditorHelp("Check Status", "Checks a combatant on certain status requirements, e.g. status value.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps", "Check Steps")]
	public class CheckStatusStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorHelp("Whole Group", "The whole group of the combatant will be checked.\n" +
			"If disabled, only the selected combatant will be checked.", "")]
		public bool wholeGroup = false;

		[ORKEditorHelp("Only Battle Group", "Only members of the battle group will be checked.\n" +
			"If disabled, all active members of the combatant's group will be checked.", "")]
		[ORKEditorLayout("wholeGroup", true, endCheckGroup=true)]
		public bool onlyBattle = false;


		// requirements
		[ORKEditorHelp("Needed", "Either ALL or only ONE requirement must be met.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[] {new StatusRequirement()};

		public CheckStatusStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool check = true;
			bool any = false;

			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					any = true;
					if(this.wholeGroup)
					{
						if(list[i].Group != null)
						{
							List<Combatant> cs = null;
							if(this.onlyBattle)
							{
								cs = list[i].Group.GetBattle();
							}
							else
							{
								cs = list[i].Group.GetGroup();
							}
							if(!this.CheckGroup(cs))
							{
								check = false;
								break;
							}
						}
					}
					else
					{
						if(!StatusRequirement.Check(list[i], this.req, this.needed))
						{
							check = false;
							break;
						}
					}
				}
			}

			if(any && check)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool CheckGroup(List<Combatant> cs)
		{
			for(int i = 0; i < cs.Count; i++)
			{
				if(!StatusRequirement.Check(cs[i], this.req, this.needed))
				{
					return false;
				}
			}
			return true;
		}
	}

	[ORKEditorHelp("Status Fork", "Checks a combatant for certain status requirements.\n" +
		"If a requirement is valid, it's next step will be executed.\n" +
		"If no requirement is valid, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Status Steps", "Check Steps")]
	public class StatusForkStep : BaseEventStep
	{
		[ORKEditorHelp("Actor", "Select the actor that will be checked.\n" +
			"If the actor doesn't have a combatant, next step fail will be executed.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		public int id = 0;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be valid.", ""
		})]
		public StatusRequirementNextNode[] req = new StatusRequirementNextNode[] {new StatusRequirementNextNode()};

		public StatusForkStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;

			List<Combatant> list = baseEvent.GetActorCombatant(this.id);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(this.Check(ref check, list[i]))
					{
						break;
					}
				}
			}

			baseEvent.StepFinished(check);
		}

		private bool Check(ref int check, Combatant combatant)
		{
			for(int i = 0; i < this.req.Length; i++)
			{
				if(this.req[i].CheckRequirement(combatant))
				{
					check = this.req[i].next;
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return "Requirement " + (index - 1) + ": " + this.req[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.req.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.req[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.req[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Check Combatant", "Checks if an object is a selected combatant.\n" +
		"If the object is the selected combatant, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Status Steps", "Check Steps")]
	public class CheckCombatantStep : BaseEventCheckStep
	{
		// combatant
		[ORKEditorHelp("Combatant", "Select the combatant that will be checked.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		public int id = 0;

		//object
		[ORKEditorInfo(separator=true, labelText="Check Object")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public CheckCombatantStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			bool valid = false;

			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].RealID == this.id)
				{
					valid = true;
					break;
				}
			}

			if(valid)
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Combatants.GetName(this.id);
		}
	}

	[ORKEditorHelp("Change Defence Attribute", "Changes the defence attribute of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ChangeDefenceAttributeStep : BaseEventStep
	{
		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes)]
		public int id = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="id")]
		public int id2 = 0;

		//object
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public ChangeDefenceAttributeStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Status.GetDefenceAttributeID(this.id).InitID(this.id2);
					list[i].MarkResetStatus();
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				ORK.DefenceAttributes.GetName(this.id) + " = " +
				ORK.DefenceAttributes.GetName(this.id, this.id2);
		}
	}

	[ORKEditorHelp("Block Ability Reuse", "Blocks a defined ability's reuse for a defined " +
		"amount of turns or time, or removes the reuse block from a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class BlockAbilityReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();


		// reuse
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability, separator=true, labelText="Ability Settings")]
		public int abilityID = 0;

		[ORKEditorHelp("Reuse After", "The ability can be reused after:" +
			"- None: The ability can be reused immediately (i.e. removes reuse block).\n" +
			"- Turn: The ability can be reused after a set amount of turns.\n" +
			"- Time: The ability can be reused after a set amount of time.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter reuseType = EndAfter.None;

		[ORKEditorHelp("Block Scope", "Select the scope that will be blocked:\n" +
			"- Single: This ability is blocked.\n" +
			"- Type: All abilities of this ability's ability type are blocked.\n" +
			"- Root Type: All abilities of this ability's root ability type are blocked " +
			"(i.e. the uppermost type in the ability type tree and all it's sub-types).\n" +
			"- All: All abilites are blocked.", "")]
		[ORKEditorLayout("reuseType", EndAfter.None, elseCheckGroup=true)]
		public UseBlockScope reuseScope = UseBlockScope.Single;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public EventFloat reuseAfter;

		public BlockAbilityReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(EndAfter.None.Equals(this.reuseType))
					{
						list[i].RemoveUseBlock(UseBlockType.Ability, this.abilityID);
					}
					else
					{
						list[i].AddUseBlock(new UseBlock(UseBlockType.Ability, this.reuseScope, this.abilityID,
							this.reuseAfter.GetValue(baseEvent), this.reuseType));
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				ORK.Abilities.GetName(this.abilityID);
		}
	}

	[ORKEditorHelp("Clear Ability Reuse", "Clears the ability reuse blocks of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ClearAbilityReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public ClearAbilityReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].ClearUseBlock(UseBlockType.Ability);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Block Item Reuse", "Blocks a defined item's reuse for a defined " +
		"amount of turns or time, or removes the reuse block from a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class BlockItemReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();


		// reuse
		[ORKEditorHelp("Item", "Select the item that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Item, separator=true, labelText="Item Settings")]
		public int itemID = 0;

		[ORKEditorHelp("Reuse After", "The item can be reused after:" +
			"- None: The item can be reused immediately (i.e. removes reuse block).\n" +
			"- Turn: The item can be reused after a set amount of turns.\n" +
			"- Time: The item can be reused after a set amount of time.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter reuseType = EndAfter.None;

		[ORKEditorHelp("Block Scope", "Select the scope that will be blocked:\n" +
			"- Single: This item is blocked.\n" +
			"- Type: All items of this item's item type are blocked.\n" +
			"- Root Type: All items of this items's root item type are blocked " +
			"(i.e. the uppermost type in the item type tree and all it's sub-types).\n" +
			"- All: All items are blocked.", "")]
		[ORKEditorLayout("reuseType", EndAfter.None, elseCheckGroup=true)]
		public UseBlockScope reuseScope = UseBlockScope.Single;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public EventFloat reuseAfter;

		public BlockItemReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(EndAfter.None.Equals(this.reuseType))
					{
						list[i].RemoveUseBlock(UseBlockType.Item, this.itemID);
					}
					else
					{
						list[i].AddUseBlock(new UseBlock(UseBlockType.Item, this.reuseScope, this.itemID,
							this.reuseAfter.GetValue(baseEvent), this.reuseType));
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				ORK.Items.GetName(this.itemID);
		}
	}

	[ORKEditorHelp("Clear Item Reuse", "Clears the item reuse blocks of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Status Steps")]
	public class ClearItemReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public ClearItemReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].ClearUseBlock(UseBlockType.Item);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Status Value To Variable", "Stores the value of a combatant's status value into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Status Steps", "Variable Steps")]
	public class StatusValueToVariableStep : BaseEventStep
	{
		[ORKEditorHelp("Status Value", "Select the status value that will be used.", "")]
		[ORKEditorInfo(ORKDataType.StatusValue)]
		public int statusValueID = 0;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the status value.\n" +
			"- Base Value: The base value of the status value (without bonuses).\n" +
			"- Min Value: The minimum value of the status value.\n" +
			"- Max Value: The maximum value of the status value.\n" +
			"- Display Value: The currently displayed value of the status value (e.g. when using 'Count To Value').\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.\n" +
			"- Preview Max Value: The preview maximum value, displaying changes when an equipment would be equipped.", "")]
		public StatusValueGetValue getType = StatusValueGetValue.CurrentValue;


		// combatant
		[ORKEditorInfo(separator=true, labelText="User Combatant")]
		public EventObjectSetting userObject = new EventObjectSetting();


		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;

		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;

		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";

		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;

		public StatusValueToVariableStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant user = this.userObject.GetFirstCombatant(baseEvent);

			if(user != null)
			{
				float result = user.Status[this.statusValueID].GetTypeValue(this.getType);

				if(VariableOrigin.Local.Equals(this.origin))
				{
					baseEvent.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					ORK.Game.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent[] comps = list[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								for(int j = 0; j < comps.Length; j++)
								{
									comps[j].GetHandler().ChangeFloat(
										this.key.GetValue(), result, this.floatOperator);
								}
							}
						}
					}
					else
					{
						ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
							this.key.GetValue(), result, this.floatOperator);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText() + "(" + this.origin + ") " +
				this.floatOperator + " " + ORK.StatusValues.GetName(this.statusValueID);
		}
	}

	[ORKEditorHelp("Atk Attribute To Variable", "Stores the value of a combatant's attack attribute into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Status Steps", "Variable Steps")]
	public class AtkAttributeToVariableStep : BaseEventStep
	{
		[ORKEditorHelp("Attack Attribute", "Select the attack attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes)]
		public int attributeID = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.AttackAttributes, idFieldName="attributeID")]
		public int subAttributeID = 0;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public AttributeGetValue getType = AttributeGetValue.CurrentValue;


		// combatant
		[ORKEditorInfo(separator=true, labelText="User Combatant")]
		public EventObjectSetting userObject = new EventObjectSetting();


		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;

		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;

		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";

		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;

		public AtkAttributeToVariableStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant user = this.userObject.GetFirstCombatant(baseEvent);

			if(user != null)
			{
				float result = user.Status.GetAttackAttribute(this.attributeID).
					GetTypeValue(this.subAttributeID, this.getType);

				if(VariableOrigin.Local.Equals(this.origin))
				{
					baseEvent.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					ORK.Game.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent[] comps = list[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								for(int j = 0; j < comps.Length; j++)
								{
									comps[j].GetHandler().ChangeFloat(
										this.key.GetValue(), result, this.floatOperator);
								}
							}
						}
					}
					else
					{
						ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
							this.key.GetValue(), result, this.floatOperator);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText() + "(" + this.origin + ") " +
				this.floatOperator + " " + ORK.AttackAttributes.GetName(this.attributeID, this.subAttributeID);
		}
	}

	[ORKEditorHelp("Def Attribute To Variable", "Stores the value of a combatant's defence attribute into a float game variable.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Status Steps", "Variable Steps")]
	public class DefAttributeToVariableStep : BaseEventStep
	{
		[ORKEditorHelp("Defence Attribute", "Select the defence attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes)]
		public int attributeID = 0;

		[ORKEditorHelp("Attribute", "Select the attribute that will be used.", "")]
		[ORKEditorInfo(ORKDataType.DefenceAttributes, idFieldName="attributeID")]
		public int subAttributeID = 0;

		[ORKEditorHelp("Used Value", "Select which value will be used:\n" +
			"- Current Value: The current value of the attribute.\n" +
			"- Base Value: The base value of the attribute (without bonuses).\n" +
			"- Min Value: The minimum value of the attribute.\n" +
			"- Max Value: The maximum value of the attribute.\n" +
			"- Start Value: The start value of the attribute (i.e. the attribute's initial value).\n" +
			"- Preview Value: The preview value, displaying changes when an equipment would be equipped.", "")]
		public AttributeGetValue getType = AttributeGetValue.CurrentValue;


		// combatant
		[ORKEditorInfo(separator=true, labelText="User Combatant")]
		public EventObjectSetting userObject = new EventObjectSetting();


		// variable settings
		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Local: Local variables are only used in a running event and don't interfere with global variables. " +
			"The variable will be gone once the event ends.\n" +
			"- Global: Global variables are persistent and available everywhere, everytime. " +
			"They can be saved in save games.\n" +
			"- Object: Object variables are bound to objects in the scene by an object ID. " +
			"They can be saved in save games.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Settings")]
		public VariableOrigin origin = VariableOrigin.Global;

		// object variables
		[ORKEditorHelp("Use Object", "Use the 'Object Variables' component of game objects to change the object variables.\n" +
			"The changes will be made on every 'Object Variables' component that is found. " +
			"If no component is found, no variables will be changed.\n" +
			"If disabled, you need to define the object ID used to change the object variables.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("origin", VariableOrigin.Object)]
		public bool useObject = true;

		[ORKEditorInfo(separator=true, labelText="Object")]
		[ORKEditorLayout("useObject", true, autoInit=true)]
		public EventObjectSetting fromObject;

		[ORKEditorHelp("Object ID", "Define the object ID of the object variables.\n" +
			"If the object ID doesn't exist yet, it will be created.", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public string objectID = "";

		// variable key
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue key = new StringValue();

		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		public FormulaOperator floatOperator = FormulaOperator.Set;

		public DefAttributeToVariableStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant user = this.userObject.GetFirstCombatant(baseEvent);

			if(user != null)
			{
				float result = user.Status.GetDefenceAttribute(this.attributeID).
					GetTypeValue(this.subAttributeID, this.getType);

				if(VariableOrigin.Local.Equals(this.origin))
				{
					baseEvent.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Global.Equals(this.origin))
				{
					ORK.Game.Variables.ChangeFloat(this.key.GetValue(),
						result, this.floatOperator);
				}
				else if(VariableOrigin.Object.Equals(this.origin))
				{
					if(this.useObject)
					{
						List<GameObject> list = this.fromObject.GetObject(baseEvent);
						for(int i = 0; i < list.Count; i++)
						{
							if(list[i] != null)
							{
								ObjectVariablesComponent[] comps = list[i].
									GetComponentsInChildren<ObjectVariablesComponent>();
								for(int j = 0; j < comps.Length; j++)
								{
									comps[j].GetHandler().ChangeFloat(
										this.key.GetValue(), result, this.floatOperator);
								}
							}
						}
					}
					else
					{
						ORK.Game.Scene.GetObjectVariables(this.objectID).ChangeFloat(
							this.key.GetValue(), result, this.floatOperator);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.key.GetInfoText() + "(" + this.origin + ") " +
				this.floatOperator + " " + ORK.DefenceAttributes.GetName(this.attributeID, this.subAttributeID);
		}
	}
}
