
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class StatisticSelection : BaseData
	{
		[ORKEditorHelp("Statistic", "Select the statistic value that will be used.", "")]
		public StatisticType type = StatisticType.TotalKilled;
		
		[ORKEditorHelp("Combatant", "Select the combatant that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Combatant)]
		[ORKEditorLayout("type", StatisticType.SingleKilled, endCheckGroup=true)]
		public int combatantID = 0;
		
		[ORKEditorHelp("Item", "Select the item that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Item)]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {StatisticType.SingleUsed, StatisticType.SingleCreatedItem}, 
			needed=Needed.One, endCheckGroup=true)]
		public int itemID = 0;
		
		[ORKEditorHelp("Weapon", "Select the weapon that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Weapon)]
		[ORKEditorLayout("type", StatisticType.SingleCreatedWeapon, endCheckGroup=true)]
		public int weaponID = 0;
		
		[ORKEditorHelp("Armor", "Select the armor that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Armor)]
		[ORKEditorLayout("type", StatisticType.SingleCreatedArmor, endCheckGroup=true)]
		public int armorID = 0;
		
		[ORKEditorInfo(separator=true, labelText="Statistic Index")]
		[ORKEditorLayout("type", StatisticType.Custom, endCheckGroup=true, autoInit=true)]
		public EventInteger customIndex;
		
		public StatisticSelection()
		{
			
		}
		
		
		/*
		============================================================================
		Statistic functions
		============================================================================
		*/
		public void Clear(BaseEvent baseEvent)
		{
			if(StatisticType.SingleKilled.Equals(this.type))
			{
				ORK.Statistic.Clear(this.type, this.combatantID);
			}
			else if(StatisticType.SingleUsed.Equals(this.type) || 
				StatisticType.SingleCreatedItem.Equals(this.type))
			{
				ORK.Statistic.Clear(this.type, this.itemID);
			}
			else if(StatisticType.SingleCreatedWeapon.Equals(this.type))
			{
				ORK.Statistic.Clear(this.type, this.weaponID);
			}
			else if(StatisticType.SingleCreatedArmor.Equals(this.type))
			{
				ORK.Statistic.Clear(this.type, this.armorID);
			}
			else if(StatisticType.Custom.Equals(this.type))
			{
				ORK.Statistic.Clear(this.type, this.customIndex.GetValue(baseEvent));
			}
			else
			{
				ORK.Statistic.Clear(this.type, -1);
			}
		}
		
		public int Get(BaseEvent baseEvent)
		{
			if(StatisticType.SingleKilled.Equals(this.type))
			{
				return ORK.Statistic.Get(this.type, this.combatantID);
			}
			else if(StatisticType.SingleUsed.Equals(this.type) || 
				StatisticType.SingleCreatedItem.Equals(this.type))
			{
				return ORK.Statistic.Get(this.type, this.itemID);
			}
			else if(StatisticType.SingleCreatedWeapon.Equals(this.type))
			{
				return ORK.Statistic.Get(this.type, this.weaponID);
			}
			else if(StatisticType.SingleCreatedArmor.Equals(this.type))
			{
				return ORK.Statistic.Get(this.type, this.armorID);
			}
			else if(StatisticType.Custom.Equals(this.type))
			{
				return ORK.Statistic.Get(this.type, this.customIndex.GetValue(baseEvent));
			}
			else
			{
				return ORK.Statistic.Get(this.type, -1);
			}
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(StatisticType.SingleKilled.Equals(this.type))
			{
				return this.type.ToString() + " " + ORK.Combatants.GetName(this.combatantID);
			}
			else if(StatisticType.SingleUsed.Equals(this.type) || 
				StatisticType.SingleCreatedItem.Equals(this.type))
			{
				return this.type.ToString() + " " + ORK.Items.GetName(this.itemID);
			}
			else if(StatisticType.SingleCreatedWeapon.Equals(this.type))
			{
				return this.type.ToString() + " " + ORK.Weapons.GetName(this.weaponID);
			}
			else if(StatisticType.SingleCreatedArmor.Equals(this.type))
			{
				return this.type.ToString() + " " + ORK.Armors.GetName(this.armorID);
			}
			return this.type.ToString();
		}
	}
}
