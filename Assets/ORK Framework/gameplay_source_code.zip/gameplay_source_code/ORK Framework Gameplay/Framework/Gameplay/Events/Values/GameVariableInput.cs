
using UnityEngine;
using ORKFramework;
using ORKFramework.Display;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class GameVariableInput : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the input field displayed in the GUI box.", "")]
		[ORKEditorArray(ORKDataType.Language)]
		[ORKEditorInfo(expandWidth=true, labelText="Field Name")]
		public string[] name = ArrayHelper.CreateArray(ORK.Languages.Count, "");
		
		
		// variable
		[ORKEditorInfo(separator=true, labelText="Variable Key")]
		public StringValue variableKey = new StringValue();
		
		[ORKEditorHelp("Input Type", "Select the type of the input value (game variable):\n" +
			"- String: A string variable (text field).\n" +
			"- Bool: A bool variable (toggle field).\n" +
			"- Float: A float variable (horizontal slider).\n" +
			"The initial value of the input will be taken from the used game variable.", "")]
		public GameVariableInputType inputType = GameVariableInputType.String;
		
		[ORKEditorHelp("Is Password", "The text field will be used as a password field " +
			"(i.e. the user's input is masked).", "")]
		[ORKEditorLayout("inputType", GameVariableInputType.String, endCheckGroup=true)]
		public bool isPassword = false;
		
		
		// float settings
		[ORKEditorHelp("Operator", "Defines how the variable will be changed:\n" +
			"- Add: Adds the value to the current value of the variable.\n" +
			"- Sub: Subtracts the value from the current value of the variable.\n" +
			"- Multiply: Multiplies the current value of the variable with the value.\n" +
			"- Divide: Divides the current value of the variable by the value.\n" +
			"- Modulo: Uses the modulo operator, current value of the variable % the value.\n" +
			"- Power Of: The current variable value to the power of the value.\n" +
			"- Log: The current variable value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current variable value to the value.", "")]
		[ORKEditorInfo(separator=true, labelText="Start Value (float)")]
		[ORKEditorLayout("inputType", GameVariableInputType.Float)]
		public FormulaOperator floatOperator = FormulaOperator.Set;
		
		[ORKEditorHelp("As Int", "The input value will be treated as an integer, i.e. only whole numbers.", "")]
		[ORKEditorInfo(separator=true)]
		public bool asInt = false;
		
		[ORKEditorInfo(separator=true, labelText="Minimum Value")]
		[ORKEditorLayout(autoInit=true)]
		public EventFloat minValue;
		
		[ORKEditorInfo(separator=true, labelText="Maximum Value")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public EventFloat maxValue;
		
		public GameVariableInput()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(data.Contains<string>("fieldName"))
			{
				string tmp = "";
				data.Get("fieldName", ref tmp);
				this.name[0] = tmp;
			}
		}
		
		
		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public BaseValueInput GetValueInput(BaseEvent baseEvent, VariableHandler variableHandler)
		{
			if(GameVariableInputType.String.Equals(this.inputType))
			{
				return new StringValueInput(
					variableHandler.GetString(this.variableKey.GetValue()), 
					this.name[ORK.Game.Language], this.isPassword);
			}
			else if(GameVariableInputType.Bool.Equals(this.inputType))
			{
				return new BoolValueInput(variableHandler.GetBool(this.variableKey.GetValue()), this.name[ORK.Game.Language]);
			}
			else if(GameVariableInputType.Float.Equals(this.inputType))
			{
				if(this.asInt)
				{
					return new IntValueInput(
						(int)variableHandler.GetFloat(this.variableKey.GetValue()), 
						(int)this.minValue.GetValue(baseEvent), 
						(int)this.maxValue.GetValue(baseEvent), 
						this.name[ORK.Game.Language]);
				}
				else
				{
					return new FloatValueInput(
						variableHandler.GetFloat(this.variableKey.GetValue()), 
						this.minValue.GetValue(baseEvent), 
						this.maxValue.GetValue(baseEvent), 
						this.name[ORK.Game.Language]);
				}
			}
			return null;
		}
		
		public void SetNewValue(VariableHandler variableHandler, BaseValueInput input)
		{
			if(variableHandler != null && input != null)
			{
				if(GameVariableInputType.String.Equals(this.inputType) && 
					input is StringValueInput)
				{
					variableHandler.Set(this.variableKey.GetValue(), ((StringValueInput)input).value);
				}
				else if(GameVariableInputType.Bool.Equals(this.inputType) && 
					input is BoolValueInput)
				{
					variableHandler.Set(this.variableKey.GetValue(), ((BoolValueInput)input).value);
				}
				else if(GameVariableInputType.Float.Equals(this.inputType))
				{
					if(this.asInt && input is IntValueInput)
					{
						variableHandler.ChangeFloat(this.variableKey.GetValue(), 
							((IntValueInput)input).value, this.floatOperator);
					}
					else if(!this.asInt && input is FloatValueInput)
					{
						variableHandler.ChangeFloat(this.variableKey.GetValue(), 
							((FloatValueInput)input).value, this.floatOperator);
					}
				}
			}
		}
	}
}
