
using ORKFramework;
using ORKFramework.Events.Steps;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class ContinueStep
	{
		public float time = 0;
		
		public BaseEventStep step;
		
		public ContinueStep()
		{
			
		}
		
		public ContinueStep(float t, BaseEventStep s)
		{
			this.time = t;
			this.step = s;
		}
		
		public bool DoContinue(float delta, BaseEvent baseEvent)
		{
			this.time -= delta;
			if(this.time <= 0)
			{
				this.step.Continue(baseEvent);
				return true;
			}
			return false;
		}
	}
}
