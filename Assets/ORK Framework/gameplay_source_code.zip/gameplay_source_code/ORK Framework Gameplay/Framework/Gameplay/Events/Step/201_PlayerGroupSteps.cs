
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Create Group", "Creates a new player group.\n" +
		"If a group with the defined ID already exists, no new group will be created.\n" +
		"A player group with ID 0 will be created at the start of the game - this is the default player group.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Player Group Steps")]
	public class CreateGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Group ID", "The ID of the group that will be created.", "")]
		[ORKEditorLimit(1, false)]
		public int id = 1;
		
		public CreateGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.PlayerHandler.AddGroup(this.id);
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Remove Group", "Removes the player group with the defined ID.\n" +
		"The default player group (ID 0) can't be removed.\n" +
		"If the removed group is the active player group, the default group will be set to active group.", "")]
	[ORKEventStep(typeof(GameEvent))]
	[ORKNodeInfo("Player Group Steps")]
	public class RemoveGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Group ID", "The ID of the group that will be removed.", "")]
		[ORKEditorLimit(1, false)]
		public int id = 1;
		
		public RemoveGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.PlayerHandler.RemoveGroup(this.id);
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Change Active Group", "Changes the active player group.\n" +
		"The default player group has ID 0.\n" +
		"When changing the active group, the old group will be removed from the scene " +
		"and the new group will be spawned at the position of the old player.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Player Group Steps")]
	public class ChangeActiveGroupStep : BaseEventStep
	{
		[ORKEditorHelp("Group ID", "The ID of the group that will be the new active group.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		public ChangeActiveGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Game.PlayerHandler.SetActiveGroup(this.id);
			baseEvent.StepFinished(this.next);
		}
	}
	
	[ORKEditorHelp("Check Group", "Checks if a group with a defined ID exists.\n" +
		"If the group exists, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Player Group Steps", "Check Steps")]
	public class CheckGroupStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Group ID", "The ID of the group that will be checked.", "")]
		[ORKEditorLimit(0, false)]
		public int id = 0;
		
		[ORKEditorHelp("Is Active Group", "Checks if the group with the defined ID is the active player group.\n" +
			"If disabled, only the existence of the group is checked.", "")]
		public bool isActive = false;
		
		public CheckGroupStep()
		{
			
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if((this.isActive && ORK.Game.PlayerHandler.IsActiveGroup(this.id)) ||
				(!this.isActive && ORK.Game.PlayerHandler.GroupExists(this.id)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}
}
