
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class MecanimParameter : BaseData
	{
		[ORKEditorHelp("Parameter Name", "The name of the parameter.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string name = "";
		
		[ORKEditorHelp("Value Type", "Select the type of the value that will be set.", "")]
		public MecanimParameterType type = MecanimParameterType.Bool;
		
		
		// bool
		[ORKEditorHelp("Toggle", "Toggle the current bool value.\n" +
			"If disabled, the bool value will be set to the defined value.", "")]
		[ORKEditorLayout("type", MecanimParameterType.Bool)]
		public bool bToggle = false;
			
		[ORKEditorHelp("Bool Value", "The bool value that will be set.", "")]
		[ORKEditorLayout("bToggle", false, endCheckGroup=true, endGroups=2)]
		public bool bVal = false;
		
		
		// other values
		[ORKEditorHelp("Add", "Add the value to the current value.", "")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {MecanimParameterType.Int, MecanimParameterType.Float}, 
			endCheckGroup=true, needed=Needed.One)]
		public bool add = false;
		
		[ORKEditorHelp("Int Value", "The int value that will be set.", "")]
		[ORKEditorLayout("type", MecanimParameterType.Int, endCheckGroup=true)]
		public int iVal = 0;
		
		[ORKEditorHelp("Float Value", "The float value that will be set.", "")]
		[ORKEditorLayout("type", MecanimParameterType.Float, endCheckGroup=true)]
		public float fVal = 0;
		
		
		// ingame
		private int parameterID = 0;
		
		public MecanimParameter()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			this.parameterID = Animator.StringToHash(this.name);
		}
		
		
		/*
		============================================================================
		Value functions
		============================================================================
		*/
		public void Set(Animator animator)
		{
			// set bool
			if(MecanimParameterType.Bool.Equals(this.type))
			{
				if(this.bToggle)
				{
					animator.SetBool(this.parameterID, !animator.GetBool(this.parameterID));
				}
				else
				{
					animator.SetBool(this.parameterID, this.bVal);
				}
			}
			// set int
			else if(MecanimParameterType.Int.Equals(this.type))
			{
				if(this.add)
				{
					animator.SetInteger(this.parameterID, animator.GetInteger(this.parameterID) + this.iVal);
				}
				else
				{
					animator.SetInteger(this.parameterID, this.iVal);
				}
			}
			// set float
			else if(MecanimParameterType.Float.Equals(this.type))
			{
				if(this.add)
				{
					animator.SetFloat(this.parameterID, animator.GetFloat(this.parameterID) + this.fVal);
				}
				else
				{
					animator.SetFloat(this.parameterID, this.fVal);
				}
			}
			// set trigger
			else if(MecanimParameterType.Trigger.Equals(this.type))
			{
				animator.SetTrigger(this.parameterID);
			}
		}
	}
}
