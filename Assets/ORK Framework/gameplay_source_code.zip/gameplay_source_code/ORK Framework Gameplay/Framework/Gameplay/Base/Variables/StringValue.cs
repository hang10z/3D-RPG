
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class StringValue : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the string value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (string).\n" +
			"- Player Prefs: The value of a PlayerPrefs string variable.\n" +
			"- Scene Name: The name of the current scene.", "")]
		public StringValueType type = StringValueType.Value;
		
		[ORKEditorHelp("Value", "Depending on the 'Value Type':\n" +
		 	"- Value: The text will be used as value.\n" +
		 	"- Game Variable: The text is the key (name) of a game variable (string) that holds the value that will be used.\n" +
		 	"- Player Prefs: The text is the key of a PlayerPrefs string variable that holds the value that will be used.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("type", StringValueType.SceneName, elseCheckGroup=true, endCheckGroup=true)]
		public string value = "";
		
		public StringValue()
		{
			
		}
		
		public string GetValue()
		{
			if(StringValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else if(StringValueType.GameVariable.Equals(this.type))
			{
				return ORK.Game.Variables.GetString(this.value);
			}
			else if(StringValueType.PlayerPrefs.Equals(this.type))
			{
				return PlayerPrefs.GetString(this.value);
			}
			else if(StringValueType.SceneName.Equals(this.type))
			{
				return Application.loadedLevelName;
			}
			return "";
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(StringValueType.SceneName.Equals(this.type))
			{
				return "Scene Name";
			}
			else if(StringValueType.Value.Equals(this.type))
			{
				return this.value;
			}
			else
			{
				return this.value + " (" + this.type + ")";
			}
		}
	}
}

