
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Value", "A single value is used.", "")]
	[ORKNodeInfo("Value Steps")]
	public class ValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true, labelText="Value")]
		public FormulaFloat value = new FormulaFloat();
		
		public ValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			ValueHelper.UseOperator(ref result, this.value.GetValue(user, target), this.formulaOperator);
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.value.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Random Value", "A random value between two values is used.", "")]
	[ORKNodeInfo("Value Steps")]
	public class RandomValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();
		
		public RandomValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			float v1 = this.min.GetValue(user, target);
			float v2 = this.max.GetValue(user, target);
			if(v1 < v2)
			{
				ValueHelper.UseOperator(ref result, Random.Range(v1, v2), this.formulaOperator);
			}
			else if(v1 > v2)
			{
				ValueHelper.UseOperator(ref result, Random.Range(v2, v1), this.formulaOperator);
			}
			else
			{
				ValueHelper.UseOperator(ref result, v1, this.formulaOperator);
			}
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " " + this.min.GetInfoText() + " ~ " + this.max.GetInfoText();
		}
	}
	
	[ORKEditorHelp("Minimum Value", "The smaller value of two values is used.", "")]
	[ORKNodeInfo("Value Steps")]
	public class MinimumValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();
		
		public MinimumValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			ValueHelper.UseOperator(ref result, 
				Mathf.Min(this.min.GetValue(user, target), this.max.GetValue(user, target)), 
				this.formulaOperator);
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " min(" + this.min.GetInfoText() + ", " + this.max.GetInfoText() + ")";
		}
	}
	
	[ORKEditorHelp("Maximum Value", "The bigger value of two values is used.", "")]
	[ORKNodeInfo("Value Steps")]
	public class MaximumValueStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		[ORKEditorInfo(separator=true, labelText="Value 1")]
		public FormulaFloat min = new FormulaFloat();
		
		[ORKEditorInfo(separator=true, labelText="Value 2")]
		public FormulaFloat max = new FormulaFloat();
		
		public MaximumValueStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			ValueHelper.UseOperator(ref result, 
				Mathf.Max(this.min.GetValue(user, target), this.max.GetValue(user, target)), 
				this.formulaOperator);
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString() + " max(" + this.min.GetInfoText() + ", " + this.max.GetInfoText() + ")";
		}
	}
}
