
using UnityEngine;
using ORKFramework;
using ORKFramework.Formulas;
using System.Collections.Generic;

namespace ORKFramework.Formulas.Steps
{
	[ORKEditorHelp("Distance", "The distance between user and target is used.", "")]
	[ORKNodeInfo("Position Steps")]
	public class DistanceStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		
		// distance
		[ORKEditorHelp("Ignore Y Distance", "Height differences to the target are ignored when calculating the distance.", "")]
		[ORKEditorInfo(separator=true)]
		public bool ignY = false;
		
		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;
		
		public DistanceStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			ValueHelper.UseOperator(ref result, user.DistanceTo(target, this.ignY, this.ignComRad), this.formulaOperator);
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator.ToString();
		}
	}
	
	[ORKEditorHelp("Check Distance", "The distance between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Position Steps")]
	public class CheckDistanceStep : BaseFormulaCheckStep
	{
		// distance
		[ORKEditorHelp("Ignore Y Distance", "Height differences to the target are ignored when calculating the distance.", "")]
		public bool ignY = false;
		
		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;
		
		
		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		
		// check value
		[ORKEditorHelp("Current Value", "The current value of the formula will be used.\n" +
			"If disabled, a defined value is used for the check.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public bool useCurrent = true;
		
		[ORKEditorLayout("useCurrent", false, endCheckGroup=true, autoInit=true)]
		public FormulaFloat value;
		
		// check value2
		[ORKEditorHelp("Current Value", "The current value of the formula will be used.\n" +
			"If disabled, a defined value is used for the check.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, autoInit=true, setDefault=true, defaultValue=false)]
		public bool useCurrent2 = true;
		
		[ORKEditorLayout("useCurrent2", false, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FormulaFloat value2;
		
		public CheckDistanceStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			if(ValueHelper.CheckVariableValue(user.DistanceTo(target, this.ignY, this.ignComRad), 
				this.useCurrent ? result : this.value.GetValue(user, target), 
				this.useCurrent2 ? result : (this.value2 != null ? this.value2.GetValue(user, target) : 0), 
				this.check))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + (this.useCurrent ? " current" : " " + this.value.GetInfoText());
		}
	}
	
	[ORKEditorHelp("Angle", "The angle between user and target (-180 - 180) is used.", "")]
	[ORKNodeInfo("Position Steps")]
	public class AngleStep : BaseFormulaStep
	{
		// operator
		[ORKEditorHelp("Operator", "The operator decides how this formula step is calculated to the current value of the formula:\n" +
			"- Add: Adds this step's result to the current value of the formula.\n" +
			"- Sub: Subtracts this step's result from the current value of the formula.\n" +
			"- Multiply: Multiplies the current value of the formula with this step's value.\n" +
			"- Divide: Divides the current value of the formula by this step's value.\n" +
			"- Modulo: Uses the modulo operator, current value of the formula % this step's value.\n" +
			"- Power Of: The current formula value to the power of this step's value.\n" +
			"- Log: The current formula value is used in a logarithmic calculation with this step's value as base.\n" +
			"- Set: Sets the current formula value to this step's result.", "")]
		public FormulaOperator formulaOperator = FormulaOperator.Set;
		
		
		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[ORKEditorInfo(separator=true)]
		public bool direction = false;
		
		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;
		
		public AngleStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			float value = 0;
			if(user.GameObject != null && target.GameObject != null)
			{
				if(this.direction)
				{
					value = VectorHelper.HorizontalDirectionAngle(user.GameObject.transform, target.GameObject.transform);
				}
				else if(this.fromTarget)
				{
					value = VectorHelper.HorizontalAngle(target.GameObject.transform, user.GameObject.transform);
				}
				else
				{
					value = VectorHelper.HorizontalAngle(user.GameObject.transform, target.GameObject.transform);
				}
			}
			ValueHelper.UseOperator(ref result, value, this.formulaOperator);
			return this.next;
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.formulaOperator + (this.direction ? " Direction" : "") + (this.fromTarget ? " from Target" : "");
		}
	}
	
	[ORKEditorHelp("Check Angle", "The angle between user and target is checked with " +
		"the current value of the formula or a defined value.\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Position Steps")]
	public class CheckAngleStep : BaseFormulaCheckStep
	{
		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		public bool direction = false;
		
		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;
		
		
		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defind values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;
		
		
		// check value
		[ORKEditorHelp("Current Value", "The current value of the formula will be used.\n" +
			"If disabled, a defined value is used for the check.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public bool useCurrent = true;
		
		[ORKEditorLayout("useCurrent", false, endCheckGroup=true, autoInit=true)]
		public FormulaFloat value;
		
		// check value2
		[ORKEditorHelp("Current Value", "The current value of the formula will be used.\n" +
			"If disabled, a defined value is used for the check.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, autoInit=true, setDefault=true, defaultValue=false)]
		public bool useCurrent2 = true;
		
		[ORKEditorLayout("useCurrent2", false, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FormulaFloat value2;
		
		public CheckAngleStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			float tmpVal = 0;
			if(user.GameObject != null && target.GameObject != null)
			{
				if(this.direction)
				{
					tmpVal = VectorHelper.HorizontalDirectionAngle(user.GameObject.transform, target.GameObject.transform);
				}
				else if(this.fromTarget)
				{
					tmpVal = VectorHelper.HorizontalAngle(target.GameObject.transform, user.GameObject.transform);
				}
				else
				{
					tmpVal = VectorHelper.HorizontalAngle(user.GameObject.transform, target.GameObject.transform);
				}
			}
			if(ValueHelper.CheckVariableValue(tmpVal, 
				this.useCurrent ? result : this.value.GetValue(user, target), 
				this.useCurrent2 ? result : (this.value2 != null ? this.value2.GetValue(user, target) : 0), 
				this.check))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check + (this.useCurrent ? " current" : " " + this.value.GetInfoText()) + 
				(this.direction ? " Direction" : "") + (this.fromTarget ? " from Target" : "");
		}
	}
	
	[ORKEditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is true, 'Success' will be executed next, else 'Failed'.", "")]
	[ORKNodeInfo("Check Steps", "Position Steps")]
	public class CheckOrientationStep : BaseFormulaCheckStep
	{
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true)]
		public Orientation orientation = Orientation.Front;
		
		[ORKEditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;
		
		public CheckOrientationStep()
		{
			
		}
		
		public override int Calculate(ref float result, Combatant user, Combatant target)
		{
			Orientation check = Orientation.None;
			if(user.GameObject != null && target.GameObject != null)
			{
				if(this.fromTarget)
				{
					check = VectorHelper.GetOrientation(target.GameObject.transform, user.GameObject.transform);
				}
				else
				{
					check = VectorHelper.GetOrientation(user.GameObject.transform, target.GameObject.transform);
				}
			}
			if(Orientation.None.Equals(this.orientation) || this.orientation.Equals(check))
			{
				return this.next;
			}
			else
			{
				return this.nextFail;
			}
		}
		
		
		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}
	}
}
