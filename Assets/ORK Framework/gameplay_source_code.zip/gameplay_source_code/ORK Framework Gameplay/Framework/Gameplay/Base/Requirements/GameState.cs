
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class GameState : BaseData
	{
		// player control
		[ORKEditorHelp("In Control", "Select the required player control state:\n" +
			"- Yes: The player can be controlled.\n" +
			"- No: The player can't be controlled.\n" +
			"- Ignore: Player control state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inControl = Consider.Ignore;
		
		[ORKEditorHelp("Shop", "Select the required shop state:\n" +
			"- Yes: A control blocking shop is displayed.\n" +
			"- No: No control blocking shop is displayed.\n" +
			"- Ignore: Shop state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inShop = Consider.Ignore;
		
		
		// event/scene change
		[ORKEditorHelp("In Event", "Select the required event state:\n" +
			"- Yes: In a blocking event.\n" +
			"- No: Not in a blocking event.\n" +
			"- Ignore: Event state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inEvent = Consider.Ignore;
		
		[ORKEditorHelp("Changing Scene", "Select the required scene change state:\n" +
			"- Yes: Changing scenes.\n" +
			"- No: Not changing scenes.\n" +
			"- Ignore: Scene changes are ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inSceneChange = Consider.Ignore;
		
		
		// pause
		[ORKEditorHelp("Game Paused", "Select the required game pause state:\n" +
			"- Yes: The game is paused.\n" +
			"- No: The game isn't paused.\n" +
			"- Ignore: Pause state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50)]
		public Consider inPause = Consider.Ignore;
		
		
		// battle
		[ORKEditorHelp("In Battle", "Select the required battle state:\n" +
			"- Yes: In a battle.\n" +
			"- No: Outside of battles.\n" +
			"- Ignore: Battle state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50, separator=true, 
			labelText="Battle Types")]
		public Consider inBattle = Consider.Ignore;
		
		// system types
		[ORKEditorHelp("Turn Based", "Available in 'Turn Based' battles.", "")]
		[ORKEditorLayout("inBattle", Consider.Yes)]
		public bool turnBased = true;
		
		[ORKEditorHelp("Active Time", "Available in 'Active Time' battles.", "")]
		public bool activeTime = true;
		
		[ORKEditorHelp("Real Time", "Available in 'Real Time' battles.", "")]
		public bool realTime = true;
		
		[ORKEditorHelp("Phase", "Available in 'Phase' battles.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool phase = true;
		
		
		// menu screens
		[ORKEditorHelp("Blocking Menu Screen", "Select the required menu state:\n" +
			"- Yes: A control blocking menu screen is displayed.\n" +
			"- No: No control blocking menu screen is displayed.\n" +
			"- Ignore: Menu screen state is ignored.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=50, separator=true, 
			labelText="Menu Screens")]
		public Consider inMenu = Consider.Ignore;
		
		[ORKEditorHelp("Opened Menu Screen", "Select the menu screen that must be opened.", "")]
		[ORKEditorInfo(ORKDataType.MenuScreen, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Menu Screen", "Adds a menu screen - " +
			"only one of the added menu screens has to be opened.\n" +
			"Add none to ignore which menu screen is opened.", "",
			"Remove", "Removes this menu screen.", "", isHorizontal=true)]
		[ORKEditorLayout("inMenu", Consider.Yes, endCheckGroup=true)]
		public int[] screenID = new int[0];
		
		public GameState()
		{
			
		}
		
		public GameState(Consider consider)
		{
			this.inControl = consider;
			this.inMenu = consider;
			this.inShop = consider;
			this.inEvent = consider;
			this.inSceneChange = consider;
			this.inPause = consider;
			this.inBattle = consider;
		}
		
		public bool Check()
		{
			return (Consider.Ignore.Equals(this.inControl) || 
					Consider.No.Equals(this.inControl) == ORK.Control.Blocked) && 
				(Consider.Ignore.Equals(this.inShop) || 
					Consider.Yes.Equals(this.inShop) == ORK.Control.InShop) && 
				(Consider.Ignore.Equals(this.inEvent) || 
					Consider.Yes.Equals(this.inEvent) == ORK.Control.InEvent) && 
				(Consider.Ignore.Equals(this.inSceneChange) || 
					Consider.Yes.Equals(this.inSceneChange) == ORK.Control.ChangingScene) && 
				(Consider.Ignore.Equals(this.inPause) || 
					Consider.Yes.Equals(this.inPause) == ORK.Game.Paused) && 
				(Consider.Ignore.Equals(this.inBattle) || 
					(Consider.No.Equals(this.inBattle) && !ORK.Control.InBattle) || 
					(Consider.Yes.Equals(this.inBattle) == ORK.Control.InBattle && 
			// battle system type
				((this.turnBased && ORK.Battle.IsTurnBased()) || 
					(this.activeTime && ORK.Battle.IsActiveTime()) || 
					(this.realTime && ORK.Battle.IsRealTime()) || 
					(this.phase && ORK.Battle.IsPhase())))) && 
			// menu screens
				(Consider.Ignore.Equals(this.inMenu) || 
					(Consider.No.Equals(this.inMenu) && !ORK.Control.InMenu) || 
					(Consider.Yes.Equals(this.inMenu) == ORK.Control.InMenu && 
					this.CheckMenuScreens()));
		}
		
		public bool CheckMenuScreens()
		{
			if(this.screenID != null && this.screenID.Length > 0)
			{
				for(int i=0; i<this.screenID.Length; i++)
				{
					if(MenuStatus.Opened.Equals(ORK.MenuScreens.Get(this.screenID[i]).Status))
					{
						return true;
					}
				}
				return false;
			}
			return true;
		}
	}
}
