
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ControlMapKey : BaseData
	{
		// input settings
		// key
		[ORKEditorHelp("Input Key", "Select the input key used for this control map key.", "")]
		[ORKEditorInfo("Input Settings", "Define the input key and use conditions.", "", 
			isPopup=true, popupType=ORKDataType.InputKey)]
		public int key = 0;
		
		[ORKEditorHelp("Is Axis", "The key name will be used as an axis instead of a button.\n" +
			"Use this setting e.g. for analog sticks.", "")]
		public bool isAxis = false;
		
		[ORKEditorHelp("Trigger At", "The value of the axis on which to trigger the input.\n" +
			"Note that an axis has positive and negative values, so you can have one input at " +
			"e.g. 0.2, another at -0.2, which means you can have input in both directions (using 2 control keys).", "")]
		[ORKEditorLayout("isAxis", true)]
		public float triggerAt = 0;
		
		[ORKEditorHelp("Axis Timeout (s)", "The timeout in seconds between recognizing a key as an axis instead a button.\n" +
			"E.g. when using an analog stick of a joystick the input will be recognized permanently, " +
			"so you can set a timeout to recognize it as a single event.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float axisTimeout = 0.5f;
		
		// conditions
		[ORKEditorHelp("Use Air/Ground", "Recognize if the combatant's game object is in the air or on the ground to enable this key.", "")]
		[ORKEditorInfo(separator=true, labelText="Conditions")]
		public bool useAG = false;
		
		[ORKEditorHelp("In Air", "The input will only be recognized when the combatant is in the air (i.e. not on ground).\n" +
			"For this to work your combatant needs to have a CharacterController component attached.\n" +
			"If disabled, the combatant needs to be on the ground.", "")]
		[ORKEditorLayout("useAG", true, endCheckGroup=true)]
		public bool inAir = false;
		
		[ORKEditorHelp("Use Speed", "Recognize the combatant's current movement speed to enable this key.", "")]
		public bool useSpeed = false;
		
		[ORKEditorHelp("Minimum Speed", "The minimum movement speed of the combatant to recognize the input.\n" +
			"Use this setting for e.g. sprint attacks, etc.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useSpeed", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minSpeed = 0;
		
		
		// action settings
		[ORKEditorHelp("Type", "Select the what this control map key will perform:\n" +
			"- Action: An action is performed (e.g. an attack or ability).\n" +
			"- Shortcut: A shortcut slot is used.\n" +
			"- Auto Attack: Enable/disable the auto attack.", "")]
		[ORKEditorInfo("Action Settings", "Define the action that will be used upon key input.", "")]
		public ControlMapKeyType type = ControlMapKeyType.Action;
		
		// action
		[ORKEditorHelp("Action", "Select the action type this control key triggers:\n" +
			"- Attack: Performs a base attack.\n" +
			"- Counter Attack: Performs a counter attack. Counter attacks can't be countered.\n" +
			"- Ability: Uses an ability.\n" +
			"- Item: Uses an item.\n" +
			"- Defend: Uses the defend command.\n" +
			"- Escape: Uses the escape command.\n" +
			"- Death: The combatant dies.\n" +
			"- None: Does nothing.\n" +
			"- Change Member: The combatant is exchanged with a non-battle group member.", "")]
		[ORKEditorLayout("type", ControlMapKeyType.Action)]
		public ActionSelectType selection = ActionSelectType.Attack;
		
		// attack
		[ORKEditorHelp("Attack Index", "Set the index of the base attack that will be used, e.g.:\n" +
			"- 0: Index of the first base attack.\n" +
			"- 1: Index of the second base attack.\n" +
			"Attack index 0 can always be used, the others only if the combatant currently has the set attack index.", "")]
		[ORKEditorLayout("selection", ActionSelectType.Attack)]
		[ORKEditorLimit(0, false)]
		public int attackIndex = 0;
		
		[ORKEditorHelp("Force Index", "The defind attack index is forced (if available).\n" +
			"The attack will be performed, even if the user's attack index isn't set to this index " +
			"(i.e. you can use the attack outside of attack combos).\n" +
			"If disabled, the user's attack index has to be set to the defined index - " +
			"the attack can only be performed in sequence.", "")]
		public bool forceAttackIndex = false;
		
		[ORKEditorHelp("Reset Index", "The attack index will be reset to 0 after the attack is used.\n" +
			"This only happens if the attack is used.", "")]
		public bool resetAttackIndex = false;
		
		// equipment part attack
		[ORKEditorHelp("Use Equipment Part", "Use the attack of a selected equipment part.\n" +
			"If disabled, the usual base attack is used " +
			"(i.e. either the attack of an equipped weapon or the default attack).", "")]
		[ORKEditorInfo(separator=true)]
		public bool useEquipmentPart = false;
		
		[ORKEditorHelp("Equipment Part", "Select the equipment part used to attack.\n" +
			"Can only be used if the equipment part has a weapon with 'Override Attack' equipped.", "")]
		[ORKEditorInfo(ORKDataType.EquipmentPart)]
		[ORKEditorLayout("useEquipmentPart", true, endCheckGroup=true, endGroups=2)]
		public int equipmentPartID = 0;
		
		// other actions
		[ORKEditorHelp("Selection", "Select the ability/item that will be used.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="selection")]
		[ORKEditorLayout(new string[] {"selection", "selection"}, 
			new System.Object[] {ActionSelectType.Ability, ActionSelectType.Item}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2)]
		public int useID = 0;
		
		// member index
		[ORKEditorHelp("Member Index", "The index of the non-battle member the combatant will be exchanged with.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout("selection", ActionSelectType.ChangeMember, endCheckGroup=true)]
		public int memberIndex = 0;
		
		
		// shorcut
		[ORKEditorHelp("Group Shortcut", "Use the group shortcuts of the combatant's group.\n" +
			"If disabled, the combatant's individual shortcuts will be used.", "")]
		[ORKEditorLayout("type", ControlMapKeyType.Shortcut)]
		public bool isGroupShortcut = false;
		
		[ORKEditorHelp("Slot Index", "The index of the shortcut slot that will be used.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		[ORKEditorLimit(0, false)]
		public int shortcutIndex = 0;
		
		
		// show tooltip
		[ORKEditorHelp("Show Tooltip", "Show the action/shortcut as a tooltip.\n" +
			"A 'Tooltip' HUD can display the information.\n" +
			"When using 'Action', this is only used for ability and item actions.", "")]
		[ORKEditorInfo(separator=true, labelText="Tooltip Settings")]
		[ORKEditorLayout(new string[] {"type", "type"}, 
			new System.Object[] {ControlMapKeyType.Action, ControlMapKeyType.Shortcut}, 
			needed=Needed.One, setDefault=true)]
		public bool showTooltip = false;
		
		[ORKEditorHelp("2nd Call Closes", "Calling the tooltip for the same action/shortcut a 2nd time will close the tooltip.\n" +
			"This only happens if the used ability/item is the same.", "")]
		[ORKEditorLayout("showTooltip", true)]
		public bool closeOn2nd = true;
		
		[ORKEditorHelp("Auto Close", "Auto close the tooltip after a defind amount of time.\n" +
			"If disabled, the tooltip will stay opened until the control key is used a 2nd time.", "")]
		public bool autoCloseTooltip = false;
		
		[ORKEditorHelp("Close After (s)", "The time in seconds until the tooltip will be closed.", "")]
		[ORKEditorLayout("autoCloseTooltip", true, endCheckGroup=true)]
		public float autoCloseTime = 3;
		
		
		// auto target
		[ORKEditorHelp("Use Auto Target", "Automatically selects the action's targets using the user's AI settings.\n" +
			"The group target is ignored.", "")]
		[ORKEditorInfo(separator=true, labelText="Target Settings")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool useAutoTarget = false;
		
		[ORKEditorHelp("Need Targets", "Actions that need target selection require possible targets to display the battle menu.\n" +
			"If no targets are available, the action wont be used and no target menu displayed.\n" +
			"If disabled, the action will display an empty target menu.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useAutoTarget", false, endCheckGroup=true, endGroups=3, 
			setDefault=true, defaultValue=false)]
		public bool needTargets = false;
		
		
		// auto attack
		[ORKEditorHelp("Enable Auto Attack", "If enabled, the combatant's auto attack will be enabled.\n" +
			"If disabled, the combatant's auto attack will be disabled.", "")]
		[ORKEditorLayout("type", ControlMapKeyType.AutoAttack, endCheckGroup=true)]
		public bool enableAutoAttack = false;
		
		
		// requirements
		[ORKEditorHelp("Use Requirements", "Use status requirements and game variable conditions.", "")]
		[ORKEditorInfo("Requirements", "Using this control map key can depend on status requirements and " +
			"game variable conditions.\n" +
			"The combatant using the control map is used for status checks and object game variables.", "")]
		public bool useRequirements = false;
		
		[ORKEditorInfo(separator=true, endFoldout=true)]
		[ORKEditorLayout("useRequirements", true, endCheckGroup=true, autoInit=true)]
		public SimpleCombatantRequirement requirement;
		
		
		// ingame
		private float timeout = 0;
		
		public ControlMapKey()
		{
			
		}
		
		
		/*
		============================================================================
		Key functions
		============================================================================
		*/
		public bool KeyValid(Combatant combatant)
		{
			return this.timeout <= Time.realtimeSinceStartup && 
				(!this.useAG || combatant.Component.InAir == this.inAir) && 
				(!this.useSpeed || combatant.Component.HorizontalSpeed >= this.minSpeed) && 
				this.ControlAccepted() && 
				(!this.useRequirements || this.requirement.Check(combatant));
		}
		
		private bool ControlAccepted()
		{
			bool accept = false;
			if(this.isAxis)
			{
				float a = ORK.InputKeys.Get(this.key).GetAxis();
				if((this.triggerAt < 0 && a < this.triggerAt) ||
					(this.triggerAt > 0 && a > this.triggerAt))
				{
					accept = true;
					this.timeout = Time.realtimeSinceStartup + this.axisTimeout;
				}
			}
			else if(ORK.InputKeys.Get(this.key).GetButton())
			{
				accept = true;
			}
			return accept;
		}
		
		
		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public bool PerformAction(Combatant combatant)
		{
			BaseAction action = null;
			
			// action
			if(ControlMapKeyType.Action.Equals(this.type))
			{
				// attack
				if(ActionSelectType.Attack.Equals(this.selection) && 
					!combatant.Status.BlockAttack)
				{
					if(this.forceAttackIndex)
					{
						// get attack
						AbilityShortcut ability = null;
						if(this.useEquipmentPart)
						{
							if(combatant.Equipment[this.equipmentPartID].Equipped)
							{
								ability = combatant.Equipment[this.equipmentPartID].Equipment.GetCurrentBaseAttack(this.attackIndex);
							}
						}
						else
						{
							ability = combatant.GetBaseAttack(this.attackIndex);
						}
						
						if(ability != null)
						{
							// tooltip
							if(this.showTooltip)
							{
								ORK.GUI.ForceTooltip(ability, this.autoCloseTooltip ? 
									this.autoCloseTime : -1, this.closeOn2nd);
								return true;
							}
							// use
							else if(ActionSelection.UseAbility(combatant, ability, 
								true, this.useAutoTarget, this.needTargets, out action))
							{
								if(this.resetAttackIndex)
								{
									combatant.ResetBaseAttack();
								}
								return true;
							}
						}
					}
					else if(combatant.AttackIndex == this.attackIndex || this.attackIndex == 0)
					{
						if(this.attackIndex == 0)
						{
							combatant.ResetBaseAttack();
						}
						// get attack
						AbilityShortcut ability = null;
						if(this.useEquipmentPart)
						{
							if(combatant.Equipment[this.equipmentPartID].Equipped)
							{
								ability = combatant.Equipment[this.equipmentPartID].Equipment.GetCurrentBaseAttack(combatant.AttackIndex);
							}
						}
						else
						{
							ability = combatant.GetCurrentBaseAttack();
						}
						
						if(ability != null)
						{
							// tooltip
							if(this.showTooltip)
							{
								ORK.GUI.ForceTooltip(ability, this.autoCloseTooltip ? 
									this.autoCloseTime : -1, this.closeOn2nd);
								return true;
							}
							// use
							else if(ActionSelection.UseAbility(combatant, ability, 
								true, this.useAutoTarget, this.needTargets, out action))
							{
								if(this.resetAttackIndex)
								{
									combatant.ResetBaseAttack();
								}
								return true;
							}
						}
					}
				}
				// counter
				else if(ActionSelectType.CounterAttack.Equals(this.selection) && 
					!combatant.Status.BlockAttack)
				{
					AbilityShortcut ability = combatant.GetCounterAttack();
					
					if(ability != null)
					{
						
						// tooltip
						if(this.showTooltip)
						{
							ORK.GUI.ForceTooltip(ability, this.autoCloseTooltip ? 
								this.autoCloseTime : -1, this.closeOn2nd);
							return true;
						}
						// use
						else if(ActionSelection.UseAbility(combatant, ability, 
							true, this.useAutoTarget, this.needTargets, out action))
						{
							return true;
						}
					}
				}
				// ability
				else if(ActionSelectType.Ability.Equals(this.selection) && 
					!combatant.Status.BlockAbilities)
				{
					AbilityShortcut ability = combatant.Abilities.Get(this.useID);
					if(ability != null)
					{
						ability.SetHighestUseLevel(combatant);
						
						// tooltip
						if(this.showTooltip)
						{
							ORK.GUI.ForceTooltip(ability, this.autoCloseTooltip ? 
								this.autoCloseTime : -1, this.closeOn2nd);
							return true;
						}
						// use
						else if(ActionSelection.UseAbility(combatant, ability, 
							true, this.useAutoTarget, this.needTargets, out action))
						{
							return true;
						}
					}
				}
				// item
				else if(ActionSelectType.Item.Equals(this.selection) && !combatant.Status.BlockItems)
				{
					ItemShortcut item = combatant.Inventory.GetItem(this.useID);
					
					if(item != null)
					{
						// tooltip
						if(this.showTooltip)
						{
							ORK.GUI.ForceTooltip(item, this.autoCloseTooltip ? 
								this.autoCloseTime : -1, this.closeOn2nd);
							return true;
						}
						// use
						else if(ActionSelection.UseItem(combatant, item, 
							true, this.useAutoTarget, this.needTargets, out action))
						{
							return true;
						}
					}
				}
				else if(!this.showTooltip)
				{
					// defend
					if(ActionSelectType.Defend.Equals(this.selection) && 
						!combatant.Status.BlockDefend)
					{
						action = new DefendAction(combatant);
					}
					// escape
					else if(ActionSelectType.Escape.Equals(this.selection) && 
						!combatant.Status.BlockEscape)
					{
						action = new EscapeAction(combatant);
					}
					// death
					else if(ActionSelectType.Death.Equals(this.selection))
					{
						action = new DeathAction(combatant, false);
					}
					// none
					else if(ActionSelectType.None.Equals(this.selection))
					{
						action = new NoneAction(combatant);
					}
					// change member
					else if(ActionSelectType.ChangeMember.Equals(this.selection))
					{
						Combatant target = combatant.Group.NonBattleMemberAt(this.memberIndex);
						if(target != null)
						{
							action = new ChangeMemberAction(combatant, target);
						}
					}
				}
			}
			// shortcut
			else if(ControlMapKeyType.Shortcut.Equals(this.type))
			{
				if(this.isGroupShortcut)
				{
					if(combatant.Group.Shortcuts.HasShortcut(this.shortcutIndex))
					{
						// tooltip
						if(this.showTooltip)
						{
							ORK.GUI.ForceTooltip(combatant.Group.Shortcuts[this.shortcutIndex].Shortcut, 
								this.autoCloseTooltip ? this.autoCloseTime : -1, this.closeOn2nd);
							return true;
						}
						// use
						else
						{
							if(combatant.Group.Shortcuts[this.shortcutIndex].Shortcut is EquipShortcut)
							{
								List<Combatant> list = new List<Combatant>();
								list.Add(combatant);
								combatant.Group.Shortcuts[this.shortcutIndex].Shortcut.Use(
									combatant.Group.Shortcuts[this.shortcutIndex].Owner, list, true);
							}
							else if(combatant.Group.Shortcuts[this.shortcutIndex].Shortcut is ItemShortcut && 
								ActionSelection.UseItem(
								combatant.Group.Shortcuts[this.shortcutIndex].Owner, 
									combatant.Group.Shortcuts[this.shortcutIndex].Shortcut as ItemShortcut, 
									true, this.useAutoTarget, this.needTargets, out action))
							{
								return true;
							}
							else if(combatant.Group.Shortcuts[this.shortcutIndex].Shortcut is AbilityShortcut && 
								ActionSelection.UseAbility(
									combatant.Group.Shortcuts[this.shortcutIndex].Owner, 
									combatant.Group.Shortcuts[this.shortcutIndex].Shortcut as AbilityShortcut, 
									true, this.useAutoTarget, this.needTargets, out action))
							{
								return true;
							}
						}
					}
				}
				else
				{
					if(combatant.Shortcuts.HasShortcut(this.shortcutIndex))
					{
						// tooltip
						if(this.showTooltip)
						{
							ORK.GUI.ForceTooltip(combatant.Shortcuts[this.shortcutIndex], 
								this.autoCloseTooltip ? this.autoCloseTime : -1, this.closeOn2nd);
							return true;
						}
						// use
						else
						{
							if(combatant.Shortcuts[this.shortcutIndex] is EquipShortcut)
							{
								List<Combatant> list = new List<Combatant>();
								list.Add(combatant);
								combatant.Shortcuts[this.shortcutIndex].Use(combatant, list, true);
							}
							else if(combatant.Shortcuts[this.shortcutIndex] is ItemShortcut && 
								ActionSelection.UseItem(combatant, 
									combatant.Shortcuts[this.shortcutIndex] as ItemShortcut, 
									true, this.useAutoTarget, this.needTargets, out action))
							{
								return true;
							}
							else if(combatant.Shortcuts[this.shortcutIndex] is AbilityShortcut && 
								ActionSelection.UseAbility(combatant, 
									combatant.Shortcuts[this.shortcutIndex] as AbilityShortcut, 
									true, this.useAutoTarget, this.needTargets, out action))
							{
								return true;
							}
						}
					}
				}
			}
			// auto attack
			else if(ControlMapKeyType.AutoAttack.Equals(this.type))
			{
				combatant.EnableAutoAttack = this.enableAutoAttack;
			}
			
			if(action != null)
			{
				combatant.Actions.Add(action, true);
				return true;
			}
			return false;
		}
	}
}
