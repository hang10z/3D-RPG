
namespace ORKFramework
{
	public class FormulaType : BaseIndexData
	{
		[ORKEditorHelp("Name", "The name of the formula type.\n" +
			"Formula types are only used to filter formulas.", "")]
		[ORKEditorInfo("Formula Type Settings", "Set the name of the formula type.\n"+
			"Formula types are only used to filter formulas.", "", endFoldout=true, expandWidth=true)]
		public string name = "";
		
		public FormulaType()
		{
			
		}
		
		public FormulaType(string n)
		{
			this.name = n;
		}
	}
}

