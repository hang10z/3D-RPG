
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TouchControl
	{
		private Dictionary<int, Vector2> start = new Dictionary<int, Vector2>();
		
		private Dictionary<int, Vector2> hold = new Dictionary<int, Vector2>();
		
		private Dictionary<int, Vector2> end = new Dictionary<int, Vector2>();
		
		private List<int> used = new List<int>();
		
		public TouchControl()
		{
			
		}
		
		public int GetStartWithin(Rect bounds, bool fullScreen)
		{
			foreach(KeyValuePair<int, Vector2> pair in this.start)
			{
				if(!this.used.Contains(pair.Key) && 
					GUIHelper.InGUIRect(VectorHelper.GetScreenPosition(pair.Value, fullScreen), bounds))
				{
					return pair.Key;
				}
			}
			return -1;
		}
		
		public bool CanStart(int count)
		{
			return this.start.Count == count && this.used.Count == 0;
		}
		
		public List<int> GetStarted(bool useFingers)
		{
			List<int> list = new List<int>();
			foreach(KeyValuePair<int, Vector2> pair in this.start)
			{
				list.Add(pair.Key);
				if(!this.hold.ContainsKey(pair.Key))
				{
					this.hold.Add(pair.Key, pair.Value);
				}
			}
			if(useFingers)
			{
				this.start.Clear();
			}
			return list;
		}
		
		public void Use(int fingerID)
		{
			if(!this.used.Contains(fingerID))
			{
				this.used.Add(fingerID);
			}
		}
		
		public Vector2 GetPosition(int fingerID)
		{
			if(this.start.ContainsKey(fingerID))
			{
				return this.start[fingerID];
			}
			else if(this.hold.ContainsKey(fingerID))
			{
				return this.hold[fingerID];
			}
			else if(this.end.ContainsKey(fingerID))
			{
				return this.end[fingerID];
			}
			return new Vector2(Mathf.Infinity, Mathf.Infinity);
		}
		
		public bool IsPhase(int fingerID, InputHandling ih)
		{
			return fingerID != -1 && 
				((InputHandling.Down.Equals(ih) && this.start.ContainsKey(fingerID)) || 
				(InputHandling.Hold.Equals(ih) && this.hold.ContainsKey(fingerID)) || 
				(InputHandling.Up.Equals(ih) && this.end.ContainsKey(fingerID)) || 
				(InputHandling.Any.Equals(ih) && 
					(this.start.ContainsKey(fingerID) || 
					this.hold.ContainsKey(fingerID) || 
					this.end.ContainsKey(fingerID))));
		}
		
		public bool IsPhase(List<int> fingerID, InputHandling ih)
		{
			for(int i=0; i<fingerID.Count; i++)
			{
				if(fingerID[i] != -1 && 
					((InputHandling.Down.Equals(ih) && this.start.ContainsKey(fingerID[i])) || 
						(InputHandling.Hold.Equals(ih) && this.hold.ContainsKey(fingerID[i])) || 
						(InputHandling.Up.Equals(ih) && this.end.ContainsKey(fingerID[i]))) || 
						(InputHandling.Any.Equals(ih) && 
							(this.start.ContainsKey(fingerID[i]) || 
							this.hold.ContainsKey(fingerID[i]) || 
							this.end.ContainsKey(fingerID[i]))))
				{
					return true;
				}
			}
			return false;
		}
		
		public void Tick()
		{
			foreach(int id in this.used)
			{
				if(this.start.ContainsKey(id) && 
					!this.hold.ContainsKey(id))
				{
					this.hold.Add(id, this.start[id]);
				}
			}
			this.used.Clear();
			this.start.Clear();
			this.end.Clear();
			
			// touches
			if(Input.touches.Length > 0)
			{
				for(int i=0; i<Input.touches.Length; i++)
				{
					Touch t = Input.GetTouch(i);
					
					// process existing touches
					if(this.hold.ContainsKey(t.fingerId))
					{
						if(t.phase == TouchPhase.Moved)
						{
							this.hold[t.fingerId] = t.position;
						}
						else if(t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
						{
							if(this.hold.ContainsKey(t.fingerId))
							{
								this.hold.Remove(t.fingerId);
							}
							this.end.Add(t.fingerId, t.position);
						}
					}
					// new touch
					else if(t.phase == TouchPhase.Began)
					{
						this.start.Add(t.fingerId, t.position);
					}
				}
			}
			// mouse
			else
			{
				// process existing touches
				if(this.hold.ContainsKey(-2))
				{
					if(Input.GetMouseButton(0))
					{
						this.hold[-2] = Input.mousePosition;
					}
					else
					{
						if(this.hold.ContainsKey(-2))
						{
							this.hold.Remove(-2);
						}
						this.end.Add(-2, Input.mousePosition);
					}
				}
				// new touch
				else if(Input.GetMouseButtonDown(0))
				{
					this.start.Add(-2, Input.mousePosition);
				}
			}
		}
	}
}
