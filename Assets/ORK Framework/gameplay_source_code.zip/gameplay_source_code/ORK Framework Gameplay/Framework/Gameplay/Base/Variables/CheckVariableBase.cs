
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class CheckVariableBase : BaseData
	{
		[ORKEditorHelp("Is Valid", "The check must be valid.\n" +
			"If disabled, the check must be invalid.", "")]
		[ORKEditorInfo(separator=true)]
		public bool isValid = true;
		
		[ORKEditorHelp("Type", "Select the type of the game variable:\n" +
			"- String: A string variable.\n" +
			"- Bool: A bool variable.\n" +
			"- Float: A float variable.\n" +
			"- Vector3: A Vector3 variable.", "")]
		public GameVariableType type = GameVariableType.String;
		
		
		// string
		[ORKEditorInfo(labelText="String Value")]
		[ORKEditorLayout("type", GameVariableType.String, endCheckGroup=true, autoInit=true)]
		public StringValue stringValue;
		
		
		// float
		[ORKEditorHelp("Check Type", "The check is valid if the current value " +
			"is equal, not equal, less or greater than the defined value.\n" +
			"Range inclusive checks if the current value is between two defind values, including the values.\n" +
			"Range exclusive checks if the current value is between two defined values, excluding the values.\n" +
			"Approximately checks if the current value is similar to the defined value.", "")]
		[ORKEditorLayout("type", GameVariableType.Float)]
		public VariableValueCheck floatCheck = VariableValueCheck.IsEqual;
		
		[ORKEditorInfo(labelText="Float Value", label=new string[] {"The player is used as user and target."})]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue floatValue;
		
		[ORKEditorInfo(labelText="Float Value 2", label=new string[] {"The player is used as user and target."})]
		[ORKEditorLayout(new string[] {"floatCheck", "floatCheck"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, endGroups=2, autoInit=true)]
		public FloatValue floatValue2;
		
		
		// vector3
		[ORKEditorHelp("Check Type", "The check is valid if the distance between the current and the defined value " +
			"is equal, not equal, less or greater than the defined distance.\n" +
			"Range inclusive checks if the distance is between two defind values, including the values.\n" +
			"Range exclusive checks if the distance is between two defined values, excluding the values.\n" +
			"Approximately checks if the distance is similar to the defined value.", "")]
		[ORKEditorLayout("type", GameVariableType.Vector3)]
		public VariableValueCheck vector3Check = VariableValueCheck.IsLess;
		
		[ORKEditorInfo(labelText="Distance")]
		[ORKEditorLayout(autoInit=true)]
		public FloatValue vector3Distance;
		
		[ORKEditorInfo(labelText="Distance 2")]
		[ORKEditorLayout(new string[] {"vector3Check", "vector3Check"}, 
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive}, 
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public FloatValue vector3Distance2;
		
		[ORKEditorInfo(labelText="Vector3 Value")]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public Vector3Value vector3Value;
		
		public CheckVariableBase()
		{
			
		}
		
		public override void SetData(DataObject data)
		{
			base.SetData(data);
			
			if(GameVariableType.Vector3.Equals(this.type) && 
				data.Contains<float>("vector3Distance"))
			{
				float tmp = 0;
				data.Get("vector3Distance", ref tmp);
				this.vector3Distance = new FloatValue(tmp);
			}
		}
		
		public bool Check(string key, VariableHandler handler)
		{
			if(GameVariableType.String.Equals(this.type))
			{
				return this.isValid == handler.Check(key, this.stringValue.GetValue());
			}
			else if(GameVariableType.Bool.Equals(this.type))
			{
				return this.isValid == handler.Check(key, true);
			}
			else if(GameVariableType.Float.Equals(this.type))
			{
				return this.isValid == handler.CheckFloat(key, 
					this.floatValue.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
					this.floatValue2 != null ? 
						this.floatValue2.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader) : 
						0, 
					this.floatCheck);
			}
			else if(GameVariableType.Vector3.Equals(this.type))
			{
				return this.isValid == handler.CheckVector3(key, 
					this.vector3Value.GetValue(), 
					this.vector3Distance.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader), 
					this.vector3Distance2 != null ? 
						this.vector3Distance2.GetValue(ORK.Game.ActiveGroup.Leader, ORK.Game.ActiveGroup.Leader) : 0, 
					this.vector3Check);
			}
			return false;
		}
		
		
		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			return (this.isValid ? "is" : "is not") + " (" + this.type + ") ";
		}
	}
}
