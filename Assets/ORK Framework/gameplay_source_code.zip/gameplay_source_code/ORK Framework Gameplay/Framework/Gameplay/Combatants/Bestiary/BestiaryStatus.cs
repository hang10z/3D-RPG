
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BestiaryStatus : ISaveData
	{
		public bool statusValues = false;
		
		public bool equipment = false;
		
		public BestiaryAttribute[] attackAttribute;
		
		public BestiaryAttribute[] defenceAttribute;
		
		public bool[] defAttrID;
		
		public BestiaryStatus()
		{
			this.Clear();
		}
		
		public BestiaryStatus(DataObject data)
		{
			this.LoadGame(data);
		}
		
		public void Clear()
		{
			this.statusValues = false;
			this.equipment = false;
			
			// attack attribute
			this.attackAttribute = new BestiaryAttribute[ORK.AttackAttributes.Count];
			for(int i=0; i<this.attackAttribute.Length; i++)
			{
				this.attackAttribute[i] = new BestiaryAttribute(ORK.AttackAttributes.Get(i).attribute.Length);
			}
			// defence attribute
			this.defenceAttribute = new BestiaryAttribute[ORK.DefenceAttributes.Count];
			for(int i=0; i<this.defenceAttribute.Length; i++)
			{
				this.defenceAttribute[i] = new BestiaryAttribute(ORK.DefenceAttributes.Get(i).attribute.Length);
			}
			this.defAttrID = new bool[ORK.DefenceAttributes.Count];
		}
		
		public bool IsComplete()
		{
			if(!this.statusValues)
			{
				return false;
			}
			if(!this.equipment)
			{
				return false;
			}
			for(int i=0; i<this.defAttrID.Length; i++)
			{
				if(!this.defAttrID[i])
				{
					return false;
				}
			}
			for(int i=0; i<this.attackAttribute.Length; i++)
			{
				if(!this.attackAttribute[i].IsComplete())
				{
					return false;
				}
			}
			for(int i=0; i<this.defenceAttribute.Length; i++)
			{
				if(!this.defenceAttribute[i].IsComplete())
				{
					return false;
				}
			}
			return true;
		}
		
		
		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public void SetAllAttackAttributes(bool value)
		{
			for(int i=0; i<this.attackAttribute.Length; i++)
			{
				this.attackAttribute[i].SetAll(value);
			}
		}
		
		public void SetAttackAttribute(int id, int id2, bool value)
		{
			if(id >= 0 && id < this.attackAttribute.Length && 
				id2 >= 0 && id2 < this.attackAttribute[id].attribute.Length)
			{
				this.attackAttribute[id].attribute[id2] = value;
			}
		}
		
		public void SetAllDefenceAttributes(bool value)
		{
			for(int i=0; i<this.defenceAttribute.Length; i++)
			{
				this.defenceAttribute[i].SetAll(value);
			}
		}
		
		public void SetDefenceAttribute(int id, int id2, bool value)
		{
			if(id >= 0 && id < this.defenceAttribute.Length && 
				id2 >= 0 && id2 < this.defenceAttribute[id].attribute.Length)
			{
				this.defenceAttribute[id].attribute[id2] = value;
			}
		}
		
		public void SetAllDefenceAttributeIDs(bool value)
		{
			for(int i=0; i<this.defAttrID.Length; i++)
			{
				this.defAttrID[i] = value;
			}
		}
		
		
		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			
			data.Set("statusValues", this.statusValues);
			data.Set("equipment", this.equipment);
			
			// attack attributes
			DataObject[] tmp = new DataObject[this.attackAttribute.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.attackAttribute[i].SaveGame();
			}
			data.Set("attackAttribute", tmp);
			
			// defence attributes
			tmp = new DataObject[this.defenceAttribute.Length];
			for(int i=0; i<tmp.Length; i++)
			{
				tmp[i] = this.defenceAttribute[i].SaveGame();
			}
			data.Set("defenceAttribute", tmp);
			data.Set("defAttrID", this.defAttrID);
			
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.Clear();
			if(data != null)
			{
				data.Get("statusValues", ref this.statusValues);
				data.Get("equipment", ref this.equipment);
				
				// attack attributes
				DataObject[] tmp = data.GetFileArray("attackAttribute");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						if(i < this.attackAttribute.Length)
						{
							this.attackAttribute[i].LoadGame(tmp[i]);
						}
					}
				}
				
				// defence attributes
				tmp = data.GetFileArray("defenceAttribute");
				if(tmp != null)
				{
					for(int i=0; i<tmp.Length; i++)
					{
						if(i < this.defenceAttribute.Length)
						{
							this.defenceAttribute[i].LoadGame(tmp[i]);
						}
					}
				}
				data.Get("defAttrID", out this.defAttrID);
			}
		}
	}
}
