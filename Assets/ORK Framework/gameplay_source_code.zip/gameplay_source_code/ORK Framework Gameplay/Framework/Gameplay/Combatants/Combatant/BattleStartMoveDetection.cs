
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleStartMoveDetection : BaseData
	{
		[ORKEditorInfo(labelText="Base Detection Range")]
		public Range range = new Range(20, true, false, 0.5f);
		
		[ORKEditorHelp("Needed", "Select if all or just one move detection must detect the target.", "")]
		[ORKEditorInfo(separator=true, isEnumToolbar=true, toolbarWidth=75, labelText="Move Detections")]
		public Needed needed = Needed.One;
		
		[ORKEditorArray(false, "Add Detection", "Adds a move detection setting.\n" +
			"You can use multiple move detections to detect enemy movement.", "", 
			"Remove", "Removes this move detection setting.", "", isMove=true, isCopy=true, 
			foldout=true, foldoutText=new string[] {"Move Detection", 
				"Move detections determine how an enemy combatant will be detected.", ""})]
		public MoveDetection[] detection = new MoveDetection[0];
		
		public BattleStartMoveDetection()
		{
			
		}
		
		public bool Check(Combatant user, Combatant target)
		{
			if(this.detection.Length > 0 && 
				this.range.InRange(user, target))
			{
				for(int i=0; i<this.detection.Length; i++)
				{
					if(this.detection[i].Detected(user, target))
					{
						if(Needed.One.Equals(this.needed))
						{
							return true;
						}
					}
					else if(Needed.All.Equals(this.needed))
					{
						return false;
					}
				}
				if(Needed.All.Equals(this.needed))
				{
					return true;
				}
			}
			return false;
		}
	}
}
