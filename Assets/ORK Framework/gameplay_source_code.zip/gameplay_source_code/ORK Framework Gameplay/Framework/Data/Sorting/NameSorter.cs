
using System.Collections.Generic;

namespace ORKFramework
{
	public delegate string GetNameDelegate(int index);
	
	public class NameSorter : IComparer<int>
	{
		private GetNameDelegate GetName;
		
		private bool invert = false;
		
		public NameSorter(GetNameDelegate getName, bool invert)
		{
			this.GetName = getName;
			this.invert = invert;
		}
		
		public int Compare(int x , int y)
		{
			if(this.invert)
			{
				return this.GetName(y).CompareTo(this.GetName(x));
			}
			else
			{
				return this.GetName(x).CompareTo(this.GetName(y));
			}
		}
	}
}
