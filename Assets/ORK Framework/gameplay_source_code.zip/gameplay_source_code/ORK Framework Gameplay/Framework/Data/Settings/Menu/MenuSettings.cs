
using UnityEngine;
using ORKFramework.Menu;

namespace ORKFramework
{
	public class MenuSettings : BaseSettings
	{
		// gui system settings
		[ORKEditorHelp("GUI System Type", "Select which GUI system will be used:\n" +
			"- Legacy GUI: The old legacy Unity GUI.\n" +
			"- New UI: The new UI.", "")]
		[ORKEditorInfo("Base Settings", "Base display and control settings.", "", 
			labelText="GUI System Settings")]
		public GUISystemType guiSystemType = GUISystemType.LegacyGUI;
		
		[ORKEditorLayout("guiSystemType", GUISystemType.NewUI, endCheckGroup=true)]
		public NewUISettings newUI = new NewUISettings();
		
		
		// general gui settings
		[ORKEditorHelp("Key Scroll Speed", "The amount of pixels the scrollbar is moved when using keys.", "")]
		[ORKEditorInfo(separator=true, labelText="General GUI Settings")]
		public float scrollSpeed = 3;
		
		[ORKEditorHelp("Mouse Over Selection", "Hovering the mouse cursor above a choice will select it (not accept).\n" +
			"This only happens on the currently focused GUI box.", "")]
		public bool choiceMouseOver = false;
		
		[ORKEditorHelp("Default Mask Material", "Select the default material that will be used for texture alpha masks.\n" +
			"The default mask material can be overridden by each image that can use alpha masks.", "")]
		public Material defaultMaskMaterial;
		
		
		// drag and drop
		[ORKEditorHelp("Show Drag", "Display a notification box while dragging.", "")]
		[ORKEditorInfo(separator=true, labelText="Dragging Notification")]
		public bool showDrag = true;
		
		[ORKEditorHelp("Drag Box", "Select the GUI box used to display drag information (e.g. name of an ability).", "")]
		[ORKEditorInfo(ORKDataType.GUIBox)]
		[ORKEditorLayout("showDrag", true)]
		public int dragBoxID = 0;
		
		// layout
		[ORKEditorInfo("Drag Content Layout", "Define the layout of the drag info.", "", 
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true)]
		public ContentLayout dragContentLayout = new ContentLayout(ContentLayoutType.Both, ContentLayoutInfoType.Info);
		
		
		// use costs display
		[ORKEditorInfo("Text Display Settings", "Define how different text representations of informations are displayed.\n" +
			"E.g.: use costs of an ability, status value bonuses of an equipment, etc.", "", 
			"Use Cost Display", "Define how an ability's use costs will be displayed in menus.", "", endFoldout=true)]
		public UseCostDisplay useCostDisplay = new UseCostDisplay();
		
		[ORKEditorInfo("Bonus Display", "Define how bonuses will be displayed when " +
			"using the '%bonus' text code in the descriptions of status effects, weapons, armors, " +
			"passive abilities, classes and combatants.", "", 
			endFoldout=true, endFolds=2)]
		public BonusDisplay bonusDisplay = new BonusDisplay();
		
		
		// combatant choice
		[ORKEditorInfo("Default Combatant Choice Layout", "Define the default layout for combatant choices " +
			"in battle menus or combatant selections.\n" +
			"You can either display  each combatant as a simple button with name and icon, " +
			"or use HUD elements to create more complex choices with status information.\n" +
			"The default layout can be overridden by each battle menu.", "", endFoldout=true)]
		public CombatantChoiceLayout combatantChoice = new CombatantChoiceLayout();
		
		
		// default GUI box settings
		// default skin settings
		[ORKEditorInfo("Default GUI Box Settings", "Define various default settings for GUI boxes.\n" +
			"Each GUI box can individually override these settings.", "", 
			"Default GUI Skins", "Select the Unity GUISkins used to display GUI boxes.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public GUIBoxSkins skins = new GUIBoxSkins();
		
		// default audio settings
		[ORKEditorInfo("Default Audio Settings", "The audio clips played when interacting with menus or dialogues (e.g. cursor move, accept).\n" +
			"You can set the volume of every clip.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public MenuAudioClips audio = new MenuAudioClips();
		
		// default inactive colors
		[ORKEditorInfo("Default Inactive Colors", "GUI boxes that aren't focused (e.g. parts of menus or shops currently not in use) " +
			"can be tinted to give the user a better visual feedback of which box he is controlling.\n" +
			"This is only used for focusable (controlable) GUI boxes, i.e. HUDs or information menu/shop parts wont be tinted.\n" +
			"These settings can be overridden by each GUI box individually.", "", endFoldout=true)]
		public InactiveColor inactive = new InactiveColor();
		
		// default ok/cancel buttons
		[ORKEditorInfo("Default Ok/Cancel Buttons", "The default 'Ok' and 'Cancel' buttons are used in all GUI boxes that don't override the default settings.\n" +
			"The buttons are used in dialogues, questions (e.g. load/save) and quantity selections.", "", endFoldout=true)]
		public GUIBoxButtons okCancel = new GUIBoxButtons();
		
		// default portrait position
		[ORKEditorInfo("Default Portrait Position", "The default position of speaker portraits.\n" +
			"These settings can be overriden by GUI boxes, combatant portraits and the portrait settings in dialogue event steps.", "", 
			endFoldout=true)]
		public PortraitPosition portraitPosition = new PortraitPosition();
		
		// header settings
		[ORKEditorInfo("Default Choice Header Settings", "The default choice header settings.\n" +
			"Header texts can optionally be displayed above choice buttons in menu screens, shops and battle menus." +
			"These settings can be overriden by each GUI box individually.", "", 
			endFoldout=true)]
		public HeaderSettings headerSettings = new HeaderSettings();
		
		// default choice icon settings
		[ORKEditorInfo("Default Choice Icon Settings", "The default choice icon settings.\n" +
			"The choice icon is displayed at a currently selected choice.", "", 
			endFoldout=true, endFolds=2)]
		public ChoiceIconSettings choiceIcon = new ChoiceIconSettings();
		
		
		// hud settings
		[ORKEditorHelp("HUD Effect Time", "The time in seconds used to display status effects in HUDs.\n" +
			"This is used to switch between the current status effects of a combatant, if only one effect " +
			"is displayed by a HUD, or if there are not enough cells to display all effects.", "")]
		[ORKEditorInfo("HUD Settings", "Base settings regarding HUDs.", "")]
		public float hudSETime = 2;
		
		[ORKEditorHelp("HUD Check Time", "The time in seconds used to check individual combatant HUDs.\n" +
			"The check will review faction and enemy state of the combatants and change the HUD accordingly.", "")]
		public float hudCheckTime = 1;
		
		[ORKEditorHelp("HUD Layer Mask", "Select the layers that will be checked for objects in HUDs.\n" +
			"This is used e.g. when a combatant's HUD is only displayed while the mouse is above it.", "")]
		public LayerMask hudMask = -1;
		
		[ORKEditorHelp("Raycast Distance", "The distance used by the raycast to determine the current HUD object.", "")]
		public float hudDistance = 100;
		
		[ORKEditorHelp("Use Turn Flash", "The HUD of a combatant who start's his turn will flash.", "")]
		[ORKEditorInfo(separator=true, labelText="Turn Flash HUD")]
		public bool useTurnFlash = false;
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("useTurnFlash", true, endCheckGroup=true, autoInit=true)]
		public FadeColorSettings hudTurnFlash;
		
		
		// menu background
		[ORKEditorInfo("Menu Backgrounds", "Menu screens can display background images.\n" +
			"You can select the default backgrounds for all menu screens here.\n" +
			"Each menu screen can override the default background images.\n" +
			"General background images are displayed in all menu screens and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "", 
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by menu screens.", ""})]
		public BackgroundImage[] defaultMenuBG = new BackgroundImage[0];
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "", 
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in all menu screens.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the menu screen's individual background.", ""})]
		public BackgroundImage[] generalMenuBG = new BackgroundImage[0];
		
		
		// shop background
		[ORKEditorInfo("Shop Backgrounds", "Shops can display background images.\n" +
			"You can select the default backgrounds for all shops here.\n" +
			"Each shop layout and shop can override the default background images.\n" +
			"General background images are displayed in all shops and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "", 
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by shop layouts and shops.", ""})]
		public BackgroundImage[] defaultShopBG = new BackgroundImage[0];
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "", 
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in all shops.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the shop layout's or shop's individual background.", ""})]
		public BackgroundImage[] generalShopBG = new BackgroundImage[0];
		
		
		// save background
		[ORKEditorInfo("Save Backgrounds", "The save point, save and load menu can display background images.\n" +
			"You can select the default backgrounds for all save menus here.\n" +
			"Each save menu can override the default background images.\n" +
			"General background images are displayed in all save menus and can't be overridden. " +
			"They're displayed behind the default backgrounds.", "")]
		[ORKEditorArray(false, "Add Default Background", "Adds a default background image.", "", 
			"Remove", "Removes this default background image.", "", foldout=true,
			foldoutText=new string[] {"Default Background", "Define the default background image that will be displayed.\n" +
				"Default backgrounds can be overridden by the save point, save and load menus.", ""})]
		public BackgroundImage[] defaultSaveBG = new BackgroundImage[0];
		
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add General Background", "Adds a general background image.", "", 
			"Remove", "Removes this general background image.", "", foldout=true,
			foldoutText=new string[] {"General Background", "Define the general background image that will be displayed in save menus.\n" +
				"This background can't be overridden and will be displayed behind the " +
				"default backgrounds or the save point's, save or load menu's individual background.", ""})]
		public BackgroundImage[] generalSaveBG = new BackgroundImage[0];
		
		
		// buttons
		[ORKEditorInfo("Buttons", "Default button settings, the buttons are used system wide.", "", 
			labelText="Cancel Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] cancelButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Cancel"});
		
		[ORKEditorInfo(separator=true, labelText="Back Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] backButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Back"});
		
		[ORKEditorInfo(separator=true, labelText="Use Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] useButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Use"});
		
		[ORKEditorInfo(separator=true, labelText="Give Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] giveButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Give"});
		
		[ORKEditorInfo(separator=true, labelText="Equip Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] equipButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Equip"});
		
		[ORKEditorInfo(separator=true, labelText="Unequip Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] unequipButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Unequip"});
		
		[ORKEditorInfo(separator=true, labelText="Remove Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] removeButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Remove"});
		
		[ORKEditorInfo(separator=true, labelText="Drop Button")]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] dropButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Drop"});
		
		[ORKEditorInfo(separator=true, labelText="Level Up Button", endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language, foldoutDefault=false)]
		public LanguageInfo[] levelUpButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count, 
			new System.Type[] {typeof(string)}, new System.Object[] {"Level Up"});
		
		
		// combatant choice
		// menu user
		[ORKEditorHelp("Menu User", "Used when the user of a menu is selected.", "")]
		[ORKEditorInfo("Default Combatant Selections", "Define the default combatant selection options.", "", 
			isPopup=true, popupType=ORKDataType.CombatantSelection)]
		public int comUserID = 0;
		
		// ability
		[ORKEditorHelp("Ability Target", "Used when the target of an ability is selected.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comAbilityID = 0;
		
		// item
		[ORKEditorHelp("Item Target", "Used when the target of an item is selected.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comItemID = 0;
		
		// equipment
		[ORKEditorHelp("Equip Target", "Used when equipping an equipment on another combatant.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		public int comEquipID = 0;
		
		// give
		[ORKEditorHelp("Give Target", "Used when giving items to another combatant.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection, endFoldout=true)]
		public int comGiveID = 0;
		
		
		// default quantity selections
		[ORKEditorInfo("Default Quantity Selections", "Define the default quantity selection options.", "", 
			labelText="Remove Selection")]
		public QuantityDefault quantityRemove = new QuantityDefault();
		
		[ORKEditorInfo(separator=true, labelText="Drop Selection")]
		public QuantityDefault quantityDrop = new QuantityDefault();
		
		[ORKEditorInfo(separator=true, labelText="Give Selection")]
		public QuantityDefault quantityGive = new QuantityDefault();
		
		[ORKEditorInfo(separator=true, labelText="Buy Selection")]
		public QuantityDefault quantityBuy = new QuantityDefault();
		
		[ORKEditorInfo(endFoldout=true, separator=true, labelText="Sell Quantity")]
		public QuantityDefault quantitySell = new QuantityDefault();
		
		public MenuSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "menuSettings"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public GUIContent GetCancelContent()
		{
			return this.cancelButton[ORK.Game.Language].GetContent();
		}
	}
}
