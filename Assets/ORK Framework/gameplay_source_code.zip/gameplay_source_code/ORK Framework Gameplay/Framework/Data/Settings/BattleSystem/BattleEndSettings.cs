
using UnityEngine;

namespace ORKFramework
{
	public class BattleEndSettings : BaseSettings
	{
		// general settings
		[ORKEditorInfo("Base Settings", "GUI display and experience gain options.", "")]
		public BattleEndChoice end = new BattleEndChoice();
		
		// experience
		[ORKEditorHelp("Split Experience Rewards", "The experience points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the experience.", "")]
		[ORKEditorInfo(separator=true, labelText="Experience Reward Settings")]
		public bool splitExp = false;
		
		[ORKEditorHelp("Whole Party", "The whole (active) group will receive experience.\n" +
			"If the experience is splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyExp = false;
		
		[ORKEditorHelp("Dead Receive Exp.", "Dead group members will also receive experience.\n" +
			"If disabled, only group members who are alive will receive experience.", "")]
		public bool deadExp = false;
		
		// normal
		[ORKEditorHelp("Split Normal Rewards", "The 'Normal' status value points gained from enemies will be split through " +
			"the battle group members, i.e. every group member will only get a part of the 'Normal' status value reward.", "")]
		[ORKEditorInfo(separator=true, labelText="Normal Status Value Reward Settings")]
		public bool splitNormalSV = false;
		
		[ORKEditorHelp("Whole Party", "The whole (active) group will receive 'Normal' status value rewards.\n" +
			"If the 'Normal' status value rewards are splitted, it will be splitted by all (active) group members.", "")]
		public bool wholePartyNormalSV = false;
		
		[ORKEditorHelp("Dead Receive Normal", "Dead group members will also receive 'Normal' status value rewards.\n" +
			"If disabled, only group members who are alive will receive 'Normal' status value rewards.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool deadNormalSV = false;
		
		
		// victory gains
		[ORKEditorHelp("Show Gains", "Victory gains are displayed at the end of a battle or " +
			"when an enemy dies (in 'Real Time' type battles and if get immediately is selected).\n" +
			"If disabled, no notification about items, money and experience is displayed.", "")]
		[ORKEditorInfo("Victory Gain Notification", "The text for the spoils of a battle are defined here.\n" +
			"The order of the single notifications can be changed by changing the total gain text.\n" +
			"All spoils will be displayed in one message.", "")]
		public bool showGains = true;
		
		// gain sum text
		[ORKEditorHelp("Total Gains Text", "The text used to display all victory gains.\n" +
			"This text uses the other victory gain texts to display money, item and experience gained from a battle/enemy.", "")]
		[ORKEditorInfo("Total Gains Text", "The text used to display all victory gains.\n" +
			"This text uses the other victory gain texts to display money, item and experience gained from a battle/enemy.", "", endFoldout=true, 
			isTextArea=true, separatorForce=true, 
			label=new string[] {
				"%m = money text, %i = item text", 
				"%e = experience text, %n = normal status value text"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("showGains", true)]
		public string[] gainText = ArrayHelper.CreateArray(ORK.Languages.Count, "Victory gains:\n%m\n%i\n%e\n%n");
		
		// money text
		[ORKEditorHelp("Money Text", "The text used to display the money dropped by the enemies.", "")]
		[ORKEditorInfo("Money Text", "The text used to display the money dropped by the enemies.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = currency name, %d = description, %i = icon, % = money amount", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] moneyText = ArrayHelper.CreateArray(ORK.Languages.Count, "You got % %n!");
		
		// item text
		[ORKEditorHelp("Item Text", "The text used to display the items dropped by the enemies.\n" +
			"Multiple items of the same kind are displayed in one line, every item kind in its own line.", "")]
		[ORKEditorInfo("Item Text", "The text used to display the items dropped by the enemies.\n" +
			"Multiple items of the same kind are displayed in one line, every item kind in its own line.", "", 
			endFoldout=true, separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = item name, %d = description, %i = icon, % = item quantity", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] itemText = ArrayHelper.CreateArray(ORK.Languages.Count, "You found % %n!");
		
		// experience text
		[ORKEditorHelp("Experience Text", "The text used to display the experience gained.", "")]
		[ORKEditorInfo("Experience Text", "The text used to display the experience gained.", "", 
			endFoldout=true, separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = status value name, %d = description, %i = icon, % = value", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] experienceText = ArrayHelper.CreateArray(ORK.Languages.Count, "%cn received % %n!");
		
		// normal status value text
		[ORKEditorHelp("Normal Status Value Text", "The text used to display the 'Normal' status values gained.", "")]
		[ORKEditorInfo("Normal Status Value Text", "The text used to display the 'Normal' status values gained.", "", 
			endFoldout=true, endFolds=2, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = status value name, %d = description, %i = icon, % = value", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] normalSVText = ArrayHelper.CreateArray(ORK.Languages.Count, "%cn received % %n!");
		
		
		// level up
		[ORKEditorHelp("Show Level Up", "Level up notifications are displayed at the " +
			"end of a battle (if a combatant's level increases).", "")]
		[ORKEditorInfo("Level Up Notification", "The notification shown when a combatant's level increases.\n" +
			"The order of the single notifications can be changed by changing the total level up text.\n" +
			"All texts will be displayed in one message.", "")]
		public bool showLevelUp = true;
		
		// level sum text
		[ORKEditorHelp("Total Level Up Text", "The text used to display all level up informations.\n" +
			"This text uses the other level up texts to display level and class level, " +
			"status value changes and ability learning information.", "")]
		[ORKEditorInfo("Total Level Up Text", "The text used to display all level up informations.\n" +
			"This text uses the other level up texts to display level and class level, " +
			"status value changes and ability learning information.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {"%l = level up/class level up text, %s = status value change text, %a = ability learn text"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout("showLevelUp", true)]
		public string[] levelText = ArrayHelper.CreateArray(ORK.Languages.Count, "%l\n%s\n%a");
		
		// level texts
		[ORKEditorHelp("Level Up Text", "The text is used to display the combatant's name and new level.", "")]
		[ORKEditorInfo("Level Up Text", "The text is used to display the combatant's name and new level.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {"%n = combatant name, %d = description, %i = icon, % = level"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] levelUpText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n reached level %!");
		
		[ORKEditorHelp("Class Lvl Up Text", "The text is used to display the combatant's name and new class level.", "")]
		[ORKEditorInfo("Class Lvl Up Text", "The text is used to display the combatant's name and new class level.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {"%n = combatant name, %d = combatant description, %i = combatant icon", 
				"%c = class name, %cd = class description, %ci = class icon, % = class level"})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] classLevelUpText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n reached class level %!");
		
		[ORKEditorHelp("Status Value Text", "The text is used to display status value changes.\n" +
			"Every status value is displayed in its own line.", "")]
		[ORKEditorInfo("Status Value Text", "The text is used to display status value changes.\n" +
			"Every status value is displayed in its own line.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = status value name, %d = description, %i = icon, % = value change", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] statusValueText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n +%");
		
		[ORKEditorHelp("Ability Learn Text", "The text used to display new abilities learned by the combatant.\n" +
			"Every ability is displayed in its own line.", "")]
		[ORKEditorInfo("Ability Learn Text", "The text used to display new abilities learned by the combatant.\n" +
			"Every ability is displayed in its own line.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = ability name, %d = description, %i = icon", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] abilityText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n learned!");
		
		[ORKEditorHelp("Group Ability Learn Text", "The text used to display new abilities learned by the combatant's group.\n" +
			"Every ability is displayed in its own line.", "")]
		[ORKEditorInfo("Group Ability Learn Text", "The text used to display new abilities learned by the combatant's group.\n" +
			"Every ability is displayed in its own line.", "", endFoldout=true, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = ability name, %d = description, %i = icon", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public string[] groupAbilityText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n learned!");
		
		[ORKEditorHelp("Ability Tree Learn Text", "The text used to display new ability trees learned by the combatant.\n" +
			"Every ability tree is displayed in its own line.", "")]
		[ORKEditorInfo("Ability Tree Learn Text", "The text used to display new ability trees learned by the combatant.\n" +
			"Every ability tree is displayed in its own line.", "", endFoldout=true, endFolds=2, 
			separatorForce=true, isTextArea=true, 
			label=new string[] {
				"%n = ability tree name, %d = description, %i = icon", 
				"%cn = combatant name, %cd = combatant description, %ci = combatant icon"
		})]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public string[] abilityTreeText = ArrayHelper.CreateArray(ORK.Languages.Count, "%n learned!");
		
		public BattleEndSettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}
		
		public override void SetRealIDs()
		{
			
		}
		
		
		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get{ return "battleEnd"; }
		}
		
		
		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}
		
		
		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}
		
		public override int Copy(int index)
		{
			return -1;
		}
		
		public override void Remove(int index)
		{
			
		}
		
		public override void Move(int index, bool down)
		{
			
		}
		
		
		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public string GetGainText(string mt, string it, string et, string nsvt)
		{
			return this.gainText[ORK.Game.Language].
				Replace("%m", mt).Replace("%i", it).Replace("%e", et).Replace("%n", nsvt);
		}
		
		public string GetItemText(Combatant combatant, IShortcut item)
		{
			return this.itemText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", item.GetName()).
				Replace("%d", item.GetDescription()).
				Replace("%i", item.GetIconTextCode()).
				Replace("%", item.Quantity.ToString());
		}
		
		public string GetMoneyText(Combatant combatant, int currencyID, int count)
		{
			Currency currency = ORK.Currencies.Get(currencyID);
			return this.moneyText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", currency.GetName()).
				Replace("%d", currency.GetDescription()).
				Replace("%i", currency.GetIconTextCode()).
				Replace("%", count.ToString());
		}
		
		public string GetExperienceText(Combatant combatant, int statusID, int count)
		{
			StatusValueSetting status = ORK.StatusValues.Get(statusID);
			return this.experienceText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", status.GetName()).
				Replace("%d", status.GetDescription()).
				Replace("%i", status.GetIconTextCode()).
				Replace("%", count.ToString());
		}
		
		public string GetNormalStatusValueText(Combatant combatant, int statusID, int count)
		{
			StatusValueSetting status = ORK.StatusValues.Get(statusID);
			return this.normalSVText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", status.GetName()).
				Replace("%d", status.GetDescription()).
				Replace("%i", status.GetIconTextCode()).
				Replace("%", count.ToString());
		}
		
		public string GetLevelText(string lt, string st, string at)
		{
			return this.levelText[ORK.Game.Language].
				Replace("%l", lt).Replace("%s", st).Replace("%a", at);
		}
		
		public string GetLevelUpText(Combatant combatant, int level)
		{
			return this.levelUpText[ORK.Game.Language].
				Replace("%n", combatant.GetName()).
				Replace("%d", combatant.GetDescription()).
				Replace("%i", combatant.GetIconTextCode()).
				Replace("%", level.ToString());
		}
		
		public string GetClassLevelUpText(Combatant combatant, int classID, int level)
		{
			Class cl = ORK.Classes.Get(classID);
			return this.classLevelUpText[ORK.Game.Language].
				Replace("%n", combatant.GetName()).
				Replace("%d", combatant.GetDescription()).
				Replace("%i", combatant.GetIconTextCode()).
				Replace("%c", cl.GetName()).
				Replace("%cd", cl.GetDescription()).
				Replace("%ci", cl.GetIconTextCode()).
				Replace("%", level.ToString());
		}
		
		public string GetStatusValueText(Combatant combatant, int statusID, int count)
		{
			StatusValueSetting status = ORK.StatusValues.Get(statusID);
			return this.statusValueText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", status.GetName()).
				Replace("%d", status.GetDescription()).
				Replace("%i", status.GetIconTextCode()).
				Replace("%", count.ToString());
		}
		
		public string GetAbilityText(Combatant combatant, int abilityID, int abilityLevel)
		{
			Ability ability = ORK.Abilities.Get(abilityID);
			return this.abilityText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", ability.GetName(abilityLevel)).
				Replace("%d", ability.GetDescription()).
				Replace("%i", ability.GetIconTextCode());
		}
		
		public string GetGroupAbilityText(Combatant combatant, int abilityID, int abilityLevel)
		{
			Ability ability = ORK.Abilities.Get(abilityID);
			return this.groupAbilityText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", ability.GetName(abilityLevel)).
				Replace("%d", ability.GetDescription()).
				Replace("%i", ability.GetIconTextCode());
		}
		
		public string GetAbilityTreeText(Combatant combatant, int abilityTreeID)
		{
			AbilityTree abilityTree = ORK.AbilityTrees.Get(abilityTreeID);
			return this.abilityTreeText[ORK.Game.Language].
				Replace("%cn", combatant.GetName()).
				Replace("%cd", combatant.GetDescription()).
				Replace("%ci", combatant.GetIconTextCode()).
				Replace("%n", abilityTree.GetName()).
				Replace("%d", abilityTree.GetDescription()).
				Replace("%i", abilityTree.GetIconTextCode());
		}
	}
}
