
using UnityEngine;
using ORKFramework;
using System.Text;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class GetFieldValue : BaseData
	{
		[ORKEditorHelp("Field Name", "The name of the field/property that will be used.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string fieldName = "";
		
		[ORKEditorHelp("Is Property", "Uses the value of a property.\n" +
			"If disabled, the value of a field will be used.", "")]
		public bool isProperty = false;
		
		public GetFieldValue()
		{
			
		}
		
		public System.Object GetValue(GameObject gameObject, string className, bool isStatic)
		{
			if(className != "")
			{
				System.Type instanceType = isStatic ? 
					ORK.Core.TypeHandler.GetType(className) :
					ORK.Core.TypeHandler.GetType(className, typeof(Component));
				
				if(instanceType != null)
				{
					System.Object instance = isStatic ? null : gameObject.GetComponent(instanceType);
					
					if(isStatic || instance != null)
					{
						if(this.fieldName != "")
						{
							if(this.isProperty)
							{
								PropertyInfo propertyInfo = instanceType.GetProperty(this.fieldName, 
									BindingFlags.Public | BindingFlags.NonPublic | 
										(isStatic ? BindingFlags.Static : BindingFlags.Instance));
								if(propertyInfo != null)
								{
									try
									{
										return propertyInfo.GetValue(instance, null);
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting property value failed (" + instanceType + "): " + 
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Property not found (" + instanceType + "): " + this.fieldName);
								}
							}
							else
							{
								FieldInfo fieldInfo = instanceType.GetField(this.fieldName, 
									BindingFlags.Public | BindingFlags.NonPublic | 
										(isStatic ? BindingFlags.Static : BindingFlags.Instance));
								if(fieldInfo != null)
								{
									try
									{
										return fieldInfo.GetValue(instance);
									}
									catch(System.Exception ex)
									{
										Debug.LogWarning("Getting field value failed (" + instanceType + "): " + 
											this.fieldName + "\n" + ex.Message + "\n" + ex.StackTrace);
									}
								}
								else
								{
									Debug.LogWarning("Field not found (" + instanceType + "): " + this.fieldName);
								}
							}
						}
					}
				}
				else
				{
					Debug.LogWarning("Component type not found: " + className);
				}
			}
			return null;
		}
	}
}
