
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ORKFramework.Bonus;
using ORKFramework.Events.Steps;
using ORKFramework.Formulas.Steps;
using ORKFramework.AI.Steps;
using ORKFramework.Menu.Parts;

namespace ORKFramework
{
	public static class DataHelper
	{
		/*
		============================================================================
		Data callback functions
		============================================================================
		*/
		public static int Add(ORKDataType type)
		{
			// editor
			if(ORKDataType.Plugin.Equals(type))
			{
				return ORK.Plugins.Add();
			}
			
			// base data
			else if(ORKDataType.Language.Equals(type))
			{
				return ORK.Languages.Add();
			}
			else if(ORKDataType.Color.Equals(type))
			{
				return ORK.Colors.Add();
			}
			else if(ORKDataType.Difficulty.Equals(type))
			{
				return ORK.Difficulties.Add();
			}
			else if(ORKDataType.InputKey.Equals(type))
			{
				return ORK.InputKeys.Add();
			}
			else if(ORKDataType.ControlMap.Equals(type))
			{
				return ORK.ControlMaps.Add();
			}
			else if(ORKDataType.FormulaType.Equals(type))
			{
				return ORK.FormulaTypes.Add();
			}
			else if(ORKDataType.Formula.Equals(type))
			{
				return ORK.Formulas.Add();
			}
			else if(ORKDataType.Requirement.Equals(type))
			{
				return ORK.Requirements.Add();
			}
			else if(ORKDataType.AnimationType.Equals(type))
			{
				return ORK.AnimationTypes.Add();
			}
			else if(ORKDataType.Animation.Equals(type))
			{
				return ORK.Animations.Add();
			}
			else if(ORKDataType.DamageType.Equals(type))
			{
				return ORK.DamageTypes.Add();
			}
			else if(ORKDataType.SoundType.Equals(type))
			{
				return ORK.SoundTypes.Add();
			}
			else if(ORKDataType.PortraitType.Equals(type))
			{
				return ORK.PortraitTypes.Add();
			}
			else if(ORKDataType.VariableConditionTemplate.Equals(type))
			{
				return ORK.VariableConditionTemplates.Add();
			}
			else if(ORKDataType.StatusRequirementTemplate.Equals(type))
			{
				return ORK.StatusRequirementTemplates.Add();
			}
			
			// game data
			else if(ORKDataType.ConsoleType.Equals(type))
			{
				return ORK.ConsoleTypes.Add();
			}
			else if(ORKDataType.AreaType.Equals(type))
			{
				return ORK.AreaTypes.Add();
			}
			else if(ORKDataType.Area.Equals(type))
			{
				return ORK.Areas.Add();
			}
			else if(ORKDataType.Teleport.Equals(type))
			{
				return ORK.Teleports.Add();
			}
			else if(ORKDataType.CameraPosition.Equals(type))
			{
				return ORK.CameraPositions.Add();
			}
			else if(ORKDataType.MusicClip.Equals(type))
			{
				return ORK.MusicClips.Add();
			}
			else if(ORKDataType.GlobalEvent.Equals(type))
			{
				return ORK.GlobalEvents.Add();
			}
			
			// world data
			else if(ORKDataType.LogType.Equals(type))
			{
				return ORK.LogTypes.Add();
			}
			else if(ORKDataType.Log.Equals(type))
			{
				return ORK.Logs.Add();
			}
			else if(ORKDataType.LogText.Equals(type))
			{
				return ORK.LogTexts.Add();
			}
			else if(ORKDataType.SceneObjectType.Equals(type))
			{
				return ORK.SceneObjectTypes.Add();
			}
			else if(ORKDataType.SceneObject.Equals(type))
			{
				return ORK.SceneObjects.Add();
			}
			else if(ORKDataType.QuestType.Equals(type))
			{
				return ORK.QuestTypes.Add();
			}
			else if(ORKDataType.Quest.Equals(type))
			{
				return ORK.Quests.Add();
			}
			else if(ORKDataType.QuestTask.Equals(type))
			{
				return ORK.QuestTasks.Add();
			}
			
			// status data
			else if(ORKDataType.AttackAttributes.Equals(type))
			{
				return ORK.AttackAttributes.Add();
			}
			else if(ORKDataType.DefenceAttributes.Equals(type))
			{
				return ORK.DefenceAttributes.Add();
			}
			else if(ORKDataType.StatusValue.Equals(type))
			{
				return ORK.StatusValues.Add();
			}
			else if(ORKDataType.StatusEffectType.Equals(type))
			{
				return ORK.StatusEffectTypes.Add();
			}
			else if(ORKDataType.StatusEffect.Equals(type))
			{
				return ORK.StatusEffects.Add();
			}
			else if(ORKDataType.StatusBonus.Equals(type))
			{
				return ORK.StatusBonuses.Add();
			}
			else if(ORKDataType.AbilityType.Equals(type))
			{
				return ORK.AbilityTypes.Add();
			}
			else if(ORKDataType.Ability.Equals(type))
			{
				return ORK.Abilities.Add();
			}
			else if(ORKDataType.StatusDevelopment.Equals(type))
			{
				return ORK.StatusDevelopments.Add();
			}
			else if(ORKDataType.AbilityTree.Equals(type))
			{
				return ORK.AbilityTrees.Add();
			}
			
			// inventory
			else if(ORKDataType.ItemType.Equals(type))
			{
				return ORK.ItemTypes.Add();
			}
			else if(ORKDataType.Currency.Equals(type))
			{
				return ORK.Currencies.Add();
			}
			else if(ORKDataType.Item.Equals(type))
			{
				return ORK.Items.Add();
			}
			else if(ORKDataType.EquipmentPart.Equals(type))
			{
				return ORK.EquipmentParts.Add();
			}
			else if(ORKDataType.Weapon.Equals(type))
			{
				return ORK.Weapons.Add();
			}
			else if(ORKDataType.Armor.Equals(type))
			{
				return ORK.Armors.Add();
			}
			else if(ORKDataType.CraftingType.Equals(type))
			{
				return ORK.CraftingTypes.Add();
			}
			else if(ORKDataType.CraftingRecipe.Equals(type))
			{
				return ORK.CraftingRecipes.Add();
			}
			
			// combat
			else if(ORKDataType.Faction.Equals(type))
			{
				return ORK.Factions.Add();
			}
			else if(ORKDataType.FactionBenefit.Equals(type))
			{
				return ORK.FactionBenefits.Add();
			}
			else if(ORKDataType.Class.Equals(type))
			{
				return ORK.Classes.Add();
			}
			else if(ORKDataType.BattleAI.Equals(type))
			{
				return ORK.BattleAIs.Add();
			}
			else if(ORKDataType.CombatantType.Equals(type))
			{
				return ORK.CombatantTypes.Add();
			}
			else if(ORKDataType.Combatant.Equals(type))
			{
				return ORK.Combatants.Add();
			}
			else if(ORKDataType.CombatantGroup.Equals(type))
			{
				return ORK.CombatantGroups.Add();
			}
			else if(ORKDataType.MoveAI.Equals(type))
			{
				return ORK.MoveAIs.Add();
			}
			else if(ORKDataType.BattleMenu.Equals(type))
			{
				return ORK.BattleMenus.Add();
			}
			else if(ORKDataType.Loot.Equals(type))
			{
				return ORK.Loot.Add();
			}
			
			// menu
			else if(ORKDataType.GUILayer.Equals(type))
			{
				return ORK.GUILayers.Add();
			}
			else if(ORKDataType.GUIBox.Equals(type))
			{
				return ORK.GUIBoxes.Add();
			}
			else if(ORKDataType.CombatantSelection.Equals(type))
			{
				return ORK.CombatantSelections.Add();
			}
			else if(ORKDataType.QuantitySelection.Equals(type))
			{
				return ORK.QuantitySelections.Add();
			}
			else if(ORKDataType.MenuScreen.Equals(type))
			{
				return ORK.MenuScreens.Add();
			}
			else if(ORKDataType.HUD.Equals(type))
			{
				return ORK.HUDs.Add();
			}
			else if(ORKDataType.ShopLayout.Equals(type))
			{
				return ORK.ShopLayouts.Add();
			}
			else if(ORKDataType.Shop.Equals(type))
			{
				return ORK.Shops.Add();
			}
			return -1;
		}
		
		
		// add/remove data
		public static void Added(ORKDataType type)
		{
			DataHelper.Added(type, -1);
		}
		
		public static void Added(ORKDataType type, int index)
		{
			// editor data
			ORK.EditorSettings.DataAdded(type, index);
			ORK.Backups.DataAdded(type, index);
			
			// base data
			ORK.Languages.DataAdded(type, index);
			ORK.Colors.DataAdded(type, index);
			ORK.InputKeys.DataAdded(type, index);
			ORK.ControlMaps.DataAdded(type, index);
			ORK.FormulaTypes.DataAdded(type, index);
			ORK.Formulas.DataAdded(type, index);
			ORK.Requirements.DataAdded(type, index);
			ORK.AnimationTypes.DataAdded(type, index);
			ORK.Animations.DataAdded(type, index);
			ORK.DamageTypes.DataAdded(type, index);
			ORK.SoundTypes.DataAdded(type, index);
			ORK.PortraitTypes.DataAdded(type, index);
			ORK.VariableConditionTemplates.DataAdded(type, index);
			ORK.StatusRequirementTemplates.DataAdded(type, index);
			
			// game data
			ORK.GameSettings.DataAdded(type, index);
			ORK.ConsoleSettings.DataAdded(type, index);
			ORK.ConsoleTypes.DataAdded(type, index);
			ORK.GameControls.DataAdded(type, index);
			ORK.Difficulties.DataAdded(type, index);
			ORK.SceneConnections.DataAdded(type, index);
			ORK.AreaTypes.DataAdded(type, index);
			ORK.Areas.DataAdded(type, index);
			ORK.Teleports.DataAdded(type, index);
			ORK.CameraPositions.DataAdded(type, index);
			ORK.MusicClips.DataAdded(type, index);
			ORK.GlobalEvents.DataAdded(type, index);
			
			// world
			ORK.LogTypes.DataAdded(type, index);
			ORK.Logs.DataAdded(type, index);
			ORK.LogTexts.DataAdded(type, index);
			ORK.SceneObjectTypes.DataAdded(type, index);
			ORK.SceneObjects.DataAdded(type, index);
			ORK.QuestTypes.DataAdded(type, index);
			ORK.Quests.DataAdded(type, index);
			ORK.QuestTasks.DataAdded(type, index);
			
			// status data
			ORK.AttackAttributes.DataAdded(type, index);
			ORK.DefenceAttributes.DataAdded(type, index);
			ORK.StatusValues.DataAdded(type, index);
			ORK.StatusEffectTypes.DataAdded(type, index);
			ORK.StatusEffects.DataAdded(type, index);
			ORK.StatusBonuses.DataAdded(type, index);
			ORK.AbilityTypes.DataAdded(type, index);
			ORK.Abilities.DataAdded(type, index);
			ORK.AbilityTrees.DataAdded(type, index);
			if(ORKDataType.StatusValue.Equals(type))
			{
				ORK.StatusDevelopments.StatusValueAdded();
			}
			else
			{
				ORK.StatusDevelopments.DataAdded(type, index);
			}
			
			// inventory
			ORK.InventorySettings.DataAdded(type, index);
			ORK.ItemTypes.DataAdded(type, index);
			ORK.Currencies.DataAdded(type, index);
			ORK.Items.DataAdded(type, index);
			ORK.EquipmentParts.DataAdded(type, index);
			ORK.Weapons.DataAdded(type, index);
			ORK.Armors.DataAdded(type, index);
			ORK.CraftingTypes.DataAdded(type, index);
			ORK.CraftingRecipes.DataAdded(type, index);
			
			// combatants
			ORK.Factions.DataAdded(type, index);
			ORK.FactionBenefits.DataAdded(type, index);
			ORK.FactionSympathy.DataAdded(type, index);
			ORK.Classes.DataAdded(type, index);
			ORK.BattleAIs.DataAdded(type, index);
			ORK.CombatantTypes.DataAdded(type, index);
			ORK.Combatants.DataAdded(type, index);
			ORK.CombatantGroups.DataAdded(type, index);
			ORK.MoveAIs.DataAdded(type, index);
			ORK.Loot.DataAdded(type, index);
			
			// battle
			ORK.BattleSettings.DataAdded(type, index);
			ORK.BattleSystem.DataAdded(type, index);
			ORK.BattleSpots.DataAdded(type, index);
			ORK.BattleMenus.DataAdded(type, index);
			ORK.BattleTexts.DataAdded(type, index);
			ORK.BattleEnd.DataAdded(type, index);
			
			// menu
			ORK.GUILayers.DataAdded(type, index);
			ORK.GUIBoxes.DataAdded(type, index);
			ORK.MainMenu.DataAdded(type, index);
			ORK.SaveGameMenu.DataAdded(type, index);
			ORK.MenuSettings.DataAdded(type, index);
			ORK.CombatantSelections.DataAdded(type, index);
			ORK.QuantitySelections.DataAdded(type, index);
			ORK.MenuScreens.DataAdded(type, index);
			ORK.HUDs.DataAdded(type, index);
			ORK.ShopLayouts.DataAdded(type, index);
			ORK.Shops.DataAdded(type, index);
			
			// plugins
			ORK.Plugins.DataAdded(type, index);
			
			// add list for event files
			if(ORK.Data.addList == null)
			{
				ORK.Data.addList = new List<KeyValuePair<ORKDataType, int>>();
			}
			ORK.Data.addList.Add(new KeyValuePair<ORKDataType, int>(type, index));
		}
		
		public static void Removed(ORKDataType type, int index)
		{
			DataHelper.Removed(type, index, -1);
		}
		
		public static void Removed(ORKDataType type, int index, int index2)
		{
			// editor data
			ORK.EditorSettings.DataRemoved(type, index, index2);
			ORK.Backups.DataRemoved(type, index, index2);
			
			// base data
			ORK.Languages.DataRemoved(type, index, index2);
			ORK.Colors.DataRemoved(type, index, index2);
			ORK.InputKeys.DataRemoved(type, index, index2);
			ORK.ControlMaps.DataRemoved(type, index, index2);
			ORK.FormulaTypes.DataRemoved(type, index, index2);
			ORK.Formulas.DataRemoved(type, index, index2);
			ORK.Requirements.DataRemoved(type, index, index2);
			ORK.AnimationTypes.DataRemoved(type, index, index2);
			ORK.Animations.DataRemoved(type, index, index2);
			ORK.DamageTypes.DataRemoved(type, index, index2);
			ORK.SoundTypes.DataRemoved(type, index, index2);
			ORK.PortraitTypes.DataRemoved(type, index, index2);
			ORK.VariableConditionTemplates.DataRemoved(type, index, index2);
			ORK.StatusRequirementTemplates.DataRemoved(type, index, index2);
			
			// game data
			ORK.GameSettings.DataRemoved(type, index, index2);
			ORK.ConsoleSettings.DataRemoved(type, index, index2);
			ORK.ConsoleTypes.DataRemoved(type, index, index2);
			ORK.GameControls.DataRemoved(type, index, index2);
			ORK.Difficulties.DataRemoved(type, index, index2);
			ORK.SceneConnections.DataRemoved(type, index, index2);
			ORK.AreaTypes.DataRemoved(type, index, index2);
			ORK.Areas.DataRemoved(type, index, index2);
			ORK.Teleports.DataRemoved(type, index, index2);
			ORK.CameraPositions.DataRemoved(type, index, index2);
			ORK.MusicClips.DataRemoved(type, index, index2);
			ORK.GlobalEvents.DataRemoved(type, index, index2);
			
			// world
			ORK.LogTypes.DataRemoved(type, index, index2);
			ORK.Logs.DataRemoved(type, index, index2);
			ORK.LogTexts.DataRemoved(type, index, index2);
			ORK.SceneObjectTypes.DataRemoved(type, index, index2);
			ORK.SceneObjects.DataRemoved(type, index, index2);
			ORK.QuestTypes.DataRemoved(type, index, index2);
			ORK.Quests.DataRemoved(type, index, index2);
			ORK.QuestTasks.DataRemoved(type, index, index2);
			
			// status data
			ORK.AttackAttributes.DataRemoved(type, index, index2);
			ORK.DefenceAttributes.DataRemoved(type, index, index2);
			ORK.StatusValues.DataRemoved(type, index, index2);
			ORK.StatusEffectTypes.DataRemoved(type, index, index2);
			ORK.StatusEffects.DataRemoved(type, index, index2);
			ORK.StatusBonuses.DataRemoved(type, index, index2);
			ORK.AbilityTypes.DataRemoved(type, index, index2);
			ORK.Abilities.DataRemoved(type, index, index2);
			ORK.AbilityTrees.DataRemoved(type, index, index2);
			ORK.StatusDevelopments.DataRemoved(type, index, index2);
			
			// inventory
			ORK.InventorySettings.DataRemoved(type, index, index2);
			ORK.ItemTypes.DataRemoved(type, index, index2);
			ORK.Currencies.DataRemoved(type, index, index2);
			ORK.Items.DataRemoved(type, index, index2);
			ORK.EquipmentParts.DataRemoved(type, index, index2);
			ORK.Weapons.DataRemoved(type, index, index2);
			ORK.Armors.DataRemoved(type, index, index2);
			ORK.CraftingTypes.DataRemoved(type, index, index2);
			ORK.CraftingRecipes.DataRemoved(type, index, index2);
			
			// combatants
			ORK.Factions.DataRemoved(type, index, index2);
			ORK.FactionBenefits.DataRemoved(type, index, index2);
			ORK.FactionSympathy.DataRemoved(type, index, index2);
			ORK.Classes.DataRemoved(type, index, index2);
			
			// battle
			ORK.BattleSettings.DataRemoved(type, index, index2);
			ORK.BattleAIs.DataRemoved(type, index, index2);
			ORK.CombatantTypes.DataRemoved(type, index, index2);
			ORK.Combatants.DataRemoved(type, index, index2);
			ORK.CombatantGroups.DataRemoved(type, index, index2);
			ORK.MoveAIs.DataRemoved(type, index, index2);
			ORK.Loot.DataRemoved(type, index, index2);
			ORK.BattleSystem.DataRemoved(type, index, index2);
			ORK.BattleSpots.DataRemoved(type, index, index2);
			ORK.BattleMenus.DataRemoved(type, index, index2);
			ORK.BattleTexts.DataRemoved(type, index, index2);
			ORK.BattleEnd.DataRemoved(type, index, index2);
			
			// menu
			ORK.GUILayers.DataRemoved(type, index, index2);
			ORK.GUIBoxes.DataRemoved(type, index, index2);
			ORK.MainMenu.DataRemoved(type, index, index2);
			ORK.SaveGameMenu.DataRemoved(type, index, index2);
			ORK.MenuSettings.DataRemoved(type, index, index2);
			ORK.CombatantSelections.DataRemoved(type, index, index2);
			ORK.QuantitySelections.DataRemoved(type, index, index2);
			ORK.MenuScreens.DataRemoved(type, index, index2);
			ORK.HUDs.DataRemoved(type, index, index2);
			ORK.ShopLayouts.DataRemoved(type, index, index2);
			ORK.Shops.DataRemoved(type, index, index2);
			
			// plugins
			ORK.Plugins.DataRemoved(type, index, index2);
			
			// remove list for event files
			if(ORK.Data.removeList == null)
			{
				ORK.Data.removeList = new List<KeyValuePair<ORKDataType, KeyValuePair<int, int>>>();
			}
			ORK.Data.removeList.Add(new KeyValuePair<ORKDataType, KeyValuePair<int, int>>(type, 
				new KeyValuePair<int, int>(index, index2)));
		}
		
		public static void Moved(ORKDataType type, bool down, int index)
		{
			DataHelper.Moved(type, down, index, -1);
		}
		
		public static void Moved(ORKDataType type, bool down, int index, int index2)
		{
			// editor data
			ORK.EditorSettings.DataMoved(type, down, index, index2);
			ORK.Backups.DataMoved(type, down, index, index2);
			
			// base data
			ORK.Languages.DataMoved(type, down, index, index2);
			ORK.Colors.DataMoved(type, down, index, index2);
			ORK.InputKeys.DataMoved(type, down, index, index2);
			ORK.ControlMaps.DataMoved(type, down, index, index2);
			ORK.FormulaTypes.DataMoved(type, down, index, index2);
			ORK.Formulas.DataMoved(type, down, index, index2);
			ORK.Requirements.DataMoved(type, down, index, index2);
			ORK.AnimationTypes.DataMoved(type, down, index, index2);
			ORK.Animations.DataMoved(type, down, index, index2);
			ORK.DamageTypes.DataMoved(type, down, index, index2);
			ORK.SoundTypes.DataMoved(type, down, index, index2);
			ORK.PortraitTypes.DataMoved(type, down, index, index2);
			ORK.VariableConditionTemplates.DataMoved(type, down, index, index2);
			ORK.StatusRequirementTemplates.DataMoved(type, down, index, index2);
			
			// game data
			ORK.GameSettings.DataMoved(type, down, index, index2);
			ORK.ConsoleSettings.DataMoved(type, down, index, index2);
			ORK.ConsoleTypes.DataMoved(type, down, index, index2);
			ORK.GameControls.DataMoved(type, down, index, index2);
			ORK.Difficulties.DataMoved(type, down, index, index2);
			ORK.SceneConnections.DataMoved(type, down, index, index2);
			ORK.AreaTypes.DataMoved(type, down, index, index2);
			ORK.Areas.DataMoved(type, down, index, index2);
			ORK.Teleports.DataMoved(type, down, index, index2);
			ORK.CameraPositions.DataMoved(type, down, index, index2);
			ORK.MusicClips.DataMoved(type, down, index, index2);
			ORK.GlobalEvents.DataMoved(type, down, index, index2);
			
			// world
			ORK.LogTypes.DataMoved(type, down, index, index2);
			ORK.Logs.DataMoved(type, down, index, index2);
			ORK.LogTexts.DataMoved(type, down, index, index2);
			ORK.SceneObjectTypes.DataMoved(type, down, index, index2);
			ORK.SceneObjects.DataMoved(type, down, index, index2);
			ORK.QuestTypes.DataMoved(type, down, index, index2);
			ORK.Quests.DataMoved(type, down, index, index2);
			ORK.QuestTasks.DataMoved(type, down, index, index2);
			
			// status data
			ORK.AttackAttributes.DataMoved(type, down, index, index2);
			ORK.DefenceAttributes.DataMoved(type, down, index, index2);
			ORK.StatusValues.DataMoved(type, down, index, index2);
			ORK.StatusEffectTypes.DataMoved(type, down, index, index2);
			ORK.StatusEffects.DataMoved(type, down, index, index2);
			ORK.StatusBonuses.DataMoved(type, down, index, index2);
			ORK.AbilityTypes.DataMoved(type, down, index, index2);
			ORK.Abilities.DataMoved(type, down, index, index2);
			ORK.AbilityTrees.DataMoved(type, down, index, index2);
			ORK.StatusDevelopments.DataMoved(type, down, index, index2);
			
			// inventory
			ORK.InventorySettings.DataMoved(type, down, index, index2);
			ORK.ItemTypes.DataMoved(type, down, index, index2);
			ORK.Currencies.DataMoved(type, down, index, index2);
			ORK.Items.DataMoved(type, down, index, index2);
			ORK.EquipmentParts.DataMoved(type, down, index, index2);
			ORK.Weapons.DataMoved(type, down, index, index2);
			ORK.Armors.DataMoved(type, down, index, index2);
			ORK.CraftingTypes.DataMoved(type, down, index, index2);
			ORK.CraftingRecipes.DataMoved(type, down, index, index2);
			
			// combatants
			ORK.Factions.DataMoved(type, down, index, index2);
			ORK.FactionBenefits.DataMoved(type, down, index, index2);
			ORK.FactionSympathy.DataMoved(type, down, index, index2);
			ORK.Classes.DataMoved(type, down, index, index2);
			
			// battle
			ORK.BattleSettings.DataMoved(type, down, index, index2);
			ORK.BattleAIs.DataMoved(type, down, index, index2);
			ORK.CombatantTypes.DataMoved(type, down, index, index2);
			ORK.Combatants.DataMoved(type, down, index, index2);
			ORK.CombatantGroups.DataMoved(type, down, index, index2);
			ORK.MoveAIs.DataMoved(type, down, index, index2);
			ORK.Loot.DataMoved(type, down, index, index2);
			ORK.BattleSystem.DataMoved(type, down, index, index2);
			ORK.BattleSpots.DataMoved(type, down, index, index2);
			ORK.BattleMenus.DataMoved(type, down, index, index2);
			ORK.BattleTexts.DataMoved(type, down, index, index2);
			ORK.BattleEnd.DataMoved(type, down, index, index2);
			
			// menu
			ORK.GUILayers.DataMoved(type, down, index, index2);
			ORK.GUIBoxes.DataMoved(type, down, index, index2);
			ORK.MainMenu.DataMoved(type, down, index, index2);
			ORK.SaveGameMenu.DataMoved(type, down, index, index2);
			ORK.MenuSettings.DataMoved(type, down, index, index2);
			ORK.CombatantSelections.DataMoved(type, down, index, index2);
			ORK.QuantitySelections.DataMoved(type, down, index, index2);
			ORK.MenuScreens.DataMoved(type, down, index, index2);
			ORK.HUDs.DataMoved(type, down, index, index2);
			ORK.ShopLayouts.DataMoved(type, down, index, index2);
			ORK.Shops.DataMoved(type, down, index, index2);
			
			// plugins
			ORK.Plugins.DataMoved(type, down, index, index2);
			
			if(ORK.Data.moveList == null)
			{
				ORK.Data.moveList = new List<KeyValuePair<ORKDataType, DataMoveInformation>>();
			}
			ORK.Data.moveList.Add(new KeyValuePair<ORKDataType, DataMoveInformation>(type, 
				new DataMoveInformation(down, index, index2)));
		}
		
		
		// status data
		public static void SetStatusValueType(int index, StatusValueType type)
		{
			ORK.Difficulties.SetStatusValueType(index, type);
			ORK.StatusValues.SetStatusValueType(index, type);
			ORK.StatusDevelopments.SetStatusValueType(index, type);
			ORK.AbilityTrees.SetStatusValueType(index, type);
			ORK.Combatants.SetStatusValueType(index, type);
			ORK.BattleSystem.SetStatusValueType(index, type);
		}
		
		public static void StatusValueMinMaxChanged(int index, int min, int max)
		{
			ORK.StatusDevelopments.StatusValueMinMaxChanged(index, min, max);
		}
		
		// developments
		public static void StatusDevelopmentLevels(int index)
		{
			ORK.Combatants.StatusDevelopmentLevels(index);
		}
		
		
		// inventory
		public static void WeaponEPChanged(int index)
		{
			//ORK.Classes.WeaponEPChanged(index);
			//ORK.Combatants.WeaponEPChanged(index);
		}
		
		public static void ArmorEPChanged(int index)
		{
			//ORK.Classes.ArmorEPChanged(index);
			//ORK.Combatants.ArmorEPChanged(index);
		}
		
		
		/*
		============================================================================
		Automatic data update functions
		============================================================================
		*/
		/// <summary>
		/// Processes adding data.
		/// </summary>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <param name='type'>
		/// ORKDataType defining the changed data.
		/// </param>
		/// <param name='index'>
		/// Index of the attack/defence attributes an attribute was added to.
		/// -1 if no attack/defence attribute was added.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="ORKFramework.IBaseData"> or 
		/// descend from <see cref="ORKFramework.BaseData">.
		/// </typeparam>
		public static void DataAdded<T>(T instance, ORKDataType type, int index)
		{
			if(instance != null)
			{
				FieldInfo[] field = instance.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);
				
				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);
					
					if(value != null)
					{
						if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}
							
							if(arrayInfo != null && type.Equals(arrayInfo.dataType))
							{
								if(index == -1)
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(arrayInfo.defaultAddValue == null)
									{
										tmp.Add(DataSerializer.CreateInstance(value.GetType().GetElementType()));
									}
									else
									{
										tmp.Add(arrayInfo.defaultAddValue);
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else if(index != -1)
							{
								if(ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].bonus, 0);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].bonus, 0);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].startValue, 100);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.Add<float>(ref tmp[j].startValue, 100);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}
								
								if(info != null && info.isPopup && type.Equals(info.popupType) && 
									!info.noAutoData && !info.noAutoAdd && 
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									tmp.Add(0);
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}
						
						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataAdded(value as IBaseData, type, index);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j=0; j<tmp.Length; j++)
							{
								DataHelper.DataAdded(tmp[j], type, index);
							}
						}
					}
				}
			}
		}
		
		/// <summary>
		/// Processes removing data.
		/// </summary>
		/// <param name='instance'>
		/// Instance of the class.
		/// </param>
		/// <param name='type'>
		/// ORKDataType defining the changed data.
		/// </param>
		/// <param name='index'>
		/// The index of the removed data.
		/// </param>
		/// <param name='index2'>
		/// The index of the removed attack/defence attribute.
		/// -1 if other data has been removed.
		/// </param>
		/// <typeparam name='T'>
		/// The class must implement the <see cref="ORKFramework.IBaseData"> or 
		/// descend from <see cref="ORKFramework.BaseData">.
		/// </typeparam>
		public static void DataRemoved<T>(T instance, ORKDataType type, int index, int index2)
		{
			if(instance != null)
			{
				FieldInfo[] field = instance.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);
				
				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);
					
					if(value != null)
					{
						if(value is int)
						{
							ORKEditorInfoAttribute editorInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
							if(attr.Length > 0)
							{
								editorInfo = attr[0] as ORKEditorInfoAttribute;
							}
							
							if(editorInfo != null && 
								(editorInfo.isPopup || editorInfo.isLimitedPopup))
							{
								ORKDataType type2 = editorInfo.popupType;
								
								// get type from other enum field
								if(editorInfo.isPopup && editorInfo.itemFieldName != "")
								{
									FieldInfo itemField = instance.GetType().GetField(editorInfo.itemFieldName);
									if(itemField != null)
									{
										EnumConverter.Convert(ref type2, itemField.GetValue(instance));
									}
								}
								
								if(type.Equals(type2))
								{
									// default
									if(index2 == -1 && (editorInfo.isLimitedPopup || editorInfo.idFieldName == ""))
									{
										int tmp = (int)value;
										if(tmp == index)
										{
											tmp = 0;
										}
										else if(tmp > index)
										{
											tmp--;
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
									// special type popup (attack/defence attribute)
									else if(index2 != -1 && editorInfo.idFieldName != "")
									{
										FieldInfo itemField = instance.GetType().GetField(editorInfo.idFieldName);
										if(itemField != null)
										{
											System.Object value2 = itemField.GetValue(instance);
											if(value2 is int && index == (int)value2)
											{
												int tmp = (int)value;
												if(tmp == index2)
												{
													tmp = 0;
												}
												else if(tmp > index2)
												{
													tmp--;
												}
												value = tmp;
												field[i].SetValue(instance, value);
											}
										}
									}
								}
							}
						}
						else if(value is string)
						{
							string tmp = (string)value;
							DataHelper.RemoveFromString(ref tmp, type, index, index2);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}
							
							if(arrayInfo != null)
							{
								if(value.GetType().GetElementType().Equals(typeof(ItemGain)))
								{
									ItemGain[] tmp = value as ItemGain[];
									if(tmp.Length > arrayInfo.noRemoveCount)
									{
										for(int j=0; j<tmp.Length; j++)
										{
											if(tmp[j] != null && 
												type.Equals(EnumConverter.Convert(tmp[j].type)) && 
												tmp[j].id == index)
											{
												ArrayHelper.RemoveAt(ref tmp, j);
												j--;
											}
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
								}
								// check attribute setter index
								else if(index2 != -1 && type.Equals(arrayInfo.dataType) && 
									value.GetType().GetElementType().Equals(typeof(AttributeSetter)))
								{
									AttributeSetter[] tmp = value as AttributeSetter[];
									if(index < tmp.Length && tmp[index] != null)
									{
										if(tmp[index].attribute == index2)
										{
											tmp[index].attribute = 0;
										}
										else if(tmp[index].attribute > index2)
										{
											tmp[index].attribute--;
										}
										value = tmp;
										field[i].SetValue(instance, value);
									}
								}
								// remove attribute bonus index
								else if(index2 != -1 && ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].bonus, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].bonus, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// remove attribute start value index
								else if(index2 != -1 && ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].startValue, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											ArrayHelper.RemoveAt(ref tmp[j].startValue, index2);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 == -1)
								{
									if(arrayInfo.removeCheckField != "" && 
										(type.Equals(arrayInfo.removeType) || 
										arrayInfo.typeCheckField != ""))
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										if(tmp.Count > arrayInfo.noRemoveCount)
										{
											for(int j=0; j<tmp.Count; j++)
											{
												if(tmp[j] != null)
												{
													FieldInfo itemField;
													ORKDataType type2 = arrayInfo.removeType;
													if(arrayInfo.typeCheckField != "")
													{
														itemField = tmp[j].GetType().GetField(arrayInfo.typeCheckField);
														if(itemField != null)
														{
															EnumConverter.Convert(ref type2, itemField.GetValue(tmp[j]));
														}
													}
													
													if(type.Equals(type2))
													{
														itemField = tmp[j].GetType().GetField(arrayInfo.removeCheckField);
														if(itemField != null)
														{
															System.Object value2 = itemField.GetValue(tmp[j]);
															if(value2 is int && index == (int)value2)
															{
																tmp.RemoveAt(j);
																j--;
															}
														}
													}
												}
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
									else if(type.Equals(arrayInfo.dataType))
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										if(tmp.Count > arrayInfo.noRemoveCount)
										{
											tmp.RemoveAt(index);
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
									else
									{
										ORKEditorInfoAttribute info = null;
										attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
										if(attr.Length > 0)
										{
											info = attr[0] as ORKEditorInfoAttribute;
										}
										
										if(info != null && info.isPopup && type.Equals(info.popupType) && 
											!info.noAutoData && !info.noAutoRemove && 
											value.GetType().GetElementType().Equals(typeof(int)) && index2 == -1)
										{
											ArrayList tmp = new ArrayList(value as System.Array);
											for(int j=0; j<tmp.Count; j++)
											{
												int tmpVal = (int)tmp[j];
												if(tmpVal == index)
												{
													tmp.RemoveAt(j--);
												}
												else if(tmpVal > index)
												{
													tmpVal--;
													tmp[j] = tmpVal;
												}
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
								}
								
								// check language strings
								if(ORKDataType.Language.Equals(arrayInfo.dataType) && 
									value.GetType().GetElementType().Equals(typeof(string)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									for(int j=0; j<tmp.Count; j++)
									{
										string tmpVal = (string)tmp[j];
										DataHelper.RemoveFromString(ref tmpVal, type, index, index2);
										tmp[j] = tmpVal;
										
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}
								
								if(info != null && info.isPopup && type.Equals(info.popupType) && 
									!info.noAutoData && !info.noAutoRemove && 
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(index2 == -1)
									{
										tmp.RemoveAt(index);
									}
									else
									{
										int tmpVal = (int)tmp[index];
										if(tmpVal == index2)
										{
											tmpVal = 0;
										}
										else if(tmpVal > index2)
										{
											tmpVal--;
										}
										tmp[index] = tmpVal;
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}
						
						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataRemoved(value as IBaseData, type, index, index2);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j=0; j<tmp.Length; j++)
							{
								DataHelper.DataRemoved(tmp[j], type, index, index2);
							}
						}
					}
				}
			}
		}
		
		public static void DataMoved<T>(T instance, ORKDataType type, bool down, int index, int index2)
		{
			if(instance != null)
			{
				FieldInfo[] field = instance.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);
				
				for(int i = 0; i < field.Length; i++)
				{
					System.Object value = field[i].GetValue(instance);
					
					if(value != null)
					{
						if(value is int)
						{
							ORKEditorInfoAttribute editorInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
							if(attr.Length > 0)
							{
								editorInfo = attr[0] as ORKEditorInfoAttribute;
							}
							
							if(editorInfo != null && 
								(editorInfo.isPopup || editorInfo.isLimitedPopup))
							{
								ORKDataType type2 = editorInfo.popupType;
								
								// get type from other enum field
								if(editorInfo.isPopup && editorInfo.itemFieldName != "")
								{
									FieldInfo itemField = instance.GetType().GetField(editorInfo.itemFieldName);
									if(itemField != null)
									{
										EnumConverter.Convert(ref type2, itemField.GetValue(instance));
									}
								}
								
								if(type.Equals(type2))
								{
									// default
									if(index2 == -1 && (editorInfo.isLimitedPopup || editorInfo.idFieldName == ""))
									{
										int tmp = (int)value;
										DataHelper.SwapIndex(ref tmp, index, down);
										value = tmp;
										field[i].SetValue(instance, value);
									}
									// special type popup (attack/defence attribute)
									else if(index2 != -1 && editorInfo.idFieldName != "")
									{
										FieldInfo itemField = instance.GetType().GetField(editorInfo.idFieldName);
										if(itemField != null)
										{
											System.Object value2 = itemField.GetValue(instance);
											if(value2 is int && index == (int)value2)
											{
												int tmp = (int)value;
												DataHelper.SwapIndex(ref tmp, index2, down);
												value = tmp;
												field[i].SetValue(instance, value);
											}
										}
									}
								}
							}
						}
						else if(value is string)
						{
							string tmp = (string)value;
							DataHelper.SwapInString(ref tmp, type, down, index, index2);
							value = tmp;
							field[i].SetValue(instance, value);
						}
						else if(value.GetType().IsArray)
						{
							ORKEditorArrayAttribute arrayInfo = null;
							System.Object[] attr = field[i].GetCustomAttributes(typeof(ORKEditorArrayAttribute), true);
							if(attr.Length > 0)
							{
								arrayInfo = attr[0] as ORKEditorArrayAttribute;
							}
							
							if(arrayInfo != null)
							{
								if(value.GetType().GetElementType().Equals(typeof(ItemGain)))
								{
									ItemGain[] tmp = value as ItemGain[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && 
											type.Equals(EnumConverter.Convert(tmp[j].type)))
										{
											DataHelper.SwapIndex(ref tmp[j].id, index, down);
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// check attribute setter index
								else if(index2 != -1 && type.Equals(arrayInfo.dataType) && 
									value.GetType().GetElementType().Equals(typeof(AttributeSetter)))
								{
									AttributeSetter[] tmp = value as AttributeSetter[];
									if(index < tmp.Length && tmp[index] != null)
									{
										DataHelper.SwapIndex(ref tmp[index].attribute, index2, down);
										value = tmp;
										field[i].SetValue(instance, value);
									}
								}
								// move attribute bonus index
								else if(index2 != -1 && ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrBonus)))
								{
									AtkAttrBonus[] tmp = value as AtkAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].bonus, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].bonus, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrBonus)))
								{
									DefAttrBonus[] tmp = value as DefAttrBonus[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].bonus, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].bonus, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								// move attribute start value index
								else if(index2 != -1 && ORKDataType.AttackAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(AtkAttrStartValue)))
								{
									AtkAttrStartValue[] tmp = value as AtkAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].startValue, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].startValue, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 != -1 && ORKDataType.DefenceAttributes.Equals(type) && 
									value.GetType().GetElementType().Equals(typeof(DefAttrStartValue)))
								{
									DefAttrStartValue[] tmp = value as DefAttrStartValue[];
									for(int j=0; j<tmp.Length; j++)
									{
										if(tmp[j] != null && tmp[j].attributeID == index)
										{
											if(down)
											{
												ArrayHelper.MoveDown(ref tmp[j].startValue, index2);
											}
											else
											{
												ArrayHelper.MoveUp(ref tmp[j].startValue, index2);
											}
										}
									}
									value = tmp;
									field[i].SetValue(instance, value);
								}
								else if(index2 == -1)
								{
									if(type.Equals(arrayInfo.dataType))
									{
										ArrayList tmp = new ArrayList(value as System.Array);
										DataHelper.SwapArrayList(ref tmp, index, down);
										value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
										field[i].SetValue(instance, value);
									}
									else
									{
										ORKEditorInfoAttribute info = null;
										attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
										if(attr.Length > 0)
										{
											info = attr[0] as ORKEditorInfoAttribute;
										}
										
										if(info != null && info.isPopup && type.Equals(info.popupType) && 
											!info.noAutoData && !info.noAutoMove && 
											value.GetType().GetElementType().Equals(typeof(int)) && index2 == -1)
										{
											ArrayList tmp = new ArrayList(value as System.Array);
											for(int j=0; j<tmp.Count; j++)
											{
												int tmpVal = (int)tmp[j];
												DataHelper.SwapIndex(ref tmpVal, index, down);
												tmp[j] = tmpVal;
											}
											value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
											field[i].SetValue(instance, value);
										}
									}
								}
								
								// check language strings
								if(ORKDataType.Language.Equals(arrayInfo.dataType) && 
									value.GetType().GetElementType().Equals(typeof(string)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									for(int j=0; j<tmp.Count; j++)
									{
										string tmpVal = (string)tmp[j];
										DataHelper.SwapInString(ref tmpVal, type, down, index, index2);
										tmp[j] = tmpVal;
										
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
							else
							{
								ORKEditorInfoAttribute info = null;
								attr = field[i].GetCustomAttributes(typeof(ORKEditorInfoAttribute), true);
								if(attr.Length > 0)
								{
									info = attr[0] as ORKEditorInfoAttribute;
								}
								
								if(info != null && info.isPopup && type.Equals(info.popupType) && 
									!info.noAutoData && !info.noAutoMove && 
									value.GetType().GetElementType().Equals(typeof(int)))
								{
									ArrayList tmp = new ArrayList(value as System.Array);
									if(index2 == -1)
									{
										DataHelper.SwapArrayList(ref tmp, index, down);
									}
									else
									{
										int tmpVal = (int)tmp[index];
										DataHelper.SwapIndex(ref tmpVal, index2, down);
										tmp[index] = tmpVal;
									}
									value = System.Convert.ChangeType(tmp.ToArray(value.GetType().GetElementType()), value.GetType());
									field[i].SetValue(instance, value);
								}
							}
						}
						
						if(typeof(IBaseData).IsAssignableFrom(field[i].FieldType))
						{
							DataHelper.DataMoved(value as IBaseData, type, down, index, index2);
						}
						else if(typeof(IBaseData[]).IsAssignableFrom(field[i].FieldType))
						{
							IBaseData[] tmp = (IBaseData[])(System.Array)value;
							for(int j=0; j<tmp.Length; j++)
							{
								DataHelper.DataMoved(tmp[j], type, down, index, index2);
							}
						}
					}
				}
			}
		}
		
		private static void SwapIndex(ref int tmp, int index, bool down)
		{
			if(down)
			{
				if(tmp == index)
				{
					tmp++;
				}
				else if(tmp == index + 1)
				{
					tmp--;
				}
			}
			else
			{
				if(tmp == index)
				{
					tmp--;
				}
				else if(tmp == index - 1)
				{
					tmp++;
				}
			}
		}
		
		private static void SwapArrayList(ref ArrayList tmp, int index, bool down)
		{
			if(down ? index + 1 < tmp.Count : index < tmp.Count)
			{
				System.Object obj = tmp[index];
				if(down)
				{
					tmp[index] = tmp[index + 1];
					tmp[index + 1] = obj;
				}
				else
				{
					tmp[index] = tmp[index - 1];
					tmp[index - 1] = obj;
				}
			}
		}
		
		private static void RemoveFromString(ref string text, ORKDataType type, int index, int index2)
		{
			if(ORKDataType.Area.Equals(type) && text.Contains(TextCode.Area))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.AreaName, TextCode.AreaDescription, TextCode.AreaIcon, 
						TextCode.Area_TypeName, TextCode.Area_TypeDescription, TextCode.Area_TypeIcon
					}, index, ORK.Areas.Count);
			}
			else if(ORKDataType.AreaType.Equals(type) && text.Contains(TextCode.AreaType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.AreaTypeName, TextCode.AreaTypeDescription, TextCode.AreaTypeIcon
					}, index, ORK.AreaTypes.Count);
			}
			else if(ORKDataType.Teleport.Equals(type) && text.Contains(TextCode.Teleport))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.TeleportName, TextCode.TeleportDescription, TextCode.TeleportIcon, 
						TextCode.Teleport_TypeName, TextCode.Teleport_TypeDescription, TextCode.Teleport_TypeIcon
					}, index, ORK.Teleports.Count);
			}
			else if(ORKDataType.Currency.Equals(type) && text.Contains(TextCode.Currency))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.CurrencyName, TextCode.CurrencyDescription, TextCode.CurrencyIcon, 
						TextCode.Currency_TypeName, TextCode.Currency_TypeDescription, TextCode.Currency_TypeIcon, 
						TextCode.Currency_Inventory
					}, index, ORK.Currencies.Count);
			}
			else if(ORKDataType.Item.Equals(type) && text.Contains(TextCode.Item))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ItemName, TextCode.ItemDescription, TextCode.ItemIcon, 
						TextCode.Item_TypeName, TextCode.Item_TypeDescription, TextCode.Item_TypeIcon, 
						TextCode.Item_Inventory
					}, index, ORK.Items.Count);
			}
			else if(ORKDataType.ItemType.Equals(type) && text.Contains(TextCode.ItemType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ItemTypeName, TextCode.ItemTypeDescription, TextCode.ItemTypeIcon
					}, index, ORK.ItemTypes.Count);
			}
			else if(ORKDataType.CraftingRecipe.Equals(type) && text.Contains(TextCode.CraftingRecipe))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.CraftingRecipeName, TextCode.CraftingRecipeDescription, TextCode.CraftingRecipeIcon, 
						TextCode.CraftingRecipe_TypeName, TextCode.CraftingRecipe_TypeDescription, TextCode.CraftingRecipe_TypeIcon
					}, index, ORK.CraftingRecipes.Count);
			}
			else if(ORKDataType.CraftingType.Equals(type) && text.Contains(TextCode.CraftingType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.CraftingTypeName, TextCode.CraftingTypeDescription, TextCode.CraftingTypeIcon
					}, index, ORK.CraftingTypes.Count);
			}
			else if(ORKDataType.Weapon.Equals(type) && text.Contains(TextCode.Weapon))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.WeaponName, TextCode.WeaponDescription, TextCode.WeaponIcon, 
						TextCode.Weapon_TypeName, TextCode.Weapon_TypeDescription, TextCode.Weapon_TypeIcon, 
						TextCode.Weapon_Inventory, TextCode.Weapon_Equipped
					}, index, ORK.Weapons.Count);
			}
			else if(ORKDataType.Armor.Equals(type) && text.Contains(TextCode.Armor))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ArmorName, TextCode.ArmorDescription, TextCode.ArmorIcon, 
						TextCode.Armor_TypeName, TextCode.Armor_TypeDescription, TextCode.Armor_TypeIcon, 
						TextCode.Armor_Inventory, TextCode.Armor_Equipped
					}, index, ORK.Armors.Count);
			}
			else if(ORKDataType.EquipmentPart.Equals(type) && text.Contains(TextCode.EquipmentPart))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.EquipmentPartName, TextCode.EquipmentPartDescription, TextCode.EquipmentPartIcon
					}, index, ORK.EquipmentParts.Count);
			}
			else if(ORKDataType.Ability.Equals(type) && text.Contains(TextCode.Ability))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.AbilityName, TextCode.AbilityDescription, TextCode.AbilityIcon, 
						TextCode.Ability_TypeName, TextCode.Ability_TypeDescription, TextCode.Ability_TypeIcon
					}, index, ORK.Abilities.Count);
			}
			else if(ORKDataType.AbilityType.Equals(type) && text.Contains(TextCode.AbilityType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.AbilityTypeName, TextCode.AbilityTypeDescription, TextCode.AbilityTypeIcon
					}, index, ORK.AbilityTypes.Count);
			}
			else if(ORKDataType.AbilityTree.Equals(type) && text.Contains(TextCode.AbilityTree))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.AbilityTreeName, TextCode.AbilityTreeDescription, TextCode.AbilityTreeIcon
					}, index, ORK.AbilityTrees.Count);
			}
			else if(ORKDataType.Log.Equals(type) && text.Contains(TextCode.Log))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.LogName, TextCode.LogDescription, TextCode.LogIcon, 
						TextCode.Log_TypeName, TextCode.Log_TypeDescription, TextCode.Log_TypeIcon
					}, index, ORK.Logs.Count);
			}
			else if(ORKDataType.LogType.Equals(type) && text.Contains(TextCode.LogType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.LogTypeName, TextCode.LogTypeDescription, TextCode.LogTypeIcon
					}, index, ORK.LogTypes.Count);
			}
			else if(ORKDataType.LogText.Equals(type) && text.Contains(TextCode.LogText))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {TextCode.LogText}, 
					index, ORK.LogTexts.Count);
			}
			else if(ORKDataType.Quest.Equals(type) && text.Contains(TextCode.Quest))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.QuestName, TextCode.QuestDescription, TextCode.QuestIcon, 
						TextCode.Quest_TypeName, TextCode.Quest_TypeDescription, TextCode.Quest_TypeIcon, 
						TextCode.QuestText
					}, index, ORK.Quests.Count);
			}
			else if(ORKDataType.QuestType.Equals(type) && text.Contains(TextCode.QuestType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.QuestTypeName, TextCode.QuestTypeDescription, TextCode.QuestTypeIcon
					}, index, ORK.QuestTypes.Count);
			}
			else if(ORKDataType.QuestTask.Equals(type) && text.Contains(TextCode.QuestTask))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.QuestTaskName, TextCode.QuestTaskDescription, TextCode.QuestTaskIcon
					}, index, ORK.QuestTasks.Count);
			}
			else if(ORKDataType.SceneObjectType.Equals(type) && text.Contains(TextCode.SceneObjectType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.SceneObjectTypeName, TextCode.SceneObjectTypeDescription, TextCode.SceneObjectTypeIcon
					}, index, ORK.SceneObjectTypes.Count);
			}
			else if(ORKDataType.SceneObject.Equals(type) && text.Contains(TextCode.SceneObject))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.SceneObjectName, TextCode.SceneObjectDescription, TextCode.SceneObjectIcon, 
						TextCode.SceneObject_TypeName, TextCode.SceneObject_TypeDescription, TextCode.SceneObject_TypeIcon
					}, index, ORK.SceneObjects.Count);
			}
			else if(ORKDataType.Shop.Equals(type) && text.Contains(TextCode.Shop))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ShopName, TextCode.ShopDescription, TextCode.ShopIcon
					}, index, ORK.Shops.Count);
			}
			else if(ORKDataType.StatusValue.Equals(type) && text.Contains(TextCode.StatusValue))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.StatusValueName, TextCode.StatusValueDescription, TextCode.StatusValueIcon
					}, index, ORK.StatusValues.Count);
			}
			else if(ORKDataType.StatusEffectType.Equals(type) && text.Contains(TextCode.StatusEffectType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.StatusEffectTypeName, TextCode.StatusEffectTypeDescription, TextCode.StatusEffectTypeIcon
					}, index, ORK.StatusEffectTypes.Count);
			}
			else if(ORKDataType.StatusEffect.Equals(type) && text.Contains(TextCode.StatusEffect))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.StatusEffectName, TextCode.StatusEffectDescription, TextCode.StatusEffectIcon, 
						TextCode.StatusEffect_TypeName, TextCode.StatusEffect_TypeDescription, TextCode.StatusEffect_TypeIcon
					}, index, ORK.StatusEffects.Count);
			}
			else if(ORKDataType.AttackAttributes.Equals(type) && text.Contains(TextCode.AttackAttribute))
			{
				if(index2 == -1)
				{
					DataHelper.RemoveFromString2(ref text, new string[] {
							TextCode.AttackAttributeName, TextCode.AttackAttributeDescription, TextCode.AttackAttributeIcon, 
							TextCode.AttackAttributeSubName, TextCode.AttackAttributeSubDescription, TextCode.AttackAttributeSubIcon
						}, index, ORK.AttackAttributes.Count);
				}
				else
				{
					DataHelper.RemoveFromString2(ref text, new string[] {
							TextCode.AttackAttributeSubName + index + "#", 
							TextCode.AttackAttributeSubDescription + index + "#", 
							TextCode.AttackAttributeSubIcon + index + "#"
						}, index2, ORK.AttackAttributes.AttributeCount(index));
				}
			}
			else if(ORKDataType.DefenceAttributes.Equals(type) && text.Contains(TextCode.DefenceAttribute))
			{
				if(index2 == -1)
				{
					DataHelper.RemoveFromString2(ref text, new string[] {
							TextCode.DefenceAttributeName, TextCode.DefenceAttributeDescription, TextCode.DefenceAttributeIcon, 
							TextCode.DefenceAttributeSubName, TextCode.DefenceAttributeSubDescription, TextCode.DefenceAttributeSubIcon
						}, index, ORK.DefenceAttributes.Count);
				}
				else
				{
					DataHelper.RemoveFromString2(ref text, new string[] {
							TextCode.DefenceAttributeSubName + index + "#", 
							TextCode.DefenceAttributeSubDescription + index + "#", 
							TextCode.DefenceAttributeSubIcon + index + "#"
						}, index2, ORK.DefenceAttributes.AttributeCount(index));
				}
			}
			else if(ORKDataType.Class.Equals(type) && text.Contains(TextCode.Class))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ClassName, TextCode.ClassDescription, TextCode.ClassIcon
					}, index, ORK.Classes.Count);
			}
			else if(ORKDataType.CombatantType.Equals(type) && text.Contains(TextCode.CombatantType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.CombatantTypeName, TextCode.CombatantTypeDescription, TextCode.CombatantTypeIcon
					}, index, ORK.CombatantTypes.Count);
			}
			else if(ORKDataType.Combatant.Equals(type) && text.Contains(TextCode.Combatant))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.CombatantName, TextCode.CombatantDescription, TextCode.CombatantIcon,
						TextCode.Combatant_TypeName, TextCode.Combatant_TypeDescription, TextCode.Combatant_TypeIcon
					}, index, ORK.Combatants.Count);
			}
			else if(ORKDataType.Faction.Equals(type) && text.Contains(TextCode.Faction))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.FactionName, TextCode.FactionDescription, TextCode.FactionIcon, 
						TextCode.FactionSympathy, TextCode.FactionISympathy, 
						TextCode.Faction_BenefitName, TextCode.Faction_BenefitDescription, TextCode.Faction_BenefitIcon
					}, index, ORK.Factions.Count);
				for(int i=0; i<ORK.Factions.Count; i++)
				{
					DataHelper.RemoveFromString2(ref text, new string[] {
							TextCode.FactionSympathy + i + "#", TextCode.FactionISympathy + i + "#", 
							TextCode.Faction_BenefitName + i + "#", TextCode.Faction_BenefitDescription + i + "#", 
							TextCode.Faction_BenefitIcon + i + "#"
						}, index, ORK.Factions.Count);
				}
			}
			else if(ORKDataType.FactionBenefit.Equals(type) && text.Contains(TextCode.FactionBenefit))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.FactionBenefitName, TextCode.FactionBenefitDescription, TextCode.FactionBenefitIcon
					}, index, ORK.FactionBenefits.Count);
			}
			else if(ORKDataType.ConsoleType.Equals(type) && text.Contains(TextCode.ConsoleType))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.ConsoleTypeName, TextCode.ConsoleTypeDescription, TextCode.ConsoleTypeIcon
					}, index, ORK.ConsoleTypes.Count);
			}
			else if(ORKDataType.Difficulty.Equals(type) && text.Contains(TextCode.Difficulty))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.DifficultyName, TextCode.DifficultyDescription, TextCode.DifficultyIcon
					}, index, ORK.Difficulties.Count);
			}
			else if(ORKDataType.Language.Equals(type) && text.Contains(TextCode.Language))
			{
				DataHelper.RemoveFromString2(ref text, new string[] {
						TextCode.LanguageName, TextCode.LanguageDescription, TextCode.LanguageIcon
					}, index, ORK.Languages.Count);
			}
		}
		
		private static void RemoveFromString2(ref string text, string[] code, int index, int count)
		{
			for(int i=0; i<code.Length; i++)
			{
				text = text.Replace(code[i] + index + "#", code[i] + "0#");
				for(int j=index + 1; j<=count; j++)
				{
					text = text.Replace(code[i] + j + "#", code[i] + (j - 1) + "#");
				}
			}
		}
		
		private static void SwapInString(ref string text, ORKDataType type, bool down, int index, int index2)
		{
			if(ORKDataType.Area.Equals(type) && text.Contains(TextCode.Area))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.AreaName, TextCode.AreaDescription, TextCode.AreaIcon, 
						TextCode.Area_TypeName, TextCode.Area_TypeDescription, TextCode.Area_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.AreaType.Equals(type) && text.Contains(TextCode.AreaType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.AreaTypeName, TextCode.AreaTypeDescription, TextCode.AreaTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Teleport.Equals(type) && text.Contains(TextCode.Teleport))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.TeleportName, TextCode.TeleportDescription, TextCode.TeleportIcon, 
						TextCode.Teleport_TypeName, TextCode.Teleport_TypeDescription, TextCode.Teleport_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Currency.Equals(type) && text.Contains(TextCode.Currency))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.CurrencyName, TextCode.CurrencyDescription, TextCode.CurrencyIcon, 
						TextCode.Currency_TypeName, TextCode.Currency_TypeDescription, TextCode.Currency_TypeIcon, 
						TextCode.Currency_Inventory
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Item.Equals(type) && text.Contains(TextCode.Item))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ItemName, TextCode.ItemDescription, TextCode.ItemIcon, 
						TextCode.Item_TypeName, TextCode.Item_TypeDescription, TextCode.Item_TypeIcon, 
						TextCode.Item_Inventory
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.ItemType.Equals(type) && text.Contains(TextCode.ItemType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ItemTypeName, TextCode.ItemTypeDescription, TextCode.ItemTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.CraftingRecipe.Equals(type) && text.Contains(TextCode.CraftingRecipe))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.CraftingRecipeName, TextCode.CraftingRecipeDescription, TextCode.CraftingRecipeIcon, 
						TextCode.CraftingRecipe_TypeName, TextCode.CraftingRecipe_TypeDescription, TextCode.CraftingRecipe_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.CraftingType.Equals(type) && text.Contains(TextCode.CraftingType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.CraftingTypeName, TextCode.CraftingTypeDescription, TextCode.CraftingTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Weapon.Equals(type) && text.Contains(TextCode.Weapon))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.WeaponName, TextCode.WeaponDescription, TextCode.WeaponIcon, 
						TextCode.Weapon_TypeName, TextCode.Weapon_TypeDescription, TextCode.Weapon_TypeIcon, 
						TextCode.Weapon_Inventory, TextCode.Weapon_Equipped
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Armor.Equals(type) && text.Contains(TextCode.Armor))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ArmorName, TextCode.ArmorDescription, TextCode.ArmorIcon, 
						TextCode.Armor_TypeName, TextCode.Armor_TypeDescription, TextCode.Armor_TypeIcon, 
						TextCode.Armor_Inventory, TextCode.Armor_Equipped
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.EquipmentPart.Equals(type) && text.Contains(TextCode.EquipmentPart))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.EquipmentPartName, TextCode.EquipmentPartDescription, TextCode.EquipmentPartIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Ability.Equals(type) && text.Contains(TextCode.Ability))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.AbilityName, TextCode.AbilityDescription, TextCode.AbilityIcon, 
						TextCode.Ability_TypeName, TextCode.Ability_TypeDescription, TextCode.Ability_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.AbilityType.Equals(type) && text.Contains(TextCode.AbilityType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.AbilityTypeName, TextCode.AbilityTypeDescription, TextCode.AbilityTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.AbilityTree.Equals(type) && text.Contains(TextCode.AbilityTree))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.AbilityTreeName, TextCode.AbilityTreeDescription, TextCode.AbilityTreeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Log.Equals(type) && text.Contains(TextCode.Log))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.LogName, TextCode.LogDescription, TextCode.LogIcon, 
						TextCode.Log_TypeName, TextCode.Log_TypeDescription, TextCode.Log_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.LogType.Equals(type) && text.Contains(TextCode.LogType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.LogTypeName, TextCode.LogTypeDescription, TextCode.LogTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.LogText.Equals(type) && text.Contains(TextCode.LogText))
			{
				DataHelper.SwapInString2(ref text, new string[] {TextCode.LogText}, 
					index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Quest.Equals(type) && text.Contains(TextCode.Quest))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.QuestName, TextCode.QuestDescription, TextCode.QuestIcon, 
						TextCode.Quest_TypeName, TextCode.Quest_TypeDescription, TextCode.Quest_TypeIcon, 
						TextCode.QuestText
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.QuestType.Equals(type) && text.Contains(TextCode.QuestType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.QuestTypeName, TextCode.QuestTypeDescription, TextCode.QuestTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.QuestTask.Equals(type) && text.Contains(TextCode.QuestTask))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.QuestTaskName, TextCode.QuestTaskDescription, TextCode.QuestTaskIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.SceneObjectType.Equals(type) && text.Contains(TextCode.SceneObjectType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.SceneObjectTypeName, TextCode.SceneObjectTypeDescription, TextCode.SceneObjectTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.SceneObject.Equals(type) && text.Contains(TextCode.SceneObject))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.SceneObjectName, TextCode.SceneObjectDescription, TextCode.SceneObjectIcon, 
						TextCode.SceneObject_TypeName, TextCode.SceneObject_TypeDescription, TextCode.SceneObject_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Shop.Equals(type) && text.Contains(TextCode.Shop))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ShopName, TextCode.ShopDescription, TextCode.ShopIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.StatusValue.Equals(type) && text.Contains(TextCode.StatusValue))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.StatusValueName, TextCode.StatusValueDescription, TextCode.StatusValueIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.StatusEffectType.Equals(type) && text.Contains(TextCode.StatusEffectType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.StatusEffectTypeName, TextCode.StatusEffectTypeDescription, TextCode.StatusEffectTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.StatusEffect.Equals(type) && text.Contains(TextCode.StatusEffect))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.StatusEffectName, TextCode.StatusEffectDescription, TextCode.StatusEffectIcon, 
						TextCode.StatusEffect_TypeName, TextCode.StatusEffect_TypeDescription, TextCode.StatusEffect_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.AttackAttributes.Equals(type) && text.Contains(TextCode.AttackAttribute))
			{
				if(index2 == -1)
				{
					DataHelper.SwapInString2(ref text, new string[] {
							TextCode.AttackAttributeName, TextCode.AttackAttributeDescription, TextCode.AttackAttributeIcon, 
							TextCode.AttackAttributeSubName, TextCode.AttackAttributeSubDescription, TextCode.AttackAttributeSubIcon
						}, index, down ? index + 1 : index - 1);
				}
				else
				{
					DataHelper.SwapInString2(ref text, new string[] {
							TextCode.AttackAttributeSubName + index + "#", 
							TextCode.AttackAttributeSubDescription + index + "#", 
							TextCode.AttackAttributeSubIcon + index + "#"
						}, index2, down ? index2 + 1 : index2 - 1);
				}
			}
			else if(ORKDataType.DefenceAttributes.Equals(type) && text.Contains(TextCode.DefenceAttribute))
			{
				if(index2 == -1)
				{
					DataHelper.SwapInString2(ref text, new string[] {
							TextCode.DefenceAttributeName, TextCode.DefenceAttributeDescription, TextCode.DefenceAttributeIcon, 
							TextCode.DefenceAttributeSubName, TextCode.DefenceAttributeSubDescription, TextCode.DefenceAttributeSubIcon
						}, index, down ? index + 1 : index - 1);
				}
				else
				{
					DataHelper.SwapInString2(ref text, new string[] {
							TextCode.DefenceAttributeSubName + index + "#", 
							TextCode.DefenceAttributeSubDescription + index + "#", 
							TextCode.DefenceAttributeSubIcon + index + "#"
						}, index2, down ? index2 + 1 : index2 - 1);
				}
			}
			else if(ORKDataType.Class.Equals(type) && text.Contains(TextCode.Class))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ClassName, TextCode.ClassDescription, TextCode.ClassIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.CombatantType.Equals(type) && text.Contains(TextCode.CombatantType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.CombatantTypeName, TextCode.CombatantTypeDescription, TextCode.CombatantTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Combatant.Equals(type) && text.Contains(TextCode.Combatant))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.CombatantName, TextCode.CombatantDescription, TextCode.CombatantIcon,
						TextCode.Combatant_TypeName, TextCode.Combatant_TypeDescription, TextCode.Combatant_TypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Faction.Equals(type) && text.Contains(TextCode.Faction))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.FactionName, TextCode.FactionDescription, TextCode.FactionIcon, 
						TextCode.FactionSympathy, TextCode.FactionISympathy, 
						TextCode.Faction_BenefitName, TextCode.Faction_BenefitDescription, TextCode.Faction_BenefitIcon
					}, index, down ? index + 1 : index - 1);
				for(int i=0; i<ORK.Factions.Count; i++)
				{
					DataHelper.SwapInString2(ref text, new string[] {
							TextCode.FactionSympathy + i + "#", TextCode.FactionISympathy + i + "#", 
							TextCode.Faction_BenefitName + i + "#", TextCode.Faction_BenefitDescription + i + "#", 
							TextCode.Faction_BenefitIcon + i + "#"
						}, index, down ? index + 1 : index - 1);
				}
			}
			else if(ORKDataType.FactionBenefit.Equals(type) && text.Contains(TextCode.FactionBenefit))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.FactionBenefitName, TextCode.FactionBenefitDescription, TextCode.FactionBenefitIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.ConsoleType.Equals(type) && text.Contains(TextCode.ConsoleType))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.ConsoleTypeName, TextCode.ConsoleTypeDescription, TextCode.ConsoleTypeIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Difficulty.Equals(type) && text.Contains(TextCode.Difficulty))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.DifficultyName, TextCode.DifficultyDescription, TextCode.DifficultyIcon
					}, index, down ? index + 1 : index - 1);
			}
			else if(ORKDataType.Language.Equals(type) && text.Contains(TextCode.Language))
			{
				DataHelper.SwapInString2(ref text, new string[] {
						TextCode.LanguageName, TextCode.LanguageDescription, TextCode.LanguageIcon
					}, index, down ? index + 1 : index - 1);
			}
		}
		
		private static void SwapInString2(ref string text, string[] code, int index, int index2)
		{
			for(int i=0; i<code.Length; i++)
			{
				text = text.Replace(code[i] + index + "#", "#TMP#");
				text = text.Replace(code[i] + index2 + "#", code[i] + index + "#");
				text = text.Replace("#TMP#", code[i] + index2 + "#");
			}
		}
	}
}
