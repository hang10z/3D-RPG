
using UnityEngine;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace ORKFramework
{
	public class SecurityHandler : ISecurityHandler
	{
		// save game encryption
		private static byte[] SAVE_KEY = new byte[] {
			0x1b, 0x75, 0x8a, 0xe7, 0xfb, 0xfe, 0x07, 0x16, 0x32, 0x7b, 0x79, 0xd7, 0x6b, 0xea, 0xda, 0xce, 
			0x4d, 0x53, 0xec, 0x4b, 0xdb, 0x36, 0xe5, 0x06, 0x07, 0xc7, 0x80, 0x28, 0x4d, 0x94, 0x39, 0x37
		};
		
		private static byte[] SAVE_IV = new byte[] {
			0xce, 0xaf, 0x3c, 0x2a, 0xb4, 0x86, 0x3a, 0xdd, 0x30, 0xca, 0x6c, 0x42, 0x3a, 0xf4, 0xa2, 0xd7, 
			0x19, 0xd8, 0xcd, 0xcf, 0x5e, 0xe4, 0x3e, 0x0a, 0xf6, 0xb2, 0x94, 0x65, 0x6a, 0xe2, 0x92, 0x9d
		};
		
		
		// project data encryption
		private static byte[] PROJECT_KEY = new byte[] {
			0xdb, 0xd5, 0x03, 0x37, 0x97, 0xa0, 0x41, 0x3b, 0xf2, 0x60, 0x1f, 0x11, 0xf3, 0x83, 0x9e, 0xdd, 
			0x7a, 0x73, 0x93, 0x7a, 0xcd, 0xbf, 0x58, 0xe3, 0x50, 0x64, 0x8c, 0xf8, 0x4e, 0x66, 0x3c, 0xea
		};
		
		private static byte[] PROJECT_IV = new byte[] {
			0x51, 0xc3, 0x2e, 0x2b, 0x61, 0x5b, 0x05, 0xe3, 0x6f, 0xf4, 0xd7, 0xba, 0x32, 0x25, 0x6b, 0x65, 
			0x05, 0xbb, 0x9b, 0x77, 0x5f, 0xfa, 0x2e, 0xd1, 0x14, 0x23, 0xc1, 0xf4, 0x72, 0x68, 0x06, 0x5f
		};
		
		
		/*
		============================================================================
		Save game handling functions
		============================================================================
		*/
		public string SaveGame(string text)
		{
			return this.EncryptRijndael(text, SecurityHandler.SAVE_KEY, SecurityHandler.SAVE_IV);
		}
		
		public string LoadGame(string text)
		{
			if(text.StartsWith("<savegame"))
			{
				return text;
			}
			else
			{
				return this.DecryptRijndael(text, SecurityHandler.SAVE_KEY, SecurityHandler.SAVE_IV);
			}
		}
		
		
		/*
		============================================================================
		Project handling functions
		============================================================================
		*/
		public string SaveData(string text)
		{
			return this.EncryptRijndael(text, SecurityHandler.PROJECT_KEY, SecurityHandler.PROJECT_IV);
		}
		
		public string LoadData(string text)
		{
			return this.DecryptRijndael(text, SecurityHandler.PROJECT_KEY, SecurityHandler.PROJECT_IV);
		}
		
		
		/*
		============================================================================
		Rijndael handling functions
		============================================================================
		*/
		private string EncryptRijndael(string text, byte[] key, byte[] iv)
		{
			string result = "";
			if(text != "")
			{
				using (RijndaelManaged rj = new RijndaelManaged())
			    {
			        try
			        {
			            rj.Padding = PaddingMode.Zeros;
			            rj.Mode = CipherMode.CBC;
			            rj.KeySize = 256;
			            rj.BlockSize = 256;
			            rj.Key = key;
			            rj.IV = iv;
						
			            using(MemoryStream ms = new MemoryStream())
						{
				            using(CryptoStream cs = new CryptoStream(ms, rj.CreateEncryptor(rj.Key, rj.IV), CryptoStreamMode.Write))
				            {
				                using(StreamWriter sw = new StreamWriter(cs))
				                {
				                    sw.Write(this.Enclose(text, "{", "}"));
									sw.Close();
				                }
								result = Convert.ToBase64String(ms.ToArray());
								cs.Close();
				            }
							ms.Close();
						}
			        }
			        finally
			        {
			            rj.Clear();
			        }
			    }
			}
			return result;
		}
		
		private string DecryptRijndael(string text, byte[] key, byte[] iv)
		{
			string result = "";
			if(text != "")
			{
				byte[] cypher = Convert.FromBase64String(text);
				
				using (RijndaelManaged rj = new RijndaelManaged())
			    {
			        try
			        {
			            rj.Padding = PaddingMode.Zeros;
			            rj.Mode = CipherMode.CBC;
			            rj.KeySize = 256;
			            rj.BlockSize = 256;
			            rj.Key = key;
			            rj.IV = iv;
						
			            using(MemoryStream ms = new MemoryStream(cypher))
						{
				            using(CryptoStream cs = new CryptoStream(ms, rj.CreateDecryptor(rj.Key, rj.IV), CryptoStreamMode.Read))
				            {
								using(StreamReader sr = new StreamReader(cs))
				                {
				                    result = this.GetEnclosed(sr.ReadToEnd(), "{", "}");
									sr.Close();
				                }
								cs.Close();
				            }
							ms.Close();
						}
			        }
			        finally
			        {
			            rj.Clear();
			        }
			    }
			}
			return result;
		}
		
		private string Enclose(string text, string begin, string end)
		{
			return new StringBuilder(begin).Append(text).Append(end).ToString();
		}
		
		private string GetEnclosed(string text, string begin, string end)
		{
			int index = text.IndexOf(begin) + 1;
			if(text.LastIndexOf(end) - index < 0)
			{
				return "";
			}
			else
			{
				return text.Substring(index, text.LastIndexOf(end) - index);
			}
		}
	}
}
